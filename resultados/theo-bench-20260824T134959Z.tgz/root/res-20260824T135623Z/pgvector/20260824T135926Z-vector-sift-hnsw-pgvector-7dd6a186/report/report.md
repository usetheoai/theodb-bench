# vector/sift/hnsw on pgvector

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T135926Z-vector-sift-hnsw-pgvector-7dd6a186`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,305 | 0.8854 | 0.6682 | 0.87 | 1.158 | **no** |
| hnsw m=16 ef_search=64 | 890.7 | 0.9882 | 1.052 | 1.375 | 1.591 | yes |
| hnsw m=16 ef_search=256 | 357.1 | 0.9998 | 2.769 | 3.396 | 3.649 | yes |
| hnsw m=16 ef_search=512 | 232.1 | 1 | 4.267 | 5.37 | 5.696 | yes |
| hnsw m=16 ef_search=1000 | 142.4 | 0.998 | 6.992 | 8.666 | 9.337 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.239

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 28.55, 28.55, 28.55
- `hnsw m=16 ef_search=16` index_size_bytes: 8.312e+07, 8.312e+07, 8.312e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6948, 0.6682, 0.649
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.8954, 0.87, 0.8611
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.9952, 1.158, 1.571
- `hnsw m=16 ef_search=16` recall: 0.8854, 0.8854, 0.8854
- `hnsw m=16 ef_search=16` throughput_per_second: 1,287, 1,305, 1,340
- `hnsw m=16 ef_search=64` build_seconds: 28.86, 28.86, 28.86
- `hnsw m=16 ef_search=64` index_size_bytes: 8.312e+07, 8.312e+07, 8.312e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.052, 1.058, 1.05
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.27, 1.375, 1.387
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.473, 1.592, 1.591
- `hnsw m=16 ef_search=64` recall: 0.9882, 0.9882, 0.9882
- `hnsw m=16 ef_search=64` throughput_per_second: 890.7, 860.2, 892.1
- `hnsw m=16 ef_search=256` build_seconds: 27.67, 27.67, 27.67
- `hnsw m=16 ef_search=256` index_size_bytes: 8.312e+07, 8.312e+07, 8.312e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.769, 2.803, 2.763
- `hnsw m=16 ef_search=256` latency_p95_ms: 3.391, 3.428, 3.396
- `hnsw m=16 ef_search=256` latency_p99_ms: 3.63, 3.649, 3.65
- `hnsw m=16 ef_search=256` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=256` throughput_per_second: 358.1, 352.7, 357.1
- `hnsw m=16 ef_search=512` build_seconds: 28.11, 28.11, 28.11
- `hnsw m=16 ef_search=512` index_size_bytes: 8.315e+07, 8.315e+07, 8.315e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 4.242, 4.421, 4.267
- `hnsw m=16 ef_search=512` latency_p95_ms: 5.37, 5.424, 5.325
- `hnsw m=16 ef_search=512` latency_p99_ms: 5.696, 6.116, 5.678
- `hnsw m=16 ef_search=512` recall: 1, 1, 1
- `hnsw m=16 ef_search=512` throughput_per_second: 232.3, 225, 232.1
- `hnsw m=16 ef_search=1000` build_seconds: 27.82, 27.82, 27.82
- `hnsw m=16 ef_search=1000` index_size_bytes: 8.314e+07, 8.314e+07, 8.314e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 7.038, 6.992, 6.956
- `hnsw m=16 ef_search=1000` latency_p95_ms: 8.683, 8.648, 8.666
- `hnsw m=16 ef_search=1000` latency_p99_ms: 9.14, 9.892, 9.337
- `hnsw m=16 ef_search=1000` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=1000` throughput_per_second: 142.4, 141.8, 142.6

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T134959Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

