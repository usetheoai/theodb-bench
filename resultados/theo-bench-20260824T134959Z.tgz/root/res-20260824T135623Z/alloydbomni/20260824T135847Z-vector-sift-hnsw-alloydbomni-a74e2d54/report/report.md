# vector/sift/hnsw on alloydbomni

**Status:** INVALID · **Profile:** research · **Run:** `20260824T135847Z-vector-sift-hnsw-alloydbomni-a74e2d54`

> This run is **INVALID**. It failed protocol validation, which says nothing about whether the numbers were favourable -- invalidation is never based on the measured outcome.

## Results

No configuration produced a measurement.

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | FAIL | yes | the harness refused to measure: a precondition it checks was not met, so no number was taken. This is the harness working, not a fault of the system under test |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | UNAVAILABLE | no | benchmark declared no expected operation count |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | FAIL | yes | approximate retrieval reported without a quality axis |
| clean_source_tree | PASS | no |  |

Invalidated by: `run_not_refused`, `quality_reported`

Invalidation is based on protocol criteria, never on whether the numbers looked good.

## Environment

- Host: theo-bench-20260824T134959Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

