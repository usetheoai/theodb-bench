# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T135726Z-vector-sift-hnsw-theodb-ac0de2f0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,485 | 0.8706 | 0.6013 | 0.7775 | 0.9261 | **no** |
| hnsw m=16 ef_search=64 | 1,140 | 0.9632 | 0.7904 | 0.9832 | 1.153 | **no** |
| hnsw m=16 ef_search=256 | 499.5 | 0.9978 | 1.948 | 2.401 | 2.53 | **no** |
| hnsw m=16 ef_search=512 | 288.9 | 0.9998 | 3.371 | 4.589 | 5.509 | **no** |
| hnsw m=16 ef_search=1000 | 178.8 | 0.9996 | 5.591 | 6.99 | 7.469 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.071
- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.051; latency_p95_ms cv=0.194; latency_p99_ms cv=0.198; throughput_per_second cv=0.065
- `hnsw m=16 ef_search=256`: latency_p95_ms cv=0.111; latency_p99_ms cv=0.138
- `hnsw m=16 ef_search=512`: latency_p95_ms cv=0.111; latency_p99_ms cv=0.134
- `hnsw m=16 ef_search=1000`: latency_p95_ms cv=0.067; latency_p99_ms cv=0.140

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 11.06, 11.06, 11.06
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6013, 0.5997, 0.6118
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7443, 0.7902, 0.7775
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8375, 0.9261, 0.9623
- `hnsw m=16 ef_search=16` recall: 0.8706, 0.8706, 0.8706
- `hnsw m=16 ef_search=16` throughput_per_second: 1,509, 1,485, 1,467
- `hnsw m=16 ef_search=64` build_seconds: 10.8, 10.8, 10.8
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7904, 0.7834, 0.8586
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9464, 0.9832, 1.328
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.01, 1.153, 1.478
- `hnsw m=16 ef_search=64` recall: 0.9632, 0.9632, 0.9632
- `hnsw m=16 ef_search=64` throughput_per_second: 1,171, 1,140, 1,034
- `hnsw m=16 ef_search=256` build_seconds: 10.87, 10.87, 10.87
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.866, 1.948, 1.968
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.262, 2.794, 2.401
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.509, 3.173, 2.53
- `hnsw m=16 ef_search=256` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=256` throughput_per_second: 524.8, 489.8, 499.5
- `hnsw m=16 ef_search=512` build_seconds: 11.01, 11.01, 11.01
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.236, 3.371, 3.39
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.003, 4.589, 5.002
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.664, 5.509, 6.11
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 305.2, 288.9, 286.4
- `hnsw m=16 ef_search=1000` build_seconds: 10.96, 10.96, 10.96
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.591, 5.557, 5.691
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.974, 6.99, 7.827
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.415, 7.469, 9.403
- `hnsw m=16 ef_search=1000` recall: 0.9996, 0.9996, 0.9996
- `hnsw m=16 ef_search=1000` throughput_per_second: 179.2, 178.8, 172.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T134959Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

