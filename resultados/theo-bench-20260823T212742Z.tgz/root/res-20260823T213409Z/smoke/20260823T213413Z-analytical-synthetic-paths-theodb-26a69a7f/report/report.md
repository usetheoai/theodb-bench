# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T213413Z-analytical-synthetic-paths-theodb-26a69a7f`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 117.2 | _not measured_ | 8.667 | 9.536 | 9.603 | yes |
| sum_amount via row | 91.69 | _not measured_ | 10.96 | 11.05 | 11.06 | yes |
| group_by_category via row | 46.12 | _not measured_ | 22.06 | 22.25 | 22.26 | **no** |
| filtered_sum via row | 73.8 | _not measured_ | 13.62 | 13.93 | 13.99 | **no** |
| numeric_filtered_sum via row | 78.55 | _not measured_ | 12.82 | 13.14 | 13.17 | **no** |
| total_rows via columnar | 562 | _not measured_ | 1.842 | 1.991 | 2.004 | **no** |
| sum_amount via columnar | 276.3 | _not measured_ | 3.669 | 3.761 | 3.771 | yes |
| group_by_category via columnar | 44.4 | _not measured_ | 22.54 | 22.75 | 22.77 | yes |
| filtered_sum via columnar | 45.34 | _not measured_ | 22.26 | 22.6 | 22.63 | **no** |
| numeric_filtered_sum via columnar | 170.8 | _not measured_ | 5.877 | 5.969 | 5.997 | yes |
| total_rows via parquet | 1.925 | _not measured_ | 520.7 | 522.5 | 522.6 | yes |
| sum_amount via parquet | 1.74 | _not measured_ | 575.3 | 579.1 | 579.4 | yes |
| group_by_category via parquet | 1.638 | _not measured_ | 612.6 | 618.4 | 618.9 | yes |
| filtered_sum via parquet | 1.808 | _not measured_ | 556.2 | 560.1 | 560.4 | yes |
| numeric_filtered_sum via parquet | 1.779 | _not measured_ | 563.9 | 569.6 | 570.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.051; latency_p99_ms cv=0.053
- `filtered_sum via row`: latency_p50_ms cv=0.072; latency_p95_ms cv=0.064; latency_p99_ms cv=0.064; throughput_per_second cv=0.067
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.074; latency_p95_ms cv=0.064; latency_p99_ms cv=0.063; throughput_per_second cv=0.064
- `total_rows via columnar`: latency_p95_ms cv=0.064; latency_p99_ms cv=0.066; throughput_per_second cv=0.054
- `filtered_sum via columnar`: latency_p50_ms cv=0.075; latency_p95_ms cv=0.064; latency_p99_ms cv=0.063; throughput_per_second cv=0.076

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 8.619, 8.667, 9.056
- `total_rows via row` latency_p95_ms: 9.536, 9.302, 9.559
- `total_rows via row` latency_p99_ms: 9.617, 9.359, 9.603
- `total_rows via row` throughput_per_second: 117.2, 119.4, 117.1
- `sum_amount via row` latency_p50_ms: 11.04, 10.76, 10.96
- `sum_amount via row` latency_p95_ms: 11.23, 10.77, 11.05
- `sum_amount via row` latency_p99_ms: 11.25, 10.77, 11.06
- `sum_amount via row` throughput_per_second: 91.69, 93.57, 91.42
- `group_by_category via row` latency_p50_ms: 22.31, 22.06, 21.04
- `group_by_category via row` latency_p95_ms: 23.49, 22.25, 21.2
- `group_by_category via row` latency_p99_ms: 23.59, 22.26, 21.21
- `group_by_category via row` throughput_per_second: 45.17, 46.12, 48.01
- `filtered_sum via row` latency_p50_ms: 15.12, 13.22, 13.62
- `filtered_sum via row` latency_p95_ms: 15.36, 13.93, 13.65
- `filtered_sum via row` latency_p99_ms: 15.38, 13.99, 13.65
- `filtered_sum via row` throughput_per_second: 66.73, 76.03, 73.8
- `numeric_filtered_sum via row` latency_p50_ms: 14.39, 12.57, 12.82
- `numeric_filtered_sum via row` latency_p95_ms: 14.43, 12.8, 13.14
- `numeric_filtered_sum via row` latency_p99_ms: 14.44, 12.83, 13.17
- `numeric_filtered_sum via row` throughput_per_second: 70.66, 79.62, 78.55
- `total_rows via columnar` latency_p50_ms: 1.892, 1.749, 1.842
- `total_rows via columnar` latency_p95_ms: 2.109, 1.854, 1.991
- `total_rows via columnar` latency_p99_ms: 2.128, 1.864, 2.004
- `total_rows via columnar` throughput_per_second: 542.9, 603.4, 562
- `sum_amount via columnar` latency_p50_ms: 3.669, 3.654, 3.671
- `sum_amount via columnar` latency_p95_ms: 3.781, 3.761, 3.744
- `sum_amount via columnar` latency_p99_ms: 3.791, 3.771, 3.751
- `sum_amount via columnar` throughput_per_second: 276.3, 275.1, 277.8
- `group_by_category via columnar` latency_p50_ms: 22.03, 22.54, 23.65
- `group_by_category via columnar` latency_p95_ms: 22.39, 22.75, 23.67
- `group_by_category via columnar` latency_p99_ms: 22.42, 22.77, 23.67
- `group_by_category via columnar` throughput_per_second: 45.56, 44.4, 42.53
- `filtered_sum via columnar` latency_p50_ms: 19.91, 22.26, 23.06
- `filtered_sum via columnar` latency_p95_ms: 20.59, 22.6, 23.34
- `filtered_sum via columnar` latency_p99_ms: 20.65, 22.63, 23.37
- `filtered_sum via columnar` throughput_per_second: 50.53, 45.34, 43.8
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.877, 5.663, 5.989
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.896, 5.969, 6.036
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.898, 5.997, 6.04
- `numeric_filtered_sum via columnar` throughput_per_second: 170.8, 178.5, 169.3
- `total_rows via parquet` latency_p50_ms: 516.5, 520.7, 525.9
- `total_rows via parquet` latency_p95_ms: 521.7, 522.5, 529
- `total_rows via parquet` latency_p99_ms: 522.2, 522.6, 529.2
- `total_rows via parquet` throughput_per_second: 1.939, 1.925, 1.902
- `sum_amount via parquet` latency_p50_ms: 572.2, 575.3, 578.4
- `sum_amount via parquet` latency_p95_ms: 577.7, 579.1, 589.2
- `sum_amount via parquet` latency_p99_ms: 578.2, 579.4, 590.2
- `sum_amount via parquet` throughput_per_second: 1.756, 1.74, 1.732
- `group_by_category via parquet` latency_p50_ms: 604, 612.6, 618.5
- `group_by_category via parquet` latency_p95_ms: 605.3, 618.4, 622.9
- `group_by_category via parquet` latency_p99_ms: 605.4, 618.9, 623.3
- `group_by_category via parquet` throughput_per_second: 1.658, 1.638, 1.627
- `filtered_sum via parquet` latency_p50_ms: 553.8, 563.6, 556.2
- `filtered_sum via parquet` latency_p95_ms: 559.2, 567.1, 560.1
- `filtered_sum via parquet` latency_p99_ms: 559.7, 567.4, 560.4
- `filtered_sum via parquet` throughput_per_second: 1.829, 1.802, 1.808
- `numeric_filtered_sum via parquet` latency_p50_ms: 560.6, 570.3, 563.9
- `numeric_filtered_sum via parquet` latency_p95_ms: 569.6, 570.7, 564.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 570.4, 570.8, 564.4
- `numeric_filtered_sum via parquet` throughput_per_second: 1.804, 1.76, 1.779

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T212742Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424501760 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d4f2b89d9ffd4df3794bbe4bf0bb1eb456134171 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

