# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T213503Z-vector-sift-hnsw-theodb-0c9a1de7`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,508 | 0.872 | 0.6049 | 0.7375 | 0.8422 | yes |
| hnsw m=16 ef_search=64 | 1,267 | 0.961 | 0.7392 | 0.8627 | 0.9639 | **no** |
| hnsw m=16 ef_search=256 | 505.6 | 0.9952 | 1.949 | 2.32 | 2.54 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.071

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 8.652, 8.652, 8.652
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6086, 0.6049, 0.6023
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7383, 0.7375, 0.7213
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8154, 0.8547, 0.8422
- `hnsw m=16 ef_search=16` recall: 0.872, 0.872, 0.872
- `hnsw m=16 ef_search=16` throughput_per_second: 1,495, 1,508, 1,514
- `hnsw m=16 ef_search=64` build_seconds: 8.632, 8.632, 8.632
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7392, 0.7509, 0.7254
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8627, 0.9186, 0.8623
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9347, 1.068, 0.9639
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,267, 1,188, 1,279
- `hnsw m=16 ef_search=256` build_seconds: 8.625, 8.625, 8.625
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.908, 1.994, 1.949
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.286, 2.419, 2.32
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.423, 2.632, 2.54
- `hnsw m=16 ef_search=256` recall: 0.9952, 0.9952, 0.9952
- `hnsw m=16 ef_search=256` throughput_per_second: 517.5, 489.9, 505.6

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T212742Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424501760 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d4f2b89d9ffd4df3794bbe4bf0bb1eb456134171 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

