# vector/sift/pg-scann-quantizer on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T223307Z-vector-sift-pg-scann-quantizer-theodb-9ae72dfc`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20 | 804.4 | 0.8172 | 1.154 | 1.306 | 1.382 | yes |
| ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20 | 757.9 | 0.927 | 1.183 | 1.344 | 1.52 | **no** |
| ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20 | 699.7 | 0.957 | 1.327 | 1.493 | 1.592 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20`: latency_p99_ms cv=0.094

### Repetitions

Every repetition is retained:

- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` build_seconds: 54.64, 54.64, 54.64
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` index_size_bytes: 1.737e+07, 1.737e+07, 1.737e+07
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p50_ms: 1.106, 1.158, 1.154
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p95_ms: 1.219, 1.311, 1.306
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p99_ms: 1.294, 1.382, 1.402
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` recall: 0.8172, 0.8172, 0.8172
- `ivfflat lists=316 pq_bits=4 pq_subspaces=16 refine=1 separate_storage=1 over_fetch=2 probes=20` throughput_per_second: 839.5, 783.8, 804.4
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` build_seconds: 54.48, 54.48, 54.48
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` index_size_bytes: 1.822e+07, 1.822e+07, 1.822e+07
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p50_ms: 1.214, 1.183, 1.174
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p95_ms: 1.355, 1.344, 1.302
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p99_ms: 1.52, 1.715, 1.429
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` recall: 0.927, 0.927, 0.927
- `ivfflat lists=316 pq_bits=4 pq_subspaces=32 refine=1 separate_storage=1 over_fetch=2 probes=20` throughput_per_second: 757.9, 754.3, 792.8
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` build_seconds: 58.65, 58.65, 58.65
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` index_size_bytes: 2.019e+07, 2.019e+07, 2.019e+07
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p50_ms: 1.333, 1.327, 1.319
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p95_ms: 1.497, 1.482, 1.493
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` latency_p99_ms: 1.599, 1.592, 1.564
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` recall: 0.957, 0.957, 0.957
- `ivfflat lists=316 pq_bits=4 pq_subspaces=64 refine=1 separate_storage=1 over_fetch=2 probes=20` throughput_per_second: 693.4, 701.1, 699.7

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T222346Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d878971b1a75b88a8b98521e63b0995685e45ea3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

