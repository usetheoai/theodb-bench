# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T223203Z-analytical-synthetic-paths-theodb-e116b4d5`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 93.89 | _not measured_ | 11.53 | 12.13 | 12.24 | **no** |
| sum_amount via row | 73.43 | _not measured_ | 13.81 | 15.5 | 15.51 | **no** |
| group_by_category via row | 35.31 | _not measured_ | 29.14 | 30.09 | 30.14 | **no** |
| filtered_sum via row | 54.2 | _not measured_ | 18.77 | 19.31 | 19.33 | yes |
| numeric_filtered_sum via row | 58.54 | _not measured_ | 17.19 | 17.57 | 17.6 | **no** |
| total_rows via columnar | 451.7 | _not measured_ | 2.396 | 2.526 | 2.537 | yes |
| sum_amount via columnar | 208.6 | _not measured_ | 4.812 | 4.856 | 4.859 | yes |
| group_by_category via columnar | 37.32 | _not measured_ | 26.98 | 28.79 | 28.84 | yes |
| filtered_sum via columnar | 36.69 | _not measured_ | 28.21 | 28.69 | 28.73 | **no** |
| numeric_filtered_sum via columnar | 127.2 | _not measured_ | 7.886 | 7.906 | 7.907 | yes |
| total_rows via parquet | 1.634 | _not measured_ | 631.4 | 639.4 | 640.1 | yes |
| sum_amount via parquet | 1.48 | _not measured_ | 687.9 | 717.6 | 720 | yes |
| group_by_category via parquet | 1.399 | _not measured_ | 735.6 | 745.3 | 746.2 | yes |
| filtered_sum via parquet | 1.496 | _not measured_ | 675.5 | 681.2 | 682.3 | yes |
| numeric_filtered_sum via parquet | 1.482 | _not measured_ | 676.9 | 682.5 | 683.1 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p95_ms cv=0.074; latency_p99_ms cv=0.078
- `sum_amount via row`: latency_p50_ms cv=0.073; latency_p95_ms cv=0.081; latency_p99_ms cv=0.089
- `group_by_category via row`: latency_p95_ms cv=0.059; latency_p99_ms cv=0.060
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.064; latency_p99_ms cv=0.068
- `filtered_sum via columnar`: latency_p95_ms cv=0.073; latency_p99_ms cv=0.076

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 11.53, 10.9, 11.94
- `total_rows via row` latency_p95_ms: 11.9, 12.13, 13.62
- `total_rows via row` latency_p99_ms: 11.94, 12.24, 13.76
- `total_rows via row` throughput_per_second: 89.89, 93.89, 94.61
- `sum_amount via row` latency_p50_ms: 13.81, 13.48, 15.43
- `sum_amount via row` latency_p95_ms: 17.52, 15.1, 15.5
- `sum_amount via row` latency_p99_ms: 17.85, 15.24, 15.51
- `sum_amount via row` throughput_per_second: 73.43, 76.62, 72.86
- `group_by_category via row` latency_p50_ms: 29.52, 27.08, 29.14
- `group_by_category via row` latency_p95_ms: 30.09, 27.14, 30.1
- `group_by_category via row` latency_p99_ms: 30.14, 27.15, 30.19
- `group_by_category via row` throughput_per_second: 34.31, 37.66, 35.31
- `filtered_sum via row` latency_p50_ms: 18.74, 19.03, 18.77
- `filtered_sum via row` latency_p95_ms: 18.94, 19.31, 19.67
- `filtered_sum via row` latency_p99_ms: 18.96, 19.33, 19.75
- `filtered_sum via row` throughput_per_second: 53.61, 54.2, 54.2
- `numeric_filtered_sum via row` latency_p50_ms: 17.19, 17.1, 17.56
- `numeric_filtered_sum via row` latency_p95_ms: 17.57, 17.4, 19.48
- `numeric_filtered_sum via row` latency_p99_ms: 17.6, 17.43, 19.65
- `numeric_filtered_sum via row` throughput_per_second: 58.49, 60.71, 58.54
- `total_rows via columnar` latency_p50_ms: 2.251, 2.396, 2.422
- `total_rows via columnar` latency_p95_ms: 2.429, 2.526, 2.563
- `total_rows via columnar` latency_p99_ms: 2.445, 2.537, 2.576
- `total_rows via columnar` throughput_per_second: 451.7, 469.3, 445.5
- `sum_amount via columnar` latency_p50_ms: 4.812, 4.823, 4.768
- `sum_amount via columnar` latency_p95_ms: 4.935, 4.856, 4.777
- `sum_amount via columnar` latency_p99_ms: 4.945, 4.859, 4.778
- `sum_amount via columnar` throughput_per_second: 208.6, 207.6, 211.8
- `group_by_category via columnar` latency_p50_ms: 26.75, 28.21, 26.98
- `group_by_category via columnar` latency_p95_ms: 29.69, 28.79, 27.23
- `group_by_category via columnar` latency_p99_ms: 29.95, 28.84, 27.25
- `group_by_category via columnar` throughput_per_second: 39.71, 36.78, 37.32
- `filtered_sum via columnar` latency_p50_ms: 28.91, 28.21, 26.66
- `filtered_sum via columnar` latency_p95_ms: 31.14, 28.69, 26.92
- `filtered_sum via columnar` latency_p99_ms: 31.33, 28.73, 26.94
- `filtered_sum via columnar` throughput_per_second: 36.69, 36.19, 38.26
- `numeric_filtered_sum via columnar` latency_p50_ms: 7.886, 7.979, 7.676
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.906, 8.268, 7.796
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.907, 8.293, 7.807
- `numeric_filtered_sum via columnar` throughput_per_second: 127.2, 126.5, 131.2
- `total_rows via parquet` latency_p50_ms: 636.7, 631.4, 617.1
- `total_rows via parquet` latency_p95_ms: 661.6, 639.4, 620.2
- `total_rows via parquet` latency_p99_ms: 663.8, 640.1, 620.4
- `total_rows via parquet` throughput_per_second: 1.573, 1.651, 1.634
- `sum_amount via parquet` latency_p50_ms: 715.8, 687.9, 669.5
- `sum_amount via parquet` latency_p95_ms: 719.6, 717.6, 693.3
- `sum_amount via parquet` latency_p99_ms: 720, 720.2, 695.4
- `sum_amount via parquet` throughput_per_second: 1.453, 1.48, 1.497
- `group_by_category via parquet` latency_p50_ms: 750.7, 735.6, 712.3
- `group_by_category via parquet` latency_p95_ms: 759, 745.3, 736.8
- `group_by_category via parquet` latency_p99_ms: 759.7, 746.2, 739
- `group_by_category via parquet` throughput_per_second: 1.382, 1.399, 1.409
- `filtered_sum via parquet` latency_p50_ms: 669, 682.4, 675.5
- `filtered_sum via parquet` latency_p95_ms: 681.2, 687.1, 678.1
- `filtered_sum via parquet` latency_p99_ms: 682.3, 687.6, 678.3
- `filtered_sum via parquet` throughput_per_second: 1.496, 1.471, 1.512
- `numeric_filtered_sum via parquet` latency_p50_ms: 694.9, 676.9, 675.8
- `numeric_filtered_sum via parquet` latency_p95_ms: 701.6, 678.6, 682.5
- `numeric_filtered_sum via parquet` latency_p99_ms: 702.2, 678.7, 683.1
- `numeric_filtered_sum via parquet` throughput_per_second: 1.478, 1.482, 1.505

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T222346Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d878971b1a75b88a8b98521e63b0995685e45ea3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

