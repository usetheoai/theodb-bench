# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T234419Z-analytical-synthetic-paths-theodb-d14a265c`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 116.3 | _not measured_ | 8.707 | 8.878 | 8.894 | yes |
| sum_amount via row | 90.04 | _not measured_ | 11.11 | 11.37 | 11.37 | yes |
| group_by_category via row | 45.63 | _not measured_ | 22.41 | 23.52 | 23.61 | **no** |
| filtered_sum via row | 69.86 | _not measured_ | 14.33 | 14.5 | 14.52 | yes |
| numeric_filtered_sum via row | 75.3 | _not measured_ | 13.45 | 14.09 | 14.14 | **no** |
| total_rows via columnar | 530.4 | _not measured_ | 2.036 | 2.124 | 2.127 | **no** |
| sum_amount via columnar | 253.1 | _not measured_ | 3.995 | 4.168 | 4.168 | yes |
| group_by_category via columnar | 46.61 | _not measured_ | 21.53 | 21.87 | 21.9 | **no** |
| filtered_sum via columnar | 46.41 | _not measured_ | 21.57 | 21.61 | 21.62 | **no** |
| numeric_filtered_sum via columnar | 152.6 | _not measured_ | 6.645 | 6.768 | 6.768 | yes |
| total_rows via parquet | 2.062 | _not measured_ | 486.5 | 488.5 | 488.5 | yes |
| sum_amount via parquet | 1.861 | _not measured_ | 541.6 | 543.1 | 543.2 | yes |
| group_by_category via parquet | 1.726 | _not measured_ | 582.6 | 583.1 | 583.2 | yes |
| filtered_sum via parquet | 1.902 | _not measured_ | 526.1 | 529.1 | 529.4 | yes |
| numeric_filtered_sum via parquet | 1.891 | _not measured_ | 534.2 | 537.5 | 537.6 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.329; latency_p99_ms cv=0.352
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.205; latency_p99_ms cv=0.220
- `total_rows via columnar`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.054; latency_p99_ms cv=0.055
- `group_by_category via columnar`: latency_p50_ms cv=0.059; throughput_per_second cv=0.066
- `filtered_sum via columnar`: latency_p50_ms cv=0.066; latency_p95_ms cv=0.053; latency_p99_ms cv=0.052; throughput_per_second cv=0.072

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 8.707, 8.912, 8.609
- `total_rows via row` latency_p95_ms: 8.878, 8.978, 8.66
- `total_rows via row` latency_p99_ms: 8.894, 8.984, 8.664
- `total_rows via row` throughput_per_second: 116.3, 113.1, 116.5
- `sum_amount via row` latency_p50_ms: 11.05, 11.32, 11.11
- `sum_amount via row` latency_p95_ms: 11.38, 11.37, 11.35
- `sum_amount via row` latency_p99_ms: 11.41, 11.37, 11.37
- `sum_amount via row` throughput_per_second: 91.53, 89.21, 90.04
- `group_by_category via row` latency_p50_ms: 22.41, 22.11, 22.5
- `group_by_category via row` latency_p95_ms: 22.73, 39.38, 23.52
- `group_by_category via row` latency_p99_ms: 22.76, 40.91, 23.61
- `group_by_category via row` throughput_per_second: 45.06, 45.72, 45.63
- `filtered_sum via row` latency_p50_ms: 14.57, 14.33, 14.27
- `filtered_sum via row` latency_p95_ms: 14.74, 14.5, 14.41
- `filtered_sum via row` latency_p99_ms: 14.75, 14.52, 14.42
- `filtered_sum via row` throughput_per_second: 69.23, 69.86, 70.14
- `numeric_filtered_sum via row` latency_p50_ms: 13.53, 13.45, 13.4
- `numeric_filtered_sum via row` latency_p95_ms: 14.09, 19.26, 13.42
- `numeric_filtered_sum via row` latency_p99_ms: 14.14, 19.77, 13.42
- `numeric_filtered_sum via row` throughput_per_second: 75.3, 74.56, 75.55
- `total_rows via columnar` latency_p50_ms: 2.087, 1.873, 2.036
- `total_rows via columnar` latency_p95_ms: 2.124, 2.02, 2.249
- `total_rows via columnar` latency_p99_ms: 2.127, 2.033, 2.268
- `total_rows via columnar` throughput_per_second: 530.4, 561.6, 523.5
- `sum_amount via columnar` latency_p50_ms: 3.995, 3.991, 4.167
- `sum_amount via columnar` latency_p95_ms: 4.015, 4.21, 4.168
- `sum_amount via columnar` latency_p99_ms: 4.017, 4.23, 4.168
- `sum_amount via columnar` throughput_per_second: 253.1, 260.2, 243.7
- `group_by_category via columnar` latency_p50_ms: 19.56, 21.53, 21.85
- `group_by_category via columnar` latency_p95_ms: 20.82, 21.87, 22.03
- `group_by_category via columnar` latency_p99_ms: 20.93, 21.9, 22.04
- `group_by_category via columnar` throughput_per_second: 51.66, 46.61, 45.81
- `filtered_sum via columnar` latency_p50_ms: 19.52, 21.57, 22.17
- `filtered_sum via columnar` latency_p95_ms: 20.1, 21.61, 22.31
- `filtered_sum via columnar` latency_p99_ms: 20.15, 21.62, 22.32
- `filtered_sum via columnar` throughput_per_second: 51.8, 46.41, 45.35
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.767, 6.551, 6.645
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.768, 6.871, 6.657
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.768, 6.9, 6.659
- `numeric_filtered_sum via columnar` throughput_per_second: 151.2, 153.1, 152.6
- `total_rows via parquet` latency_p50_ms: 485.7, 486.5, 488
- `total_rows via parquet` latency_p95_ms: 486.9, 499.8, 488.5
- `total_rows via parquet` latency_p99_ms: 487, 501, 488.5
- `total_rows via parquet` throughput_per_second: 2.062, 2.068, 2.057
- `sum_amount via parquet` latency_p50_ms: 541.7, 541.6, 532.7
- `sum_amount via parquet` latency_p95_ms: 543.1, 551.4, 535.3
- `sum_amount via parquet` latency_p99_ms: 543.2, 552.3, 535.5
- `sum_amount via parquet` throughput_per_second: 1.856, 1.861, 1.879
- `group_by_category via parquet` latency_p50_ms: 582.6, 584.6, 573.8
- `group_by_category via parquet` latency_p95_ms: 583.1, 585.2, 574.7
- `group_by_category via parquet` latency_p99_ms: 583.2, 585.3, 574.8
- `group_by_category via parquet` throughput_per_second: 1.726, 1.719, 1.748
- `filtered_sum via parquet` latency_p50_ms: 525.6, 531.8, 526.1
- `filtered_sum via parquet` latency_p95_ms: 527.5, 535.6, 529.1
- `filtered_sum via parquet` latency_p99_ms: 527.7, 536, 529.4
- `filtered_sum via parquet` throughput_per_second: 1.918, 1.887, 1.902
- `numeric_filtered_sum via parquet` latency_p50_ms: 529.4, 536.5, 534.2
- `numeric_filtered_sum via parquet` latency_p95_ms: 530.7, 537.5, 539.6
- `numeric_filtered_sum via parquet` latency_p99_ms: 530.9, 537.6, 540.1
- `numeric_filtered_sum via parquet` throughput_per_second: 1.899, 1.887, 1.891

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T233752Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e3a2d470d700437bfb74fb5b685bb4f7dd5a0304 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

