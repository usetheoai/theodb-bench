# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T234510Z-vector-sift-hnsw-theodb-806517e0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,338 | 0.8674 | 0.6902 | 0.8629 | 0.9814 | **no** |
| hnsw m=16 ef_search=64 | 1,136 | 0.9612 | 0.8298 | 0.9985 | 1.31 | **no** |
| hnsw m=16 ef_search=256 | 465.9 | 0.996 | 2.152 | 2.634 | 2.847 | **no** |
| hnsw m=16 ef_search=512 | 267 | 0.9964 | 3.752 | 4.696 | 5.029 | yes |
| hnsw m=16 ef_search=1000 | 154.1 | 0.9972 | 6.508 | 8.079 | 8.672 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p95_ms cv=0.062; latency_p99_ms cv=0.282
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.133
- `hnsw m=16 ef_search=256`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.263

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 7.198, 7.198, 7.198
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6902, 0.7043, 0.6824
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.8475, 0.95, 0.8629
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.9754, 1.548, 0.9814
- `hnsw m=16 ef_search=16` recall: 0.8674, 0.8674, 0.8674
- `hnsw m=16 ef_search=16` throughput_per_second: 1,341, 1,271, 1,338
- `hnsw m=16 ef_search=64` build_seconds: 7.133, 7.133, 7.133
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.8292, 0.8428, 0.8298
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9985, 1.03, 0.9819
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.31, 1.356, 1.05
- `hnsw m=16 ef_search=64` recall: 0.9612, 0.9612, 0.9612
- `hnsw m=16 ef_search=64` throughput_per_second: 1,136, 1,072, 1,143
- `hnsw m=16 ef_search=256` build_seconds: 7.092, 7.092, 7.092
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.169, 2.152, 2.117
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.849, 2.575, 2.634
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.324, 2.781, 2.847
- `hnsw m=16 ef_search=256` recall: 0.996, 0.996, 0.996
- `hnsw m=16 ef_search=256` throughput_per_second: 445.4, 465.9, 468.2
- `hnsw m=16 ef_search=512` build_seconds: 7.166, 7.166, 7.166
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.744, 3.752, 3.762
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.645, 4.696, 4.784
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.986, 5.151, 5.029
- `hnsw m=16 ef_search=512` recall: 0.9964, 0.9964, 0.9964
- `hnsw m=16 ef_search=512` throughput_per_second: 267.2, 267, 263.6
- `hnsw m=16 ef_search=1000` build_seconds: 7.15, 7.15, 7.15
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 6.508, 6.57, 6.49
- `hnsw m=16 ef_search=1000` latency_p95_ms: 8.079, 8.056, 8.187
- `hnsw m=16 ef_search=1000` latency_p99_ms: 8.454, 8.8, 8.672
- `hnsw m=16 ef_search=1000` recall: 0.9972, 0.9972, 0.9972
- `hnsw m=16 ef_search=1000` throughput_per_second: 154.5, 154.1, 153.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T233752Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e3a2d470d700437bfb74fb5b685bb4f7dd5a0304 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

