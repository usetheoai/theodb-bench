# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T153517Z-vector-sift1m-hnsw-theodb-7a08928e`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 708.7 | 0.898 | 1.365 | 1.648 | 1.822 | yes |
| hnsw m=16 ef_search=256 | 271.9 | 0.9894 | 3.704 | 4.335 | 4.704 | yes |

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 157.4, 157.4, 157.4
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.365, 1.366, 1.353
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.615, 1.664, 1.648
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.765, 1.842, 1.822
- `hnsw m=16 ef_search=64` recall: 0.898, 0.898, 0.898
- `hnsw m=16 ef_search=64` throughput_per_second: 708.7, 704.6, 710.1
- `hnsw m=16 ef_search=256` build_seconds: 157, 157, 157
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.653, 3.704, 3.704
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.424, 4.335, 4.316
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.709, 4.667, 4.704
- `hnsw m=16 ef_search=256` recall: 0.9894, 0.9894, 0.9894
- `hnsw m=16 ef_search=256` throughput_per_second: 274.9, 269.2, 271.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T152258Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

