# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T153424Z-analytical-synthetic-paths-theodb-e8043a22`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 106.2 | _not measured_ | 9.476 | 9.961 | 10 | yes |
| sum_amount via row | 84.32 | _not measured_ | 11.96 | 12.03 | 12.04 | yes |
| group_by_category via row | 44.03 | _not measured_ | 23.39 | 23.95 | 24 | **no** |
| filtered_sum via row | 72.75 | _not measured_ | 14.56 | 14.65 | 14.66 | **no** |
| numeric_filtered_sum via row | 76.61 | _not measured_ | 13.13 | 13.21 | 13.21 | **no** |
| total_rows via columnar | 577.3 | _not measured_ | 1.822 | 1.908 | 1.92 | yes |
| sum_amount via columnar | 278.4 | _not measured_ | 3.622 | 3.899 | 3.925 | **no** |
| group_by_category via columnar | 43.63 | _not measured_ | 22.97 | 23.23 | 23.26 | yes |
| filtered_sum via columnar | 44.62 | _not measured_ | 22.84 | 23.03 | 23.04 | **no** |
| numeric_filtered_sum via columnar | 159.5 | _not measured_ | 6.495 | 6.674 | 6.69 | **no** |
| total_rows via parquet | 1.885 | _not measured_ | 536.3 | 539.4 | 539.6 | yes |
| sum_amount via parquet | 1.716 | _not measured_ | 586 | 595.9 | 596.8 | yes |
| group_by_category via parquet | 1.622 | _not measured_ | 619.3 | 622.7 | 623 | yes |
| filtered_sum via parquet | 1.765 | _not measured_ | 568.9 | 570.4 | 570.6 | yes |
| numeric_filtered_sum via parquet | 1.728 | _not measured_ | 580 | 585.3 | 586.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.310; latency_p99_ms cv=0.331
- `filtered_sum via row`: latency_p50_ms cv=0.067; latency_p95_ms cv=0.063; latency_p99_ms cv=0.063; throughput_per_second cv=0.055
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.055; latency_p95_ms cv=0.076; latency_p99_ms cv=0.078
- `sum_amount via columnar`: latency_p50_ms cv=0.207; latency_p95_ms cv=0.197; latency_p99_ms cv=0.197
- `filtered_sum via columnar`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.056; latency_p99_ms cv=0.056; throughput_per_second cv=0.058
- `numeric_filtered_sum via columnar`: latency_p50_ms cv=0.068; latency_p95_ms cv=0.104; latency_p99_ms cv=0.108; throughput_per_second cv=0.065

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.476, 9.343, 10.08
- `total_rows via row` latency_p95_ms: 9.961, 9.887, 10.29
- `total_rows via row` latency_p99_ms: 10, 9.935, 10.31
- `total_rows via row` throughput_per_second: 106.2, 109.4, 101
- `sum_amount via row` latency_p50_ms: 11.96, 12.46, 11.38
- `sum_amount via row` latency_p95_ms: 12.03, 12.6, 11.56
- `sum_amount via row` latency_p99_ms: 12.04, 12.61, 11.58
- `sum_amount via row` throughput_per_second: 84.32, 81.13, 88.65
- `group_by_category via row` latency_p50_ms: 23.39, 23.44, 22.49
- `group_by_category via row` latency_p95_ms: 23.95, 38.54, 22.73
- `group_by_category via row` latency_p99_ms: 24, 39.88, 22.75
- `group_by_category via row` throughput_per_second: 43.84, 44.03, 46.19
- `filtered_sum via row` latency_p50_ms: 14.56, 15.61, 13.64
- `filtered_sum via row` latency_p95_ms: 14.65, 15.67, 13.8
- `filtered_sum via row` latency_p99_ms: 14.66, 15.67, 13.82
- `filtered_sum via row` throughput_per_second: 72.75, 66.74, 74.01
- `numeric_filtered_sum via row` latency_p50_ms: 13.13, 14.18, 12.76
- `numeric_filtered_sum via row` latency_p95_ms: 13.21, 14.74, 12.77
- `numeric_filtered_sum via row` latency_p99_ms: 13.21, 14.79, 12.77
- `numeric_filtered_sum via row` throughput_per_second: 76.61, 74.16, 78.61
- `total_rows via columnar` latency_p50_ms: 1.78, 1.822, 1.835
- `total_rows via columnar` latency_p95_ms: 1.908, 1.863, 1.961
- `total_rows via columnar` latency_p99_ms: 1.92, 1.866, 1.972
- `total_rows via columnar` throughput_per_second: 577.3, 594, 551.1
- `sum_amount via columnar` latency_p50_ms: 5.091, 3.608, 3.622
- `sum_amount via columnar` latency_p95_ms: 5.283, 3.899, 3.736
- `sum_amount via columnar` latency_p99_ms: 5.3, 3.925, 3.746
- `sum_amount via columnar` throughput_per_second: 264.8, 278.4, 286.5
- `group_by_category via columnar` latency_p50_ms: 22.15, 23.32, 22.97
- `group_by_category via columnar` latency_p95_ms: 22.15, 23.47, 23.23
- `group_by_category via columnar` latency_p99_ms: 22.15, 23.48, 23.26
- `group_by_category via columnar` throughput_per_second: 45.51, 42.9, 43.63
- `filtered_sum via columnar` latency_p50_ms: 20.72, 22.9, 22.84
- `filtered_sum via columnar` latency_p95_ms: 20.88, 23.03, 23.05
- `filtered_sum via columnar` latency_p99_ms: 20.9, 23.04, 23.06
- `filtered_sum via columnar` throughput_per_second: 48.82, 43.96, 44.62
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.819, 6.495, 6.617
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.89, 6.674, 7.265
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.896, 6.69, 7.322
- `numeric_filtered_sum via columnar` throughput_per_second: 174.7, 159.5, 154.3
- `total_rows via parquet` latency_p50_ms: 536.3, 530.8, 540.9
- `total_rows via parquet` latency_p95_ms: 539.4, 534.7, 546.1
- `total_rows via parquet` latency_p99_ms: 539.6, 535, 546.6
- `total_rows via parquet` throughput_per_second: 1.895, 1.885, 1.869
- `sum_amount via parquet` latency_p50_ms: 580.5, 586, 589.5
- `sum_amount via parquet` latency_p95_ms: 581.2, 595.9, 598.5
- `sum_amount via parquet` latency_p99_ms: 581.2, 596.8, 599.3
- `sum_amount via parquet` throughput_per_second: 1.724, 1.716, 1.703
- `group_by_category via parquet` latency_p50_ms: 619.3, 612.5, 629.6
- `group_by_category via parquet` latency_p95_ms: 622.7, 615.2, 635.7
- `group_by_category via parquet` latency_p99_ms: 623, 615.5, 636.3
- `group_by_category via parquet` throughput_per_second: 1.622, 1.652, 1.592
- `filtered_sum via parquet` latency_p50_ms: 562.6, 568.9, 577.4
- `filtered_sum via parquet` latency_p95_ms: 569.8, 570.4, 582.3
- `filtered_sum via parquet` latency_p99_ms: 570.5, 570.6, 582.8
- `filtered_sum via parquet` throughput_per_second: 1.787, 1.765, 1.74
- `numeric_filtered_sum via parquet` latency_p50_ms: 573.9, 580, 607.9
- `numeric_filtered_sum via parquet` latency_p95_ms: 585.3, 583.3, 609.6
- `numeric_filtered_sum via parquet` latency_p99_ms: 586.4, 583.6, 609.7
- `numeric_filtered_sum via parquet` throughput_per_second: 1.747, 1.728, 1.646

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T152258Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

