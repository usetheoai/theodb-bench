# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T154218Z-vector-sift1m-hnsw-theodb-52223b1f`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 701.8 | 0.9004 | 1.381 | 1.666 | 1.839 | **no** |
| hnsw m=16 ef_search=256 | 279.3 | 0.9892 | 3.566 | 4.254 | 4.523 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.053

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 204, 204, 204
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.261, 1.381, 1.388
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.593, 1.678, 1.666
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.839, 1.863, 1.805
- `hnsw m=16 ef_search=64` recall: 0.9004, 0.9004, 0.9004
- `hnsw m=16 ef_search=64` throughput_per_second: 749.2, 701.8, 698.8
- `hnsw m=16 ef_search=256` build_seconds: 201.9, 201.9, 201.9
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.614, 3.477, 3.566
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.382, 4.139, 4.254
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.706, 4.523, 4.427
- `hnsw m=16 ef_search=256` recall: 0.9892, 0.9892, 0.9892
- `hnsw m=16 ef_search=256` throughput_per_second: 275.4, 284, 279.3

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T152258Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

