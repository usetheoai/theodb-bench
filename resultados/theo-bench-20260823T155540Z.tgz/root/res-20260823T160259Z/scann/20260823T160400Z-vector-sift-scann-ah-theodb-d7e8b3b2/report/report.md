# vector/sift/scann-ah on theodb

**Status:** INVALID · **Profile:** research · **Run:** `20260823T160400Z-vector-sift-scann-ah-theodb-d7e8b3b2`

> This run is **INVALID**. It failed protocol validation, which says nothing about whether the numbers were favourable -- invalidation is never based on the measured outcome.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400 | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |

### Repetitions

Every repetition is retained:


## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | UNAVAILABLE | no | benchmark declared no expected operation count |
| repetitions_completed | FAIL | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | FAIL | yes | approximate retrieval reported without a quality axis |
| clean_source_tree | PASS | no |  |

Invalidated by: `repetitions_completed`, `quality_reported`

Invalidation is based on protocol criteria, never on whether the numbers looked good.

## Environment

- Host: theo-bench-20260823T155540Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

