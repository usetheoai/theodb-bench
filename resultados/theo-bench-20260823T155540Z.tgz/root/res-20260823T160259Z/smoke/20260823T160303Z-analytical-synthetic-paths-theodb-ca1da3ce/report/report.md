# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T160303Z-analytical-synthetic-paths-theodb-ca1da3ce`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 93.32 | _not measured_ | 10.76 | 10.9 | 10.92 | yes |
| sum_amount via row | 74.16 | _not measured_ | 13.76 | 13.82 | 13.82 | yes |
| group_by_category via row | 38.1 | _not measured_ | 26.51 | 26.74 | 26.76 | yes |
| filtered_sum via row | 58.82 | _not measured_ | 17.21 | 17.3 | 17.3 | yes |
| numeric_filtered_sum via row | 62.92 | _not measured_ | 16.2 | 16.31 | 16.32 | yes |
| total_rows via columnar | 500.8 | _not measured_ | 2.091 | 2.18 | 2.192 | yes |
| sum_amount via columnar | 243.4 | _not measured_ | 4.13 | 4.258 | 4.273 | yes |
| group_by_category via columnar | 37.37 | _not measured_ | 26.91 | 27.07 | 27.09 | **no** |
| filtered_sum via columnar | 38.48 | _not measured_ | 26.3 | 26.51 | 26.53 | **no** |
| numeric_filtered_sum via columnar | 138.6 | _not measured_ | 7.26 | 7.46 | 7.48 | yes |
| total_rows via parquet | 1.689 | _not measured_ | 593.3 | 595.8 | 595.8 | yes |
| sum_amount via parquet | 1.532 | _not measured_ | 653.9 | 666.4 | 667.5 | yes |
| group_by_category via parquet | 1.439 | _not measured_ | 698.1 | 701.6 | 701.9 | yes |
| filtered_sum via parquet | 1.585 | _not measured_ | 638.9 | 646.6 | 646.8 | yes |
| numeric_filtered_sum via parquet | 1.555 | _not measured_ | 647.2 | 647.9 | 648.1 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via columnar`: latency_p50_ms cv=0.066; latency_p95_ms cv=0.064; latency_p99_ms cv=0.064; throughput_per_second cv=0.072
- `filtered_sum via columnar`: latency_p50_ms cv=0.070; latency_p95_ms cv=0.072; latency_p99_ms cv=0.072; throughput_per_second cv=0.068

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 10.83, 10.74, 10.76
- `total_rows via row` latency_p95_ms: 11.66, 10.9, 10.89
- `total_rows via row` latency_p99_ms: 11.74, 10.92, 10.9
- `total_rows via row` throughput_per_second: 92.87, 93.49, 93.32
- `sum_amount via row` latency_p50_ms: 13.42, 13.76, 13.87
- `sum_amount via row` latency_p95_ms: 13.51, 13.82, 13.93
- `sum_amount via row` latency_p99_ms: 13.51, 13.82, 13.93
- `sum_amount via row` throughput_per_second: 75.06, 74.16, 73.31
- `group_by_category via row` latency_p50_ms: 26.65, 26.46, 26.51
- `group_by_category via row` latency_p95_ms: 27.18, 26.74, 26.63
- `group_by_category via row` latency_p99_ms: 27.23, 26.76, 26.64
- `group_by_category via row` throughput_per_second: 37.69, 38.1, 38.12
- `filtered_sum via row` latency_p50_ms: 17.75, 17.21, 17.02
- `filtered_sum via row` latency_p95_ms: 17.93, 17.3, 17.14
- `filtered_sum via row` latency_p99_ms: 17.95, 17.3, 17.15
- `filtered_sum via row` throughput_per_second: 57.67, 59.96, 58.82
- `numeric_filtered_sum via row` latency_p50_ms: 16.2, 16.28, 15.77
- `numeric_filtered_sum via row` latency_p95_ms: 16.31, 16.37, 15.88
- `numeric_filtered_sum via row` latency_p99_ms: 16.32, 16.37, 15.89
- `numeric_filtered_sum via row` throughput_per_second: 61.75, 62.92, 63.68
- `total_rows via columnar` latency_p50_ms: 2.124, 2.041, 2.091
- `total_rows via columnar` latency_p95_ms: 2.257, 2.18, 2.168
- `total_rows via columnar` latency_p99_ms: 2.269, 2.192, 2.175
- `total_rows via columnar` throughput_per_second: 494.2, 506.9, 500.8
- `sum_amount via columnar` latency_p50_ms: 4.089, 4.393, 4.13
- `sum_amount via columnar` latency_p95_ms: 4.258, 4.446, 4.157
- `sum_amount via columnar` latency_p99_ms: 4.273, 4.45, 4.16
- `sum_amount via columnar` throughput_per_second: 251.2, 232.5, 243.4
- `group_by_category via columnar` latency_p50_ms: 24.03, 26.91, 27.06
- `group_by_category via columnar` latency_p95_ms: 24.19, 27.07, 27.12
- `group_by_category via columnar` latency_p99_ms: 24.2, 27.09, 27.12
- `group_by_category via columnar` throughput_per_second: 42.14, 37.18, 37.37
- `filtered_sum via columnar` latency_p50_ms: 23.37, 26.3, 26.58
- `filtered_sum via columnar` latency_p95_ms: 23.63, 26.51, 27.06
- `filtered_sum via columnar` latency_p99_ms: 23.65, 26.53, 27.1
- `filtered_sum via columnar` throughput_per_second: 42.81, 38.48, 37.89
- `numeric_filtered_sum via columnar` latency_p50_ms: 7.26, 7.241, 7.302
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.303, 7.46, 7.521
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.307, 7.48, 7.54
- `numeric_filtered_sum via columnar` throughput_per_second: 138.6, 141.6, 137.2
- `total_rows via parquet` latency_p50_ms: 593.3, 595.4, 592.3
- `total_rows via parquet` latency_p95_ms: 596.6, 595.8, 595.2
- `total_rows via parquet` latency_p99_ms: 596.9, 595.8, 595.4
- `total_rows via parquet` throughput_per_second: 1.709, 1.686, 1.689
- `sum_amount via parquet` latency_p50_ms: 653.9, 651.4, 654.3
- `sum_amount via parquet` latency_p95_ms: 671.4, 654.5, 666.4
- `sum_amount via parquet` latency_p99_ms: 673, 654.8, 667.5
- `sum_amount via parquet` throughput_per_second: 1.53, 1.544, 1.532
- `group_by_category via parquet` latency_p50_ms: 697, 698.1, 711.3
- `group_by_category via parquet` latency_p95_ms: 698.5, 701.6, 711.9
- `group_by_category via parquet` latency_p99_ms: 698.6, 701.9, 712
- `group_by_category via parquet` throughput_per_second: 1.443, 1.439, 1.427
- `filtered_sum via parquet` latency_p50_ms: 638.9, 630.7, 644.9
- `filtered_sum via parquet` latency_p95_ms: 651.8, 631.8, 646.6
- `filtered_sum via parquet` latency_p99_ms: 652.9, 631.9, 646.8
- `filtered_sum via parquet` throughput_per_second: 1.585, 1.587, 1.572
- `numeric_filtered_sum via parquet` latency_p50_ms: 651.4, 647.2, 645.3
- `numeric_filtered_sum via parquet` latency_p95_ms: 655.2, 647.3, 647.9
- `numeric_filtered_sum via parquet` latency_p99_ms: 655.6, 647.3, 648.1
- `numeric_filtered_sum via parquet` throughput_per_second: 1.536, 1.555, 1.556

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T155540Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

