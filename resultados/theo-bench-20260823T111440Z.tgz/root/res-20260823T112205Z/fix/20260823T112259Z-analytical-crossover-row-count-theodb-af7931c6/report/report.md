# analytical/crossover/row-count on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T112259Z-analytical-crossover-row-count-theodb-af7931c6`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row @ 10000 linhas | 1,641 | _not measured_ | 0.6241 | 0.7095 | 0.7171 | **no** |
| sum_amount via row @ 10000 linhas | 1,352 | _not measured_ | 0.7654 | 0.8487 | 0.8568 | **no** |
| group_by_category via row @ 10000 linhas | 554.8 | _not measured_ | 1.846 | 1.936 | 1.94 | **no** |
| filtered_sum via row @ 10000 linhas | 1,115 | _not measured_ | 0.9425 | 1.024 | 1.032 | **no** |
| total_rows via columnar @ 10000 linhas | 907.9 | _not measured_ | 1.144 | 1.263 | 1.274 | **no** |
| sum_amount via columnar @ 10000 linhas | 922.9 | _not measured_ | 1.232 | 1.36 | 1.372 | **no** |
| group_by_category via columnar @ 10000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 10000 linhas | 392.3 | _not measured_ | 2.631 | 2.791 | 2.805 | **no** |
| total_rows via parquet @ 10000 linhas | 37.27 | _not measured_ | 29.99 | 30.63 | 30.68 | **no** |
| sum_amount via parquet @ 10000 linhas | 33.91 | _not measured_ | 33.18 | 33.61 | 33.65 | **no** |
| group_by_category via parquet @ 10000 linhas | 28.28 | _not measured_ | 35.69 | 35.92 | 35.96 | **no** |
| filtered_sum via parquet @ 10000 linhas | 35.92 | _not measured_ | 29.09 | 31.68 | 31.95 | **no** |
| total_rows via row @ 50000 linhas | 379 | _not measured_ | 2.821 | 2.882 | 2.894 | yes |
| sum_amount via row @ 50000 linhas | 305.2 | _not measured_ | 3.326 | 3.354 | 3.357 | **no** |
| group_by_category via row @ 50000 linhas | 118.7 | _not measured_ | 8.571 | 8.599 | 8.602 | **no** |
| filtered_sum via row @ 50000 linhas | 235.6 | _not measured_ | 4.327 | 4.406 | 4.415 | **no** |
| total_rows via columnar @ 50000 linhas | 693.8 | _not measured_ | 1.527 | 1.7 | 1.715 | **no** |
| sum_amount via columnar @ 50000 linhas | 459.7 | _not measured_ | 2.218 | 2.23 | 2.244 | **no** |
| group_by_category via columnar @ 50000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 50000 linhas | 121.2 | _not measured_ | 8.882 | 8.981 | 8.99 | **no** |
| total_rows via parquet @ 50000 linhas | 6.537 | _not measured_ | 153.1 | 156.5 | 156.8 | **no** |
| sum_amount via parquet @ 50000 linhas | 5.992 | _not measured_ | 187.7 | 222.5 | 225.6 | **no** |
| group_by_category via parquet @ 50000 linhas | 5.61 | _not measured_ | 195.1 | 201.5 | 202.9 | **no** |
| filtered_sum via parquet @ 50000 linhas | 6.164 | _not measured_ | 162.6 | 175.3 | 176.4 | **no** |
| total_rows via row @ 100000 linhas | 178.4 | _not measured_ | 8.465 | 10.95 | 11.02 | **no** |
| sum_amount via row @ 100000 linhas | 137.5 | _not measured_ | 7.845 | 9.236 | 9.36 | **no** |
| group_by_category via row @ 100000 linhas | 59.41 | _not measured_ | 17.87 | 18.99 | 19.01 | **no** |
| filtered_sum via row @ 100000 linhas | 117.4 | _not measured_ | 8.603 | 9.547 | 9.63 | **no** |
| total_rows via columnar @ 100000 linhas | 535.5 | _not measured_ | 1.93 | 2.092 | 2.107 | **no** |
| sum_amount via columnar @ 100000 linhas | 314.6 | _not measured_ | 3.22 | 3.387 | 3.402 | **no** |
| group_by_category via columnar @ 100000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 100000 linhas | 65.65 | _not measured_ | 15.71 | 15.76 | 15.76 | **no** |
| total_rows via parquet @ 100000 linhas | 3.101 | _not measured_ | 329.2 | 348.2 | 348.5 | **no** |
| sum_amount via parquet @ 100000 linhas | 2.88 | _not measured_ | 350.1 | 357 | 357.6 | **no** |
| group_by_category via parquet @ 100000 linhas | 2.664 | _not measured_ | 379.7 | 390.8 | 391.8 | **no** |
| filtered_sum via parquet @ 100000 linhas | 2.973 | _not measured_ | 346 | 350.9 | 351.8 | **no** |
| total_rows via row @ 500000 linhas | 48.95 | _not measured_ | 22.9 | 26.26 | 26.56 | **no** |
| sum_amount via row @ 500000 linhas | 41.24 | _not measured_ | 29.38 | 30.93 | 30.95 | **no** |
| group_by_category via row @ 500000 linhas | 23.7 | _not measured_ | 52.07 | 61.05 | 61.26 | **no** |
| filtered_sum via row @ 500000 linhas | 29.11 | _not measured_ | 34.94 | 38.7 | 39.04 | **no** |
| total_rows via columnar @ 500000 linhas | 163.1 | _not measured_ | 6.176 | 6.445 | 6.469 | **no** |
| sum_amount via columnar @ 500000 linhas | 81.92 | _not measured_ | 12.27 | 12.27 | 12.27 | **no** |
| group_by_category via columnar @ 500000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 500000 linhas | 15.33 | _not measured_ | 66.65 | 67.94 | 68.05 | **no** |
| total_rows via parquet @ 500000 linhas | 0.6071 | _not measured_ | 1,752 | 1,893 | 1,905 | **no** |
| sum_amount via parquet @ 500000 linhas | 0.557 | _not measured_ | 1,875 | 1,885 | 1,886 | **no** |
| group_by_category via parquet @ 500000 linhas | 0.5456 | _not measured_ | 1,888 | 1,959 | 1,965 | **no** |
| filtered_sum via parquet @ 500000 linhas | 0.6016 | _not measured_ | 1,748 | 1,849 | 1,855 | yes |
| total_rows via row @ 1000000 linhas | 34.73 | _not measured_ | 32.55 | 34.25 | 34.63 | **no** |
| sum_amount via row @ 1000000 linhas | 27.07 | _not measured_ | 37.23 | 46.23 | 47.03 | **no** |
| group_by_category via row @ 1000000 linhas | 13.74 | _not measured_ | 77.55 | 83.13 | 84.13 | **no** |
| filtered_sum via row @ 1000000 linhas | 22.82 | _not measured_ | 44.73 | 48.78 | 48.87 | **no** |
| total_rows via columnar @ 1000000 linhas | 69.95 | _not measured_ | 17.57 | 18.23 | 18.29 | **no** |
| sum_amount via columnar @ 1000000 linhas | 30.98 | _not measured_ | 32.4 | 32.87 | 32.91 | **no** |
| group_by_category via columnar @ 1000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 1000000 linhas | 7.671 | _not measured_ | 136.9 | 143.9 | 145.3 | **no** |
| total_rows via parquet @ 1000000 linhas | 0.3162 | _not measured_ | 3,230 | 3,271 | 3,275 | **no** |
| sum_amount via parquet @ 1000000 linhas | 0.2934 | _not measured_ | 3,441 | 3,484 | 3,488 | yes |
| group_by_category via parquet @ 1000000 linhas | 0.2751 | _not measured_ | 3,672 | 3,712 | 3,716 | yes |
| filtered_sum via parquet @ 1000000 linhas | 0.3025 | _not measured_ | 3,339 | 3,376 | 3,377 | yes |
| total_rows via row @ 2000000 linhas | 21.78 | _not measured_ | 46.89 | 47.69 | 47.76 | **no** |
| sum_amount via row @ 2000000 linhas | 15.24 | _not measured_ | 66.59 | 66.78 | 66.79 | **no** |
| group_by_category via row @ 2000000 linhas | 7.933 | _not measured_ | 126.3 | 141.6 | 141.6 | **no** |
| filtered_sum via row @ 2000000 linhas | 13.16 | _not measured_ | 76.44 | 77.12 | 77.19 | **no** |
| total_rows via columnar @ 2000000 linhas | 52.31 | _not measured_ | 19.23 | 21.54 | 21.59 | **no** |
| sum_amount via columnar @ 2000000 linhas | 23.78 | _not measured_ | 42.31 | 42.57 | 42.6 | yes |
| group_by_category via columnar @ 2000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 2000000 linhas | 3.873 | _not measured_ | 262.1 | 268 | 268.3 | **no** |
| total_rows via parquet @ 2000000 linhas | 0.1531 | _not measured_ | 6,704 | 6,777 | 6,786 | yes |
| sum_amount via parquet @ 2000000 linhas | 0.1388 | _not measured_ | 7,281 | 7,342 | 7,348 | yes |
| group_by_category via parquet @ 2000000 linhas | 0.1316 | _not measured_ | 7,660 | 7,839 | 7,855 | yes |
| filtered_sum via parquet @ 2000000 linhas | 0.141 | _not measured_ | 7,111 | 7,287 | 7,303 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row @ 10000 linhas`: latency_p50_ms cv=0.155; latency_p95_ms cv=0.151; latency_p99_ms cv=0.151; throughput_per_second cv=0.123
- `sum_amount via row @ 10000 linhas`: latency_p50_ms cv=0.090; latency_p95_ms cv=0.162; latency_p99_ms cv=0.168; throughput_per_second cv=0.113
- `group_by_category via row @ 10000 linhas`: latency_p95_ms cv=0.102; latency_p99_ms cv=0.111
- `filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.304; latency_p95_ms cv=0.631; latency_p99_ms cv=0.652
- `total_rows via columnar @ 10000 linhas`: latency_p50_ms cv=0.155; latency_p95_ms cv=0.077; latency_p99_ms cv=0.071; throughput_per_second cv=0.115
- `sum_amount via columnar @ 10000 linhas`: latency_p50_ms cv=0.087; latency_p95_ms cv=0.222; latency_p99_ms cv=0.233; throughput_per_second cv=0.073
- `filtered_sum via columnar @ 10000 linhas`: latency_p50_ms cv=0.304; latency_p95_ms cv=0.321; latency_p99_ms cv=0.322; throughput_per_second cv=0.264
- `total_rows via parquet @ 10000 linhas`: latency_p50_ms cv=0.306; latency_p95_ms cv=0.273; latency_p99_ms cv=0.270; throughput_per_second cv=0.281
- `sum_amount via parquet @ 10000 linhas`: latency_p99_ms cv=0.051; throughput_per_second cv=0.075
- `group_by_category via parquet @ 10000 linhas`: latency_p50_ms cv=0.083; latency_p95_ms cv=0.148; latency_p99_ms cv=0.154; throughput_per_second cv=0.064
- `filtered_sum via parquet @ 10000 linhas`: latency_p50_ms cv=0.087; latency_p95_ms cv=0.075; latency_p99_ms cv=0.074
- `sum_amount via row @ 50000 linhas`: latency_p50_ms cv=0.053; latency_p95_ms cv=0.052; latency_p99_ms cv=0.052
- `group_by_category via row @ 50000 linhas`: latency_p95_ms cv=0.086; latency_p99_ms cv=0.092
- `filtered_sum via row @ 50000 linhas`: latency_p95_ms cv=0.051; latency_p99_ms cv=0.055
- `total_rows via columnar @ 50000 linhas`: latency_p50_ms cv=0.209; latency_p95_ms cv=0.326; latency_p99_ms cv=0.334; throughput_per_second cv=0.197
- `sum_amount via columnar @ 50000 linhas`: latency_p50_ms cv=0.077; latency_p95_ms cv=0.061; latency_p99_ms cv=0.060; throughput_per_second cv=0.062
- `filtered_sum via columnar @ 50000 linhas`: latency_p50_ms cv=0.202; latency_p95_ms cv=0.215; latency_p99_ms cv=0.216; throughput_per_second cv=0.060
- `total_rows via parquet @ 50000 linhas`: latency_p95_ms cv=0.052; latency_p99_ms cv=0.054
- `sum_amount via parquet @ 50000 linhas`: latency_p50_ms cv=0.110; latency_p95_ms cv=0.161; latency_p99_ms cv=0.166
- `group_by_category via parquet @ 50000 linhas`: latency_p50_ms cv=0.070; latency_p95_ms cv=0.056; latency_p99_ms cv=0.056
- `filtered_sum via parquet @ 50000 linhas`: latency_p95_ms cv=0.139; latency_p99_ms cv=0.147
- `total_rows via row @ 100000 linhas`: latency_p50_ms cv=0.266; latency_p95_ms cv=0.319; latency_p99_ms cv=0.326
- `sum_amount via row @ 100000 linhas`: latency_p50_ms cv=0.147; latency_p95_ms cv=0.187; latency_p99_ms cv=0.191; throughput_per_second cv=0.145
- `group_by_category via row @ 100000 linhas`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.082; latency_p99_ms cv=0.087
- `filtered_sum via row @ 100000 linhas`: latency_p95_ms cv=0.457; latency_p99_ms cv=0.484
- `total_rows via columnar @ 100000 linhas`: latency_p50_ms cv=0.262; latency_p95_ms cv=0.213; latency_p99_ms cv=0.209; throughput_per_second cv=0.235
- `sum_amount via columnar @ 100000 linhas`: latency_p50_ms cv=0.254; latency_p95_ms cv=0.230; latency_p99_ms cv=0.228; throughput_per_second cv=0.221
- `filtered_sum via columnar @ 100000 linhas`: latency_p50_ms cv=0.086; latency_p95_ms cv=0.117; latency_p99_ms cv=0.120
- `total_rows via parquet @ 100000 linhas`: latency_p95_ms cv=0.077; latency_p99_ms cv=0.081; throughput_per_second cv=0.051
- `sum_amount via parquet @ 100000 linhas`: latency_p50_ms cv=0.120; latency_p95_ms cv=0.133; latency_p99_ms cv=0.134; throughput_per_second cv=0.097
- `group_by_category via parquet @ 100000 linhas`: latency_p50_ms cv=0.060; throughput_per_second cv=0.069
- `filtered_sum via parquet @ 100000 linhas`: latency_p95_ms cv=0.113; latency_p99_ms cv=0.120
- `total_rows via row @ 500000 linhas`: latency_p50_ms cv=0.244; latency_p95_ms cv=0.198; latency_p99_ms cv=0.195; throughput_per_second cv=0.161
- `sum_amount via row @ 500000 linhas`: latency_p50_ms cv=0.076; throughput_per_second cv=0.092
- `group_by_category via row @ 500000 linhas`: latency_p50_ms cv=0.126; latency_p95_ms cv=0.086; latency_p99_ms cv=0.090
- `filtered_sum via row @ 500000 linhas`: latency_p50_ms cv=0.103; throughput_per_second cv=0.177
- `total_rows via columnar @ 500000 linhas`: latency_p50_ms cv=0.298; latency_p95_ms cv=0.359; latency_p99_ms cv=0.364; throughput_per_second cv=0.241
- `sum_amount via columnar @ 500000 linhas`: latency_p50_ms cv=0.249; latency_p95_ms cv=0.279; latency_p99_ms cv=0.281; throughput_per_second cv=0.160
- `filtered_sum via columnar @ 500000 linhas`: latency_p50_ms cv=0.261; latency_p95_ms cv=0.283; latency_p99_ms cv=0.285; throughput_per_second cv=0.183
- `total_rows via parquet @ 500000 linhas`: latency_p50_ms cv=0.063; latency_p95_ms cv=0.135; latency_p99_ms cv=0.140
- `sum_amount via parquet @ 500000 linhas`: latency_p95_ms cv=0.073; latency_p99_ms cv=0.076; throughput_per_second cv=0.054
- `group_by_category via parquet @ 500000 linhas`: latency_p95_ms cv=0.127; latency_p99_ms cv=0.133
- `total_rows via row @ 1000000 linhas`: latency_p50_ms cv=0.152; latency_p95_ms cv=0.205; latency_p99_ms cv=0.209; throughput_per_second cv=0.109
- `sum_amount via row @ 1000000 linhas`: latency_p50_ms cv=0.114; latency_p95_ms cv=0.121; latency_p99_ms cv=0.125; throughput_per_second cv=0.091
- `group_by_category via row @ 1000000 linhas`: latency_p50_ms cv=0.103; latency_p95_ms cv=0.201; latency_p99_ms cv=0.210
- `filtered_sum via row @ 1000000 linhas`: latency_p50_ms cv=0.061; latency_p95_ms cv=0.081; latency_p99_ms cv=0.084
- `total_rows via columnar @ 1000000 linhas`: latency_p50_ms cv=0.291; latency_p95_ms cv=0.301; latency_p99_ms cv=0.302; throughput_per_second cv=0.295
- `sum_amount via columnar @ 1000000 linhas`: latency_p50_ms cv=0.264; latency_p95_ms cv=0.241; latency_p99_ms cv=0.239; throughput_per_second cv=0.265
- `filtered_sum via columnar @ 1000000 linhas`: latency_p50_ms cv=0.054; latency_p95_ms cv=0.099; latency_p99_ms cv=0.104
- `total_rows via parquet @ 1000000 linhas`: latency_p50_ms cv=0.056
- `total_rows via row @ 2000000 linhas`: latency_p50_ms cv=0.127; latency_p95_ms cv=0.124; latency_p99_ms cv=0.123; throughput_per_second cv=0.126
- `sum_amount via row @ 2000000 linhas`: latency_p50_ms cv=0.165; latency_p95_ms cv=0.109; latency_p99_ms cv=0.105; throughput_per_second cv=0.169
- `group_by_category via row @ 2000000 linhas`: latency_p50_ms cv=0.077; latency_p95_ms cv=0.081; latency_p99_ms cv=0.087
- `filtered_sum via row @ 2000000 linhas`: latency_p50_ms cv=0.109; latency_p95_ms cv=0.213; latency_p99_ms cv=0.222; throughput_per_second cv=0.073
- `total_rows via columnar @ 2000000 linhas`: latency_p50_ms cv=0.061; latency_p95_ms cv=0.140; latency_p99_ms cv=0.153
- `filtered_sum via columnar @ 2000000 linhas`: latency_p95_ms cv=0.139; latency_p99_ms cv=0.150

### Repetitions

Every repetition is retained:

- `total_rows via row @ 10000 linhas` latency_p50_ms: 0.6241, 0.8018, 0.615
- `total_rows via row @ 10000 linhas` latency_p95_ms: 0.7095, 0.8845, 0.6707
- `total_rows via row @ 10000 linhas` latency_p99_ms: 0.7171, 0.8918, 0.6757
- `total_rows via row @ 10000 linhas` throughput_per_second: 1,641, 1,341, 1,697
- `sum_amount via row @ 10000 linhas` latency_p50_ms: 0.7568, 0.8862, 0.7654
- `sum_amount via row @ 10000 linhas` latency_p95_ms: 0.8487, 1.059, 0.7806
- `sum_amount via row @ 10000 linhas` latency_p99_ms: 0.8568, 1.074, 0.7819
- `sum_amount via row @ 10000 linhas` throughput_per_second: 1,352, 1,132, 1,409
- `group_by_category via row @ 10000 linhas` latency_p50_ms: 1.893, 1.831, 1.846
- `group_by_category via row @ 10000 linhas` latency_p95_ms: 1.936, 2.239, 1.848
- `group_by_category via row @ 10000 linhas` latency_p99_ms: 1.94, 2.275, 1.848
- `group_by_category via row @ 10000 linhas` throughput_per_second: 532.4, 554.8, 581.8
- `filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.9425, 1.485, 0.873
- `filtered_sum via row @ 10000 linhas` latency_p95_ms: 1.024, 2.58, 0.8792
- `filtered_sum via row @ 10000 linhas` latency_p99_ms: 1.032, 2.678, 0.8798
- `filtered_sum via row @ 10000 linhas` throughput_per_second: 1,065, 1,115, 1,150
- `total_rows via columnar @ 10000 linhas` latency_p50_ms: 1.144, 1.335, 0.9771
- `total_rows via columnar @ 10000 linhas` latency_p95_ms: 1.263, 1.362, 1.167
- `total_rows via columnar @ 10000 linhas` latency_p99_ms: 1.274, 1.365, 1.184
- `total_rows via columnar @ 10000 linhas` throughput_per_second: 907.9, 906, 1,101
- `sum_amount via columnar @ 10000 linhas` latency_p50_ms: 1.232, 1.301, 1.095
- `sum_amount via columnar @ 10000 linhas` latency_p95_ms: 1.36, 1.749, 1.128
- `sum_amount via columnar @ 10000 linhas` latency_p99_ms: 1.372, 1.789, 1.131
- `sum_amount via columnar @ 10000 linhas` throughput_per_second: 825.8, 950.3, 922.9
- `filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 2.563, 4.252, 2.631
- `filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 2.571, 4.497, 2.791
- `filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 2.572, 4.519, 2.805
- `filtered_sum via columnar @ 10000 linhas` throughput_per_second: 395.7, 237.8, 392.3
- `total_rows via parquet @ 10000 linhas` latency_p50_ms: 26.32, 45.95, 29.99
- `total_rows via parquet @ 10000 linhas` latency_p95_ms: 29.56, 46.96, 30.63
- `total_rows via parquet @ 10000 linhas` latency_p99_ms: 29.85, 47.05, 30.68
- `total_rows via parquet @ 10000 linhas` throughput_per_second: 39.11, 22.28, 37.27
- `sum_amount via parquet @ 10000 linhas` latency_p50_ms: 33.15, 33.22, 33.18
- `sum_amount via parquet @ 10000 linhas` latency_p95_ms: 36.45, 33.61, 33.61
- `sum_amount via parquet @ 10000 linhas` latency_p99_ms: 36.74, 33.65, 33.65
- `sum_amount via parquet @ 10000 linhas` throughput_per_second: 30.33, 35.13, 33.91
- `group_by_category via parquet @ 10000 linhas` latency_p50_ms: 35.47, 40.94, 35.69
- `group_by_category via parquet @ 10000 linhas` latency_p95_ms: 35.92, 45.88, 35.7
- `group_by_category via parquet @ 10000 linhas` latency_p99_ms: 35.96, 46.32, 35.7
- `group_by_category via parquet @ 10000 linhas` throughput_per_second: 28.28, 28.28, 31.56
- `filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 29.09, 33.41, 28.65
- `filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 31.61, 35.92, 31.68
- `filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 31.83, 36.15, 31.95
- `filtered_sum via parquet @ 10000 linhas` throughput_per_second: 35.92, 35.4, 36.1
- `total_rows via row @ 50000 linhas` latency_p50_ms: 2.821, 2.748, 2.867
- `total_rows via row @ 50000 linhas` latency_p95_ms: 2.839, 2.882, 2.892
- `total_rows via row @ 50000 linhas` latency_p99_ms: 2.841, 2.894, 2.894
- `total_rows via row @ 50000 linhas` throughput_per_second: 384.3, 379, 357
- `sum_amount via row @ 50000 linhas` latency_p50_ms: 3.216, 3.326, 3.565
- `sum_amount via row @ 50000 linhas` latency_p95_ms: 3.239, 3.354, 3.586
- `sum_amount via row @ 50000 linhas` latency_p99_ms: 3.241, 3.357, 3.588
- `sum_amount via row @ 50000 linhas` throughput_per_second: 314.4, 305.2, 286.7
- `group_by_category via row @ 50000 linhas` latency_p50_ms: 8.361, 8.758, 8.571
- `group_by_category via row @ 50000 linhas` latency_p95_ms: 8.562, 9.929, 8.599
- `group_by_category via row @ 50000 linhas` latency_p99_ms: 8.58, 10.03, 8.602
- `group_by_category via row @ 50000 linhas` throughput_per_second: 119.6, 118, 118.7
- `filtered_sum via row @ 50000 linhas` latency_p50_ms: 4.327, 4.307, 4.36
- `filtered_sum via row @ 50000 linhas` latency_p95_ms: 4.79, 4.406, 4.382
- `filtered_sum via row @ 50000 linhas` latency_p99_ms: 4.831, 4.415, 4.384
- `filtered_sum via row @ 50000 linhas` throughput_per_second: 239.6, 235.4, 235.6
- `total_rows via columnar @ 50000 linhas` latency_p50_ms: 1.527, 2.062, 1.408
- `total_rows via columnar @ 50000 linhas` latency_p95_ms: 1.7, 2.818, 1.627
- `total_rows via columnar @ 50000 linhas` latency_p99_ms: 1.715, 2.885, 1.647
- `total_rows via columnar @ 50000 linhas` throughput_per_second: 693.8, 497.9, 733.5
- `sum_amount via columnar @ 50000 linhas` latency_p50_ms: 2.073, 2.415, 2.218
- `sum_amount via columnar @ 50000 linhas` latency_p95_ms: 2.23, 2.469, 2.22
- `sum_amount via columnar @ 50000 linhas` latency_p99_ms: 2.244, 2.473, 2.22
- `sum_amount via columnar @ 50000 linhas` throughput_per_second: 485.7, 428.5, 459.7
- `filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 11.86, 8.882, 8.205
- `filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 12.25, 8.981, 8.283
- `filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 12.28, 8.99, 8.29
- `filtered_sum via columnar @ 50000 linhas` throughput_per_second: 109.5, 121.2, 122
- `total_rows via parquet @ 50000 linhas` latency_p50_ms: 152, 161.4, 153.1
- `total_rows via parquet @ 50000 linhas` latency_p95_ms: 155.4, 170.5, 156.5
- `total_rows via parquet @ 50000 linhas` latency_p99_ms: 155.7, 171.3, 156.8
- `total_rows via parquet @ 50000 linhas` throughput_per_second: 6.59, 6.291, 6.537
- `sum_amount via parquet @ 50000 linhas` latency_p50_ms: 169.6, 187.7, 211.1
- `sum_amount via parquet @ 50000 linhas` latency_p95_ms: 171.7, 222.5, 235.7
- `sum_amount via parquet @ 50000 linhas` latency_p99_ms: 171.9, 225.6, 237.9
- `sum_amount via parquet @ 50000 linhas` throughput_per_second: 5.992, 6.011, 5.654
- `group_by_category via parquet @ 50000 linhas` latency_p50_ms: 213.3, 195.1, 186.1
- `group_by_category via parquet @ 50000 linhas` latency_p95_ms: 217.8, 195.6, 201.5
- `group_by_category via parquet @ 50000 linhas` latency_p99_ms: 218.2, 195.6, 202.9
- `group_by_category via parquet @ 50000 linhas` throughput_per_second: 5.249, 5.655, 5.61
- `filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 162.6, 162.4, 174.1
- `filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 167.2, 175.3, 215.5
- `filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 167.6, 176.4, 219.1
- `filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.227, 6.164, 6.041
- `total_rows via row @ 100000 linhas` latency_p50_ms: 8.465, 5.874, 10.19
- `total_rows via row @ 100000 linhas` latency_p95_ms: 11.47, 5.993, 10.95
- `total_rows via row @ 100000 linhas` latency_p99_ms: 11.73, 6.003, 11.02
- `total_rows via row @ 100000 linhas` throughput_per_second: 182.5, 175.5, 178.4
- `sum_amount via row @ 100000 linhas` latency_p50_ms: 6.821, 9.142, 7.845
- `sum_amount via row @ 100000 linhas` latency_p95_ms: 6.902, 10.05, 9.236
- `sum_amount via row @ 100000 linhas` latency_p99_ms: 6.909, 10.13, 9.36
- `sum_amount via row @ 100000 linhas` throughput_per_second: 147, 110.2, 137.5
- `group_by_category via row @ 100000 linhas` latency_p50_ms: 16.79, 17.87, 18.79
- `group_by_category via row @ 100000 linhas` latency_p95_ms: 18.33, 21.37, 18.99
- `group_by_category via row @ 100000 linhas` latency_p99_ms: 18.46, 21.68, 19.01
- `group_by_category via row @ 100000 linhas` throughput_per_second: 60.41, 56.06, 59.41
- `filtered_sum via row @ 100000 linhas` latency_p50_ms: 8.441, 8.86, 8.603
- `filtered_sum via row @ 100000 linhas` latency_p95_ms: 8.555, 18.74, 9.547
- `filtered_sum via row @ 100000 linhas` latency_p99_ms: 8.566, 19.62, 9.63
- `filtered_sum via row @ 100000 linhas` throughput_per_second: 119.3, 117.4, 116.6
- `total_rows via columnar @ 100000 linhas` latency_p50_ms: 1.689, 2.748, 1.93
- `total_rows via columnar @ 100000 linhas` latency_p95_ms: 1.837, 2.755, 2.092
- `total_rows via columnar @ 100000 linhas` latency_p99_ms: 1.85, 2.755, 2.107
- `total_rows via columnar @ 100000 linhas` throughput_per_second: 607.2, 375.1, 535.5
- `sum_amount via columnar @ 100000 linhas` latency_p50_ms: 3.019, 4.717, 3.22
- `sum_amount via columnar @ 100000 linhas` latency_p95_ms: 3.182, 4.784, 3.387
- `sum_amount via columnar @ 100000 linhas` latency_p99_ms: 3.196, 4.79, 3.402
- `sum_amount via columnar @ 100000 linhas` throughput_per_second: 335.2, 215.9, 314.6
- `filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 17.4, 14.69, 15.71
- `filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 18.49, 14.79, 15.76
- `filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 18.59, 14.8, 15.76
- `filtered_sum via columnar @ 100000 linhas` throughput_per_second: 64.78, 68.32, 65.65
- `total_rows via parquet @ 100000 linhas` latency_p50_ms: 329.2, 312.9, 345.8
- `total_rows via parquet @ 100000 linhas` latency_p95_ms: 377.4, 323.7, 348.2
- `total_rows via parquet @ 100000 linhas` latency_p99_ms: 381.7, 324.7, 348.5
- `total_rows via parquet @ 100000 linhas` throughput_per_second: 3.101, 3.26, 2.946
- `sum_amount via parquet @ 100000 linhas` latency_p50_ms: 350.1, 343.7, 423.9
- `sum_amount via parquet @ 100000 linhas` latency_p95_ms: 357, 354.7, 444.5
- `sum_amount via parquet @ 100000 linhas` latency_p99_ms: 357.6, 355.6, 446.4
- `sum_amount via parquet @ 100000 linhas` throughput_per_second: 2.88, 2.965, 2.462
- `group_by_category via parquet @ 100000 linhas` latency_p50_ms: 379.7, 415.1, 370.8
- `group_by_category via parquet @ 100000 linhas` latency_p95_ms: 390.8, 418.8, 383.9
- `group_by_category via parquet @ 100000 linhas` latency_p99_ms: 391.8, 419.2, 385.1
- `group_by_category via parquet @ 100000 linhas` throughput_per_second: 2.664, 2.424, 2.78
- `filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 346, 359, 339.9
- `filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 349.9, 423.5, 350.9
- `filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 350.2, 429.2, 351.8
- `filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.034, 2.8, 2.973
- `total_rows via row @ 500000 linhas` latency_p50_ms: 32.82, 21.26, 22.9
- `total_rows via row @ 500000 linhas` latency_p95_ms: 33.28, 22.61, 26.26
- `total_rows via row @ 500000 linhas` latency_p99_ms: 33.33, 22.73, 26.56
- `total_rows via row @ 500000 linhas` throughput_per_second: 36.93, 50.04, 48.95
- `sum_amount via row @ 500000 linhas` latency_p50_ms: 29.38, 26.5, 30.8
- `sum_amount via row @ 500000 linhas` latency_p95_ms: 31.23, 30.5, 30.93
- `sum_amount via row @ 500000 linhas` latency_p99_ms: 31.39, 30.85, 30.95
- `sum_amount via row @ 500000 linhas` throughput_per_second: 35.13, 41.24, 41.51
- `group_by_category via row @ 500000 linhas` latency_p50_ms: 58.58, 45.48, 52.07
- `group_by_category via row @ 500000 linhas` latency_p95_ms: 61.05, 57.16, 67.73
- `group_by_category via row @ 500000 linhas` latency_p99_ms: 61.26, 58.2, 69.12
- `group_by_category via row @ 500000 linhas` throughput_per_second: 22.66, 23.7, 24.66
- `filtered_sum via row @ 500000 linhas` latency_p50_ms: 34.94, 31.02, 38.18
- `filtered_sum via row @ 500000 linhas` latency_p95_ms: 38.7, 35.92, 39.47
- `filtered_sum via row @ 500000 linhas` latency_p99_ms: 39.04, 36.35, 39.59
- `filtered_sum via row @ 500000 linhas` throughput_per_second: 29.11, 37.15, 26.7
- `total_rows via columnar @ 500000 linhas` latency_p50_ms: 6.176, 9.85, 5.964
- `total_rows via columnar @ 500000 linhas` latency_p95_ms: 6.445, 11.08, 6.001
- `total_rows via columnar @ 500000 linhas` latency_p99_ms: 6.469, 11.19, 6.005
- `total_rows via columnar @ 500000 linhas` throughput_per_second: 163.1, 109.7, 179
- `sum_amount via columnar @ 500000 linhas` latency_p50_ms: 12.27, 17.96, 11.65
- `sum_amount via columnar @ 500000 linhas` latency_p95_ms: 12.27, 18.84, 11.67
- `sum_amount via columnar @ 500000 linhas` latency_p99_ms: 12.27, 18.91, 11.67
- `sum_amount via columnar @ 500000 linhas` throughput_per_second: 81.92, 63.01, 86.11
- `filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 101.6, 66.65, 65.96
- `filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 106.4, 67.94, 66.32
- `filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 106.8, 68.05, 66.36
- `filtered_sum via columnar @ 500000 linhas` throughput_per_second: 10.94, 15.34, 15.33
- `total_rows via parquet @ 500000 linhas` latency_p50_ms: 1,835, 1,752, 1,619
- `total_rows via parquet @ 500000 linhas` latency_p95_ms: 2,165, 1,893, 1,652
- `total_rows via parquet @ 500000 linhas` latency_p99_ms: 2,194, 1,905, 1,655
- `total_rows via parquet @ 500000 linhas` throughput_per_second: 0.6071, 0.5897, 0.6397
- `sum_amount via parquet @ 500000 linhas` latency_p50_ms: 1,875, 1,940, 1,802
- `sum_amount via parquet @ 500000 linhas` latency_p95_ms: 1,885, 2,077, 1,805
- `sum_amount via parquet @ 500000 linhas` latency_p99_ms: 1,886, 2,090, 1,805
- `sum_amount via parquet @ 500000 linhas` throughput_per_second: 0.5886, 0.528, 0.557
- `group_by_category via parquet @ 500000 linhas` latency_p50_ms: 2,026, 1,845, 1,888
- `group_by_category via parquet @ 500000 linhas` latency_p95_ms: 2,349, 1,857, 1,959
- `group_by_category via parquet @ 500000 linhas` latency_p99_ms: 2,378, 1,858, 1,965
- `group_by_category via parquet @ 500000 linhas` throughput_per_second: 0.5456, 0.5429, 0.5547
- `filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,748, 1,704, 1,781
- `filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,873, 1,752, 1,849
- `filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,884, 1,757, 1,855
- `filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.5811, 0.6016, 0.6031
- `total_rows via row @ 1000000 linhas` latency_p50_ms: 39.99, 32.55, 29.99
- `total_rows via row @ 1000000 linhas` latency_p95_ms: 47.14, 33.08, 34.25
- `total_rows via row @ 1000000 linhas` latency_p99_ms: 47.78, 33.13, 34.63
- `total_rows via row @ 1000000 linhas` throughput_per_second: 28.59, 34.73, 34.81
- `sum_amount via row @ 1000000 linhas` latency_p50_ms: 44.87, 36.85, 37.23
- `sum_amount via row @ 1000000 linhas` latency_p95_ms: 47.07, 37.56, 46.23
- `sum_amount via row @ 1000000 linhas` latency_p99_ms: 47.26, 37.62, 47.03
- `sum_amount via row @ 1000000 linhas` throughput_per_second: 23.91, 28.66, 27.07
- `group_by_category via row @ 1000000 linhas` latency_p50_ms: 87.99, 71.94, 77.55
- `group_by_category via row @ 1000000 linhas` latency_p95_ms: 112.1, 83.13, 78.12
- `group_by_category via row @ 1000000 linhas` latency_p99_ms: 114.2, 84.13, 78.17
- `group_by_category via row @ 1000000 linhas` throughput_per_second: 13.58, 14.25, 13.74
- `filtered_sum via row @ 1000000 linhas` latency_p50_ms: 47.72, 42.27, 44.73
- `filtered_sum via row @ 1000000 linhas` latency_p95_ms: 48.78, 42.39, 49.18
- `filtered_sum via row @ 1000000 linhas` latency_p99_ms: 48.87, 42.4, 49.58
- `filtered_sum via row @ 1000000 linhas` throughput_per_second: 22.22, 23.92, 22.82
- `total_rows via columnar @ 1000000 linhas` latency_p50_ms: 10.1, 17.57, 17.93
- `total_rows via columnar @ 1000000 linhas` latency_p95_ms: 10.16, 18.23, 18.34
- `total_rows via columnar @ 1000000 linhas` latency_p99_ms: 10.16, 18.29, 18.37
- `total_rows via columnar @ 1000000 linhas` throughput_per_second: 99.95, 69.95, 56.43
- `sum_amount via columnar @ 1000000 linhas` latency_p50_ms: 21.66, 32.4, 37.45
- `sum_amount via columnar @ 1000000 linhas` latency_p95_ms: 22.8, 32.87, 37.45
- `sum_amount via columnar @ 1000000 linhas` latency_p99_ms: 22.9, 32.91, 37.45
- `sum_amount via columnar @ 1000000 linhas` throughput_per_second: 46.66, 30.98, 29.59
- `filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 136.9, 142.9, 128.2
- `filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 139.1, 166.9, 143.9
- `filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 139.3, 169.1, 145.3
- `filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 7.671, 7.223, 7.824
- `total_rows via parquet @ 1000000 linhas` latency_p50_ms: 3,438, 3,230, 3,076
- `total_rows via parquet @ 1000000 linhas` latency_p95_ms: 3,483, 3,271, 3,227
- `total_rows via parquet @ 1000000 linhas` latency_p99_ms: 3,487, 3,275, 3,241
- `total_rows via parquet @ 1000000 linhas` throughput_per_second: 0.2997, 0.3162, 0.3254
- `sum_amount via parquet @ 1000000 linhas` latency_p50_ms: 3,563, 3,441, 3,404
- `sum_amount via parquet @ 1000000 linhas` latency_p95_ms: 3,579, 3,484, 3,445
- `sum_amount via parquet @ 1000000 linhas` latency_p99_ms: 3,581, 3,488, 3,448
- `sum_amount via parquet @ 1000000 linhas` throughput_per_second: 0.2913, 0.2934, 0.297
- `group_by_category via parquet @ 1000000 linhas` latency_p50_ms: 3,666, 3,686, 3,672
- `group_by_category via parquet @ 1000000 linhas` latency_p95_ms: 3,684, 3,785, 3,712
- `group_by_category via parquet @ 1000000 linhas` latency_p99_ms: 3,686, 3,794, 3,716
- `group_by_category via parquet @ 1000000 linhas` throughput_per_second: 0.2751, 0.2752, 0.2725
- `filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,301, 3,339, 3,358
- `filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,335, 3,379, 3,376
- `filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,338, 3,383, 3,377
- `filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.3034, 0.3025, 0.2982
- `total_rows via row @ 2000000 linhas` latency_p50_ms: 55.77, 46.89, 43.89
- `total_rows via row @ 2000000 linhas` latency_p95_ms: 55.82, 47.69, 43.95
- `total_rows via row @ 2000000 linhas` latency_p99_ms: 55.83, 47.76, 43.96
- `total_rows via row @ 2000000 linhas` throughput_per_second: 18.04, 21.78, 23.16
- `sum_amount via row @ 2000000 linhas` latency_p50_ms: 66.59, 78.88, 56.67
- `sum_amount via row @ 2000000 linhas` latency_p95_ms: 66.78, 79.27, 65.31
- `sum_amount via row @ 2000000 linhas` latency_p99_ms: 66.79, 79.31, 66.08
- `sum_amount via row @ 2000000 linhas` throughput_per_second: 15.24, 12.77, 17.94
- `group_by_category via row @ 2000000 linhas` latency_p50_ms: 141.3, 126.3, 122.3
- `group_by_category via row @ 2000000 linhas` latency_p95_ms: 141.6, 126.8, 148.8
- `group_by_category via row @ 2000000 linhas` latency_p99_ms: 141.6, 126.8, 151.1
- `group_by_category via row @ 2000000 linhas` throughput_per_second: 7.663, 7.933, 8.2
- `filtered_sum via row @ 2000000 linhas` latency_p50_ms: 76.44, 69.91, 86.75
- `filtered_sum via row @ 2000000 linhas` latency_p95_ms: 77.12, 70.01, 103.8
- `filtered_sum via row @ 2000000 linhas` latency_p99_ms: 77.19, 70.02, 105.3
- `filtered_sum via row @ 2000000 linhas` throughput_per_second: 13.16, 14.32, 12.38
- `total_rows via columnar @ 2000000 linhas` latency_p50_ms: 18.6, 19.23, 20.91
- `total_rows via columnar @ 2000000 linhas` latency_p95_ms: 25.78, 19.69, 21.54
- `total_rows via columnar @ 2000000 linhas` latency_p99_ms: 26.42, 19.73, 21.59
- `total_rows via columnar @ 2000000 linhas` throughput_per_second: 54.55, 52.26, 52.31
- `sum_amount via columnar @ 2000000 linhas` latency_p50_ms: 42.31, 43.64, 42.23
- `sum_amount via columnar @ 2000000 linhas` latency_p95_ms: 42.57, 43.78, 42.26
- `sum_amount via columnar @ 2000000 linhas` latency_p99_ms: 42.6, 43.79, 42.26
- `sum_amount via columnar @ 2000000 linhas` throughput_per_second: 23.89, 23.17, 23.78
- `filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 260.6, 264.5, 262.1
- `filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 265.2, 268, 336.2
- `filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 265.7, 268.3, 342.8
- `filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 3.926, 3.805, 3.873
- `total_rows via parquet @ 2000000 linhas` latency_p50_ms: 6,704, 6,827, 6,682
- `total_rows via parquet @ 2000000 linhas` latency_p95_ms: 6,752, 6,856, 6,777
- `total_rows via parquet @ 2000000 linhas` latency_p99_ms: 6,756, 6,859, 6,786
- `total_rows via parquet @ 2000000 linhas` throughput_per_second: 0.1531, 0.1536, 0.1497
- `sum_amount via parquet @ 2000000 linhas` latency_p50_ms: 7,276, 7,281, 7,467
- `sum_amount via parquet @ 2000000 linhas` latency_p95_ms: 7,296, 7,342, 7,680
- `sum_amount via parquet @ 2000000 linhas` latency_p99_ms: 7,298, 7,348, 7,699
- `sum_amount via parquet @ 2000000 linhas` throughput_per_second: 0.1379, 0.1396, 0.1388
- `group_by_category via parquet @ 2000000 linhas` latency_p50_ms: 7,660, 7,552, 7,993
- `group_by_category via parquet @ 2000000 linhas` latency_p95_ms: 7,839, 7,646, 8,002
- `group_by_category via parquet @ 2000000 linhas` latency_p99_ms: 7,855, 7,654, 8,003
- `group_by_category via parquet @ 2000000 linhas` throughput_per_second: 0.1316, 0.1327, 0.1267
- `filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 7,111, 7,356, 7,061
- `filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 7,287, 7,492, 7,098
- `filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 7,303, 7,504, 7,102
- `filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.141, 0.1388, 0.1433

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T111440Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: dbeefff628dfeaf06c3bc69fa1f33f578f19d08a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

