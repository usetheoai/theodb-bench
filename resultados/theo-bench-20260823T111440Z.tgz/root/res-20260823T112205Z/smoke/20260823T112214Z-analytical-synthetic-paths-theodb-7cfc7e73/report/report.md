# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T112214Z-analytical-synthetic-paths-theodb-7cfc7e73`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 94.55 | _not measured_ | 10.97 | 11.67 | 11.67 | **no** |
| sum_amount via row | 75.24 | _not measured_ | 13.64 | 13.75 | 13.75 | **no** |
| group_by_category via row | 36.7 | _not measured_ | 28.39 | 32.64 | 33.05 | **no** |
| filtered_sum via row | 56.04 | _not measured_ | 20.74 | 21.52 | 21.58 | **no** |
| total_rows via columnar | 239.3 | _not measured_ | 4.211 | 4.319 | 4.329 | **no** |
| sum_amount via columnar | 165 | _not measured_ | 7.587 | 7.593 | 7.594 | **no** |
| group_by_category via columnar | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar | 36.76 | _not measured_ | 30.96 | 33.1 | 33.23 | **no** |
| total_rows via parquet | 1.672 | _not measured_ | 625.1 | 645.7 | 647.5 | **no** |
| sum_amount via parquet | 1.46 | _not measured_ | 706 | 748.2 | 753.9 | **no** |
| group_by_category via parquet | 1.372 | _not measured_ | 768 | 791.2 | 793.2 | **no** |
| filtered_sum via parquet | 1.531 | _not measured_ | 724.1 | 738.7 | 740 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p95_ms cv=0.067; latency_p99_ms cv=0.072
- `sum_amount via row`: latency_p50_ms cv=0.155; latency_p95_ms cv=0.291; latency_p99_ms cv=0.302
- `group_by_category via row`: latency_p50_ms cv=0.052
- `filtered_sum via row`: latency_p50_ms cv=0.083; latency_p95_ms cv=0.144; latency_p99_ms cv=0.150
- `total_rows via columnar`: latency_p50_ms cv=0.260; latency_p95_ms cv=0.414; latency_p99_ms cv=0.426; throughput_per_second cv=0.241
- `sum_amount via columnar`: latency_p50_ms cv=0.194; latency_p95_ms cv=0.195; latency_p99_ms cv=0.195; throughput_per_second cv=0.167
- `filtered_sum via columnar`: latency_p50_ms cv=0.082; latency_p95_ms cv=0.124; latency_p99_ms cv=0.129
- `total_rows via parquet`: latency_p95_ms cv=0.085; latency_p99_ms cv=0.091
- `sum_amount via parquet`: latency_p50_ms cv=0.052
- `group_by_category via parquet`: latency_p95_ms cv=0.074; latency_p99_ms cv=0.076
- `filtered_sum via parquet`: latency_p50_ms cv=0.069; latency_p95_ms cv=0.066; latency_p99_ms cv=0.066; throughput_per_second cv=0.083

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 10.97, 10.73, 11.66
- `total_rows via row` latency_p95_ms: 12.44, 10.87, 11.67
- `total_rows via row` latency_p99_ms: 12.57, 10.89, 11.67
- `total_rows via row` throughput_per_second: 94.34, 94.6, 94.55
- `sum_amount via row` latency_p50_ms: 13.4, 13.64, 17.5
- `sum_amount via row` latency_p95_ms: 13.42, 13.75, 21.81
- `sum_amount via row` latency_p99_ms: 13.43, 13.75, 22.19
- `sum_amount via row` throughput_per_second: 75.66, 73.82, 75.24
- `group_by_category via row` latency_p50_ms: 30.81, 28.07, 28.39
- `group_by_category via row` latency_p95_ms: 33.56, 32.64, 30.71
- `group_by_category via row` latency_p99_ms: 33.8, 33.05, 30.92
- `group_by_category via row` throughput_per_second: 34.78, 36.7, 36.89
- `filtered_sum via row` latency_p50_ms: 20.74, 20.83, 17.93
- `filtered_sum via row` latency_p95_ms: 24.03, 21.52, 17.97
- `filtered_sum via row` latency_p99_ms: 24.33, 21.58, 17.98
- `filtered_sum via row` throughput_per_second: 55.03, 56.06, 56.04
- `total_rows via columnar` latency_p50_ms: 4.211, 2.903, 4.973
- `total_rows via columnar` latency_p95_ms: 4.319, 2.97, 6.801
- `total_rows via columnar` latency_p99_ms: 4.329, 2.976, 6.963
- `total_rows via columnar` throughput_per_second: 239.3, 353.3, 236.3
- `sum_amount via columnar` latency_p50_ms: 7.587, 5.412, 7.882
- `sum_amount via columnar` latency_p95_ms: 7.593, 5.44, 7.972
- `sum_amount via columnar` latency_p99_ms: 7.594, 5.443, 7.98
- `sum_amount via columnar` throughput_per_second: 132.6, 186.2, 165
- `filtered_sum via columnar` latency_p50_ms: 30.96, 31.7, 27.15
- `filtered_sum via columnar` latency_p95_ms: 35.08, 33.1, 27.44
- `filtered_sum via columnar` latency_p99_ms: 35.45, 33.23, 27.46
- `filtered_sum via columnar` throughput_per_second: 34.85, 36.76, 37.11
- `total_rows via parquet` latency_p50_ms: 625.6, 625.1, 604.5
- `total_rows via parquet` latency_p95_ms: 732.3, 645.7, 625.5
- `total_rows via parquet` latency_p99_ms: 741.8, 647.5, 627.3
- `total_rows via parquet` throughput_per_second: 1.643, 1.672, 1.68
- `sum_amount via parquet` latency_p50_ms: 756.6, 706, 683.5
- `sum_amount via parquet` latency_p95_ms: 786.8, 735.7, 748.2
- `sum_amount via parquet` latency_p99_ms: 789.5, 738.3, 753.9
- `sum_amount via parquet` throughput_per_second: 1.376, 1.46, 1.468
- `group_by_category via parquet` latency_p50_ms: 707.8, 769.7, 768
- `group_by_category via parquet` latency_p95_ms: 717.1, 830, 791.2
- `group_by_category via parquet` latency_p99_ms: 717.9, 835.4, 793.2
- `group_by_category via parquet` throughput_per_second: 1.419, 1.372, 1.343
- `filtered_sum via parquet` latency_p50_ms: 701.1, 799.1, 724.1
- `filtered_sum via parquet` latency_p95_ms: 702.7, 800.6, 738.7
- `filtered_sum via parquet` latency_p99_ms: 702.9, 800.8, 740
- `filtered_sum via parquet` throughput_per_second: 1.595, 1.355, 1.531

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T111440Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: dbeefff628dfeaf06c3bc69fa1f33f578f19d08a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

