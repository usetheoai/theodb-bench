# vector/sift/hnsw on pgvector

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T224813Z-vector-sift-hnsw-pgvector-06ea8167`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,107 | 0.8824 | 0.7869 | 0.9853 | 1.085 | **no** |
| hnsw m=16 ef_search=64 | 661.9 | 0.9856 | 1.418 | 1.727 | 1.834 | yes |
| hnsw m=16 ef_search=256 | 278.9 | 0.9998 | 3.549 | 4.431 | 4.805 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.081; latency_p95_ms cv=0.076; throughput_per_second cv=0.100

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 33.57, 33.57, 33.57
- `hnsw m=16 ef_search=16` index_size_bytes: 8.317e+07, 8.317e+07, 8.317e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.7869, 0.6823, 0.7879
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.9853, 0.8631, 0.9895
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.085, 1.015, 1.097
- `hnsw m=16 ef_search=16` recall: 0.8824, 0.8824, 0.8824
- `hnsw m=16 ef_search=16` throughput_per_second: 1,096, 1,303, 1,107
- `hnsw m=16 ef_search=64` build_seconds: 37.87, 37.87, 37.87
- `hnsw m=16 ef_search=64` index_size_bytes: 8.317e+07, 8.317e+07, 8.317e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.413, 1.424, 1.418
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.727, 1.751, 1.717
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.834, 1.932, 1.811
- `hnsw m=16 ef_search=64` recall: 0.9856, 0.9856, 0.9856
- `hnsw m=16 ef_search=64` throughput_per_second: 661.9, 649.6, 678.7
- `hnsw m=16 ef_search=256` build_seconds: 33.45, 33.45, 33.45
- `hnsw m=16 ef_search=256` index_size_bytes: 8.308e+07, 8.308e+07, 8.308e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.588, 3.521, 3.549
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.431, 4.377, 4.439
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.587, 4.805, 4.83
- `hnsw m=16 ef_search=256` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=256` throughput_per_second: 277.8, 280.1, 278.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T224009Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e33e1ade0d002e02afd40f98201d1fabd1ad04e4 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

