# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T195754Z-analytical-synthetic-paths-theodb-a1b995a2`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 99.85 | _not measured_ | 10.12 | 10.18 | 10.19 | yes |
| sum_amount via row | 78.91 | _not measured_ | 12.77 | 12.81 | 12.82 | yes |
| group_by_category via row | 41.18 | _not measured_ | 24.71 | 26.19 | 26.3 | yes |
| filtered_sum via row | 63.56 | _not measured_ | 15.86 | 16.33 | 16.37 | **no** |
| numeric_filtered_sum via row | 66.46 | _not measured_ | 15.05 | 15.23 | 15.24 | **no** |
| total_rows via columnar | 559.6 | _not measured_ | 1.947 | 1.991 | 1.996 | **no** |
| sum_amount via columnar | 267.3 | _not measured_ | 3.788 | 3.965 | 3.978 | yes |
| group_by_category via columnar | 40.19 | _not measured_ | 25.05 | 25.43 | 25.45 | **no** |
| filtered_sum via columnar | 40.82 | _not measured_ | 24.72 | 24.73 | 24.73 | **no** |
| numeric_filtered_sum via columnar | 153.6 | _not measured_ | 6.619 | 6.698 | 6.713 | yes |
| total_rows via parquet | 1.848 | _not measured_ | 544.7 | 552.1 | 552.8 | yes |
| sum_amount via parquet | 1.652 | _not measured_ | 607.5 | 610.6 | 610.7 | yes |
| group_by_category via parquet | 1.571 | _not measured_ | 639.2 | 643.3 | 643.7 | yes |
| filtered_sum via parquet | 1.723 | _not measured_ | 582.4 | 588.5 | 589.1 | yes |
| numeric_filtered_sum via parquet | 1.684 | _not measured_ | 596.2 | 597.2 | 597.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via row`: latency_p50_ms cv=0.128; latency_p95_ms cv=0.138; latency_p99_ms cv=0.139; throughput_per_second cv=0.091
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.050; latency_p95_ms cv=0.220; latency_p99_ms cv=0.234; throughput_per_second cv=0.060
- `total_rows via columnar`: throughput_per_second cv=0.075
- `group_by_category via columnar`: latency_p50_ms cv=0.064; latency_p95_ms cv=0.070; latency_p99_ms cv=0.070; throughput_per_second cv=0.063
- `filtered_sum via columnar`: latency_p50_ms cv=0.063; latency_p95_ms cv=0.065; latency_p99_ms cv=0.065; throughput_per_second cv=0.072

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 10.08, 10.19, 10.12
- `total_rows via row` latency_p95_ms: 10.18, 10.31, 10.15
- `total_rows via row` latency_p99_ms: 10.19, 10.32, 10.16
- `total_rows via row` throughput_per_second: 100.2, 98.65, 99.85
- `sum_amount via row` latency_p50_ms: 12.77, 12.85, 12.73
- `sum_amount via row` latency_p95_ms: 12.81, 12.87, 12.8
- `sum_amount via row` latency_p99_ms: 12.82, 12.88, 12.81
- `sum_amount via row` throughput_per_second: 79.89, 78.77, 78.91
- `group_by_category via row` latency_p50_ms: 24.71, 24.31, 24.93
- `group_by_category via row` latency_p95_ms: 27.06, 24.99, 26.19
- `group_by_category via row` latency_p99_ms: 27.27, 25.05, 26.3
- `group_by_category via row` throughput_per_second: 41.21, 41.18, 40.76
- `filtered_sum via row` latency_p50_ms: 19.49, 15.61, 15.86
- `filtered_sum via row` latency_p95_ms: 20.19, 15.75, 16.33
- `filtered_sum via row` latency_p99_ms: 20.25, 15.77, 16.37
- `filtered_sum via row` throughput_per_second: 54.25, 64.1, 63.56
- `numeric_filtered_sum via row` latency_p50_ms: 14.23, 15.73, 15.05
- `numeric_filtered_sum via row` latency_p95_ms: 14.78, 21.54, 15.23
- `numeric_filtered_sum via row` latency_p99_ms: 14.83, 22.06, 15.24
- `numeric_filtered_sum via row` throughput_per_second: 71.89, 63.94, 66.46
- `total_rows via columnar` latency_p50_ms: 1.931, 1.972, 1.947
- `total_rows via columnar` latency_p95_ms: 1.991, 2.066, 1.972
- `total_rows via columnar` latency_p99_ms: 1.996, 2.075, 1.974
- `total_rows via columnar` throughput_per_second: 559.6, 514, 597.6
- `sum_amount via columnar` latency_p50_ms: 3.824, 3.788, 3.663
- `sum_amount via columnar` latency_p95_ms: 3.965, 4.053, 3.731
- `sum_amount via columnar` latency_p99_ms: 3.978, 4.077, 3.737
- `sum_amount via columnar` throughput_per_second: 262.9, 267.3, 273.7
- `group_by_category via columnar` latency_p50_ms: 22.43, 25.05, 25.2
- `group_by_category via columnar` latency_p95_ms: 22.5, 25.5, 25.43
- `group_by_category via columnar` latency_p99_ms: 22.51, 25.54, 25.45
- `group_by_category via columnar` throughput_per_second: 44.72, 40.19, 40.13
- `filtered_sum via columnar` latency_p50_ms: 22.11, 24.72, 24.74
- `filtered_sum via columnar` latency_p95_ms: 22.29, 24.73, 25.17
- `filtered_sum via columnar` latency_p99_ms: 22.3, 24.73, 25.2
- `filtered_sum via columnar` throughput_per_second: 46.12, 40.8, 40.82
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.619, 6.751, 6.534
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.677, 6.955, 6.698
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.682, 6.973, 6.713
- `numeric_filtered_sum via columnar` throughput_per_second: 152.8, 154.6, 153.6
- `total_rows via parquet` latency_p50_ms: 542.8, 544.7, 561.1
- `total_rows via parquet` latency_p95_ms: 544.1, 552.1, 562
- `total_rows via parquet` latency_p99_ms: 544.2, 552.8, 562.1
- `total_rows via parquet` throughput_per_second: 1.849, 1.848, 1.804
- `sum_amount via parquet` latency_p50_ms: 601.1, 609.4, 607.5
- `sum_amount via parquet` latency_p95_ms: 604, 610.6, 610.9
- `sum_amount via parquet` latency_p99_ms: 604.2, 610.7, 611.3
- `sum_amount via parquet` throughput_per_second: 1.684, 1.647, 1.652
- `group_by_category via parquet` latency_p50_ms: 635, 643.5, 639.2
- `group_by_category via parquet` latency_p95_ms: 638.2, 644.4, 643.3
- `group_by_category via parquet` latency_p99_ms: 638.4, 644.5, 643.7
- `group_by_category via parquet` throughput_per_second: 1.581, 1.559, 1.571
- `filtered_sum via parquet` latency_p50_ms: 579, 582.4, 589.4
- `filtered_sum via parquet` latency_p95_ms: 581.8, 588.5, 591.7
- `filtered_sum via parquet` latency_p99_ms: 582.1, 589.1, 591.9
- `filtered_sum via parquet` throughput_per_second: 1.73, 1.723, 1.697
- `numeric_filtered_sum via parquet` latency_p50_ms: 594, 596.2, 601.4
- `numeric_filtered_sum via parquet` latency_p95_ms: 597.2, 596.2, 603.1
- `numeric_filtered_sum via parquet` latency_p99_ms: 597.4, 596.3, 603.3
- `numeric_filtered_sum via parquet` throughput_per_second: 1.684, 1.698, 1.675

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T195054Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 1b2c47e5f33d184b5f7d3dae09d606bfabaa6f7e (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

