# vector/glove/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T195847Z-vector-glove-hnsw-theodb-ddbbcbc5`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,023 | 0.6444 | 0.862 | 1.109 | 1.257 | yes |
| hnsw m=16 ef_search=64 | 856.6 | 0.7782 | 1.032 | 1.463 | 1.681 | yes |
| hnsw m=16 ef_search=256 | 345.8 | 0.9136 | 2.775 | 3.49 | 3.76 | yes |
| hnsw m=16 ef_search=512 | 217.9 | 0.9578 | 4.549 | 5.608 | 6.053 | **no** |
| hnsw m=16 ef_search=1000 | 107.3 | 0.9844 | 9.342 | 11.63 | 12.52 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=512`: latency_p99_ms cv=0.059

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 33.65
- `hnsw m=16 ef_search=16` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.862, 0.853, 0.8889
- `hnsw m=16 ef_search=16` latency_p95_ms: 1.079, 1.109, 1.142
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.193, 1.26, 1.257
- `hnsw m=16 ef_search=16` recall: 0.6444, 0.6444, 0.6444
- `hnsw m=16 ef_search=16` throughput_per_second: 1,023, 1,024, 991.7
- `hnsw m=16 ef_search=64` build_seconds: 33.77
- `hnsw m=16 ef_search=64` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.027, 1.044, 1.032
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.434, 1.508, 1.463
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.681, 1.693, 1.63
- `hnsw m=16 ef_search=64` recall: 0.7782, 0.7782, 0.7782
- `hnsw m=16 ef_search=64` throughput_per_second: 866.1, 822.6, 856.6
- `hnsw m=16 ef_search=256` build_seconds: 33.91
- `hnsw m=16 ef_search=256` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.794, 2.763, 2.775
- `hnsw m=16 ef_search=256` latency_p95_ms: 3.521, 3.443, 3.49
- `hnsw m=16 ef_search=256` latency_p99_ms: 3.745, 3.76, 3.85
- `hnsw m=16 ef_search=256` recall: 0.9136, 0.9136, 0.9136
- `hnsw m=16 ef_search=256` throughput_per_second: 345.8, 348.4, 345.6
- `hnsw m=16 ef_search=512` build_seconds: 33.18
- `hnsw m=16 ef_search=512` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 4.57, 4.362, 4.549
- `hnsw m=16 ef_search=512` latency_p95_ms: 5.608, 5.358, 5.709
- `hnsw m=16 ef_search=512` latency_p99_ms: 6.053, 5.521, 6.177
- `hnsw m=16 ef_search=512` recall: 0.9578, 0.9578, 0.9578
- `hnsw m=16 ef_search=512` throughput_per_second: 217.6, 227.1, 217.9
- `hnsw m=16 ef_search=1000` build_seconds: 34.15
- `hnsw m=16 ef_search=1000` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 9.342, 9.392, 9.228
- `hnsw m=16 ef_search=1000` latency_p95_ms: 11.81, 11.63, 11.48
- `hnsw m=16 ef_search=1000` latency_p99_ms: 12.57, 12.52, 12.15
- `hnsw m=16 ef_search=1000` recall: 0.9844, 0.9844, 0.9844
- `hnsw m=16 ef_search=1000` throughput_per_second: 106.6, 107.3, 109

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T195054Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 1b2c47e5f33d184b5f7d3dae09d606bfabaa6f7e (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

