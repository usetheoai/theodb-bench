# vector/sift/scann-ah on alloydbomni

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T162533Z-vector-sift-scann-ah-alloydbomni-b451c8e6`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25 | 1,547 | 0.6528 | 0.5655 | 0.6355 | 0.712 | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100 | 1,166 | 0.7204 | 0.7614 | 0.867 | 0.964 | **no** |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400 | 727.8 | 0.7112 | 1.292 | 1.422 | 1.5 | **no** |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25 | 1,136 | 0.8754 | 0.8056 | 0.8966 | 0.9705 | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100 | 958.9 | 0.952 | 0.9662 | 1.051 | 1.111 | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400 | 600 | 0.9568 | 1.581 | 1.742 | 1.818 | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25 | 640.8 | 0.9002 | 1.478 | 1.611 | 1.682 | **no** |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100 | 549.3 | 0.9962 | 1.733 | 1.904 | 2.038 | yes |
| scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400 | 422 | 1 | 2.279 | 2.469 | 2.631 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100`: latency_p99_ms cv=0.082
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.064
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25`: latency_p99_ms cv=0.186

### Repetitions

Every repetition is retained:

- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` build_seconds: 2.916, 2.916, 2.916
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` index_size_bytes: 5.849e+06, 5.849e+06, 5.849e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` latency_p50_ms: 0.573, 0.5655, 0.5599
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` latency_p95_ms: 0.6355, 0.6431, 0.6284
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` latency_p99_ms: 0.712, 0.7122, 0.6751
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` recall: 0.6528, 0.6528, 0.6528
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=25` throughput_per_second: 1,547, 1,545, 1,571
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` build_seconds: 2.927, 2.927, 2.927
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` index_size_bytes: 5.833e+06, 5.833e+06, 5.833e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` latency_p50_ms: 0.7342, 0.7614, 0.773
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` latency_p95_ms: 0.8005, 0.8689, 0.867
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` latency_p99_ms: 0.8801, 1.036, 0.964
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` recall: 0.7204, 0.7204, 0.7204
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=100` throughput_per_second: 1,233, 1,132, 1,166
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` build_seconds: 2.883, 2.883, 2.883
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` index_size_bytes: 5.882e+06, 5.882e+06, 5.882e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` latency_p50_ms: 1.266, 1.353, 1.292
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` latency_p95_ms: 1.359, 1.512, 1.422
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` latency_p99_ms: 1.415, 1.608, 1.5
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` recall: 0.7112, 0.7112, 0.7112
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=5 pre_reordering_num_neighbors=400` throughput_per_second: 746, 693.4, 727.8
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` build_seconds: 2.867, 2.867, 2.867
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` index_size_bytes: 5.906e+06, 5.906e+06, 5.906e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` latency_p50_ms: 0.8056, 0.8146, 0.805
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` latency_p95_ms: 0.8905, 0.9302, 0.8966
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` latency_p99_ms: 0.9245, 0.9947, 0.9705
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` recall: 0.8754, 0.8754, 0.8754
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=25` throughput_per_second: 1,136, 1,115, 1,138
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` build_seconds: 2.933, 2.933, 2.933
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` index_size_bytes: 5.816e+06, 5.816e+06, 5.816e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` latency_p50_ms: 0.9662, 0.9532, 0.9667
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` latency_p95_ms: 1.051, 1.032, 1.08
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` latency_p99_ms: 1.111, 1.074, 1.153
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` recall: 0.952, 0.952, 0.952
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=100` throughput_per_second: 958.9, 970.1, 951.4
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` build_seconds: 2.884, 2.884, 2.884
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` index_size_bytes: 5.743e+06, 5.743e+06, 5.743e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` latency_p50_ms: 1.583, 1.581, 1.539
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` latency_p95_ms: 1.742, 1.75, 1.646
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` latency_p99_ms: 1.818, 1.885, 1.719
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` recall: 0.9568, 0.9568, 0.9568
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=20 pre_reordering_num_neighbors=400` throughput_per_second: 600, 598.9, 619.1
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` build_seconds: 3.027, 3.027, 3.027
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` index_size_bytes: 5.825e+06, 5.825e+06, 5.825e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` latency_p50_ms: 1.474, 1.478, 1.49
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` latency_p95_ms: 1.59, 1.611, 1.665
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` latency_p99_ms: 1.682, 1.679, 2.287
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` recall: 0.9002, 0.9002, 0.9002
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=25` throughput_per_second: 642, 640.8, 629.8
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` build_seconds: 2.895, 2.895, 2.895
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` index_size_bytes: 5.849e+06, 5.849e+06, 5.849e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` latency_p50_ms: 1.715, 1.74, 1.733
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` latency_p95_ms: 1.866, 1.904, 1.91
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` latency_p99_ms: 1.946, 2.038, 2.106
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` recall: 0.9962, 0.9962, 0.9962
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=100` throughput_per_second: 557.6, 547.5, 549.3
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` build_seconds: 2.874, 2.874, 2.874
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` index_size_bytes: 5.882e+06, 5.882e+06, 5.882e+06
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` latency_p50_ms: 2.215, 2.279, 2.303
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` latency_p95_ms: 2.395, 2.469, 2.531
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` latency_p99_ms: 2.509, 2.655, 2.631
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` recall: 1, 1, 1
- `scann num_leaves=316 quantizer=AH num_leaves_to_search=80 pre_reordering_num_neighbors=400` throughput_per_second: 435, 422, 416.6

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T161640Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 1470c475acc9f0564d293a6086330e4d26197e3d (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

