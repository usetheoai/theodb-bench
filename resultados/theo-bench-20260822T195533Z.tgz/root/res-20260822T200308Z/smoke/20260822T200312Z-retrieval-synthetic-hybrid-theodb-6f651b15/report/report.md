# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T200312Z-retrieval-synthetic-hybrid-theodb-6f651b15`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,127 | _not measured_ | 0.7972 | 0.9368 | 1.067 | **no** |
| pipeline=vector | 197.4 | _not measured_ | 4.742 | 4.933 | 5.1 | **no** |
| pipeline=hybrid_rrf | 31.76 | _not measured_ | 29.87 | 38.75 | 40.63 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=lexical`: latency_p99_ms cv=0.059
- `pipeline=vector`: latency_p99_ms cv=0.111

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.7869, 0.7882, 0.8054, 0.8118, 0.7972
- `pipeline=lexical` latency_p95_ms: 0.9368, 0.9077, 0.9473, 0.987, 0.9292
- `pipeline=lexical` latency_p99_ms: 1.085, 0.9702, 1.067, 1.083, 0.9652
- `pipeline=lexical` mrr: 0.06323, 0.06323, 0.06323, 0.06323, 0.06323
- `pipeline=lexical` ndcg_at_10: 0.07518, 0.07518, 0.07518, 0.07518, 0.07518
- `pipeline=lexical` recall_at_k: 0.09667, 0.09667, 0.09667, 0.09667, 0.09667
- `pipeline=lexical` throughput_per_second: 1,127, 1,145, 1,117, 1,109, 1,132
- `pipeline=vector` latency_p50_ms: 4.761, 4.826, 4.738, 4.742, 4.715
- `pipeline=vector` latency_p95_ms: 4.962, 5.011, 4.925, 4.933, 4.89
- `pipeline=vector` latency_p99_ms: 5.1, 5.133, 6.35, 5.023, 4.928
- `pipeline=vector` mrr: 1, 1, 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.432, 1.448, 1.433, 1.425, 1.416
- `pipeline=vector` throughput_per_second: 197.2, 195, 197.4, 198.5, 199.6
- `pipeline=hybrid_rrf` latency_p50_ms: 29.62, 29.87, 29.87, 29.92, 29.73
- `pipeline=hybrid_rrf` latency_p95_ms: 38.6, 38.67, 38.77, 39.35, 38.75
- `pipeline=hybrid_rrf` latency_p99_ms: 40.54, 40.63, 40.9, 41.18, 40.12
- `pipeline=hybrid_rrf` mrr: 0.7731, 0.7731, 0.7731, 0.7731, 0.7731
- `pipeline=hybrid_rrf` ndcg_at_10: 0.6868, 0.6868, 0.6868, 0.6868, 0.6868
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 31.82, 31.74, 31.76, 31.59, 31.82

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T195533Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 77daeae9fc758690eaba12a58cdd0d19677c22a1 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

