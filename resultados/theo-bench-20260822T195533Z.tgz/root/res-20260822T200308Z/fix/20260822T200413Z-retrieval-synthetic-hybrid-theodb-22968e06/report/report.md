# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T200413Z-retrieval-synthetic-hybrid-theodb-22968e06`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,118 | _not measured_ | 0.8046 | 0.9534 | 1.027 | **no** |
| pipeline=vector | 199.2 | _not measured_ | 4.726 | 4.917 | 5.035 | yes |
| pipeline=hybrid_rrf | 31.89 | _not measured_ | 30.09 | 38.02 | 39.54 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=lexical`: latency_p99_ms cv=0.054

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.7876, 0.7897, 0.8085, 0.8149, 0.8046
- `pipeline=lexical` latency_p95_ms: 0.9517, 0.9159, 0.9534, 0.9695, 0.9566
- `pipeline=lexical` latency_p99_ms: 1.012, 1.018, 1.038, 1.027, 1.148
- `pipeline=lexical` mrr: 0.06323, 0.06323, 0.06323, 0.06323, 0.06323
- `pipeline=lexical` ndcg_at_10: 0.07518, 0.07518, 0.07518, 0.07518, 0.07518
- `pipeline=lexical` recall_at_k: 0.09667, 0.09667, 0.09667, 0.09667, 0.09667
- `pipeline=lexical` throughput_per_second: 1,134, 1,139, 1,115, 1,101, 1,118
- `pipeline=vector` latency_p50_ms: 4.726, 4.735, 4.653, 4.691, 4.778
- `pipeline=vector` latency_p95_ms: 4.908, 4.917, 4.823, 4.917, 4.924
- `pipeline=vector` latency_p99_ms: 5.035, 5.052, 4.982, 5.037, 5.031
- `pipeline=vector` mrr: 1, 1, 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.421, 1.422, 1.398, 1.411, 1.436
- `pipeline=vector` throughput_per_second: 199.2, 199, 202.3, 200.5, 196.8
- `pipeline=hybrid_rrf` latency_p50_ms: 30.09, 30.13, 29.98, 30.07, 30.21
- `pipeline=hybrid_rrf` latency_p95_ms: 38.02, 38.1, 37.82, 37.88, 38.02
- `pipeline=hybrid_rrf` latency_p99_ms: 39.33, 39.72, 39.54, 39.68, 39.41
- `pipeline=hybrid_rrf` mrr: 0.7731, 0.7731, 0.7731, 0.7731, 0.7731
- `pipeline=hybrid_rrf` ndcg_at_10: 0.6868, 0.6868, 0.6868, 0.6868, 0.6868
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 31.96, 31.83, 31.89, 31.94, 31.86

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T195533Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 77daeae9fc758690eaba12a58cdd0d19677c22a1 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

