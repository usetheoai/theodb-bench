# vector/glove/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260825T024437Z-vector-glove-hnsw-theodb-80c25de7`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,166 | 0.6454 | 0.7418 | 0.945 | 1.082 | yes |
| hnsw m=16 ef_search=64 | 1,026 | 0.7738 | 0.8457 | 1.153 | 1.451 | yes |
| hnsw m=16 ef_search=256 | 425.6 | 0.914 | 2.254 | 2.812 | 3.079 | yes |
| hnsw m=16 ef_search=512 | 259.9 | 0.957 | 3.837 | 4.69 | 4.901 | yes |
| hnsw m=16 ef_search=1000 | 148 | 0.9828 | 6.823 | 8.514 | 9.115 | yes |

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 21.66
- `hnsw m=16 ef_search=16` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.7418, 0.7495, 0.7053
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.945, 0.9581, 0.8945
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.007, 1.082, 1.087
- `hnsw m=16 ef_search=16` recall: 0.6454, 0.6454, 0.6454
- `hnsw m=16 ef_search=16` throughput_per_second: 1,166, 1,149, 1,217
- `hnsw m=16 ef_search=64` build_seconds: 21.88
- `hnsw m=16 ef_search=64` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.8457, 0.8452, 0.8496
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.153, 1.149, 1.161
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.443, 1.536, 1.451
- `hnsw m=16 ef_search=64` recall: 0.7738, 0.7738, 0.7738
- `hnsw m=16 ef_search=64` throughput_per_second: 1,035, 1,004, 1,026
- `hnsw m=16 ef_search=256` build_seconds: 21.7
- `hnsw m=16 ef_search=256` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.213, 2.254, 2.305
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.711, 2.812, 2.895
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.876, 3.079, 3.118
- `hnsw m=16 ef_search=256` recall: 0.914, 0.914, 0.914
- `hnsw m=16 ef_search=256` throughput_per_second: 436.7, 425.6, 415.8
- `hnsw m=16 ef_search=512` build_seconds: 21.64
- `hnsw m=16 ef_search=512` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.882, 3.805, 3.837
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.752, 4.69, 4.654
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.901, 4.89, 5.028
- `hnsw m=16 ef_search=512` recall: 0.957, 0.957, 0.957
- `hnsw m=16 ef_search=512` throughput_per_second: 255.5, 260.4, 259.9
- `hnsw m=16 ef_search=1000` build_seconds: 21.62
- `hnsw m=16 ef_search=1000` index_size_bytes: 6.445e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 6.86, 6.823, 6.643
- `hnsw m=16 ef_search=1000` latency_p95_ms: 8.611, 8.514, 8.251
- `hnsw m=16 ef_search=1000` latency_p99_ms: 9.506, 9.115, 8.778
- `hnsw m=16 ef_search=1000` recall: 0.9828, 0.9828, 0.9828
- `hnsw m=16 ef_search=1000` throughput_per_second: 147.3, 148, 151.5

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260825T023708Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e99819b4b13d373a52ced151e449b6cf4118950b (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

