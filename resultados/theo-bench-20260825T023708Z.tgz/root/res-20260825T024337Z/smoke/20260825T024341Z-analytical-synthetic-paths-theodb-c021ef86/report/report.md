# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260825T024341Z-analytical-synthetic-paths-theodb-c021ef86`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 120 | _not measured_ | 8.608 | 9.354 | 9.431 | yes |
| sum_amount via row | 88.65 | _not measured_ | 11.35 | 11.48 | 11.49 | yes |
| group_by_category via row | 46.53 | _not measured_ | 21.54 | 21.72 | 21.74 | yes |
| filtered_sum via row | 74.9 | _not measured_ | 13.62 | 13.81 | 13.83 | **no** |
| numeric_filtered_sum via row | 80.34 | _not measured_ | 12.92 | 18.27 | 18.73 | **no** |
| total_rows via columnar | 587 | _not measured_ | 1.709 | 1.863 | 1.878 | yes |
| sum_amount via columnar | 282.3 | _not measured_ | 3.579 | 3.654 | 3.673 | yes |
| group_by_category via columnar | 42.87 | _not measured_ | 23.34 | 23.49 | 23.51 | **no** |
| filtered_sum via columnar | 44.7 | _not measured_ | 22.46 | 22.51 | 22.52 | **no** |
| numeric_filtered_sum via columnar | 167.4 | _not measured_ | 6.071 | 6.214 | 6.217 | yes |
| total_rows via parquet | 1.882 | _not measured_ | 536.2 | 541.3 | 541.9 | yes |
| sum_amount via parquet | 1.699 | _not measured_ | 591.5 | 594.6 | 594.9 | yes |
| group_by_category via parquet | 1.579 | _not measured_ | 642.8 | 648.5 | 649 | yes |
| filtered_sum via parquet | 1.751 | _not measured_ | 574.7 | 582 | 582.7 | yes |
| numeric_filtered_sum via parquet | 1.722 | _not measured_ | 583.1 | 595.3 | 596.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via row`: latency_p95_ms cv=0.255; latency_p99_ms cv=0.272
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.211; latency_p99_ms cv=0.223
- `group_by_category via columnar`: latency_p50_ms cv=0.054; latency_p95_ms cv=0.059; latency_p99_ms cv=0.059; throughput_per_second cv=0.063
- `filtered_sum via columnar`: throughput_per_second cv=0.071

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.005, 8.494, 8.608
- `total_rows via row` latency_p95_ms: 9.813, 9.354, 9.16
- `total_rows via row` latency_p99_ms: 9.884, 9.431, 9.209
- `total_rows via row` throughput_per_second: 113.2, 120, 120
- `sum_amount via row` latency_p50_ms: 11.35, 10.93, 11.58
- `sum_amount via row` latency_p95_ms: 11.48, 11, 11.86
- `sum_amount via row` latency_p99_ms: 11.49, 11.01, 11.89
- `sum_amount via row` throughput_per_second: 88.65, 92.48, 87.19
- `group_by_category via row` latency_p50_ms: 21.54, 21.23, 22.24
- `group_by_category via row` latency_p95_ms: 21.72, 21.23, 22.52
- `group_by_category via row` latency_p99_ms: 21.74, 21.23, 22.54
- `group_by_category via row` throughput_per_second: 46.53, 48.18, 46.32
- `filtered_sum via row` latency_p50_ms: 14.34, 13.43, 13.62
- `filtered_sum via row` latency_p95_ms: 20.96, 13.79, 13.81
- `filtered_sum via row` latency_p99_ms: 21.55, 13.82, 13.83
- `filtered_sum via row` throughput_per_second: 71.84, 77.21, 74.9
- `numeric_filtered_sum via row` latency_p50_ms: 13.1, 12.27, 12.92
- `numeric_filtered_sum via row` latency_p95_ms: 18.27, 12.33, 18.33
- `numeric_filtered_sum via row` latency_p99_ms: 18.73, 12.34, 18.81
- `numeric_filtered_sum via row` throughput_per_second: 80.34, 83.12, 78.24
- `total_rows via columnar` latency_p50_ms: 1.709, 1.759, 1.695
- `total_rows via columnar` latency_p95_ms: 1.858, 1.993, 1.863
- `total_rows via columnar` latency_p99_ms: 1.872, 2.014, 1.878
- `total_rows via columnar` throughput_per_second: 587, 580.2, 596.2
- `sum_amount via columnar` latency_p50_ms: 3.579, 3.64, 3.444
- `sum_amount via columnar` latency_p95_ms: 3.611, 3.896, 3.654
- `sum_amount via columnar` latency_p99_ms: 3.614, 3.919, 3.673
- `sum_amount via columnar` throughput_per_second: 282.3, 281.6, 292.1
- `group_by_category via columnar` latency_p50_ms: 21.26, 23.41, 23.34
- `group_by_category via columnar` latency_p95_ms: 21.43, 23.96, 23.49
- `group_by_category via columnar` latency_p99_ms: 21.44, 24, 23.51
- `group_by_category via columnar` throughput_per_second: 47.68, 42.86, 42.87
- `filtered_sum via columnar` latency_p50_ms: 21.7, 23.58, 22.46
- `filtered_sum via columnar` latency_p95_ms: 22.45, 24.27, 22.51
- `filtered_sum via columnar` latency_p99_ms: 22.51, 24.33, 22.52
- `filtered_sum via columnar` throughput_per_second: 49.23, 42.94, 44.7
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.186, 6.071, 5.666
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.214, 6.275, 5.948
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.217, 6.293, 5.973
- `numeric_filtered_sum via columnar` throughput_per_second: 164.5, 167.4, 176.7
- `total_rows via parquet` latency_p50_ms: 534.6, 536.2, 545
- `total_rows via parquet` latency_p95_ms: 541.3, 538.4, 546.9
- `total_rows via parquet` latency_p99_ms: 541.9, 538.6, 547.1
- `total_rows via parquet` throughput_per_second: 1.891, 1.869, 1.882
- `sum_amount via parquet` latency_p50_ms: 590.5, 591.5, 604.1
- `sum_amount via parquet` latency_p95_ms: 594.6, 594.5, 611.1
- `sum_amount via parquet` latency_p99_ms: 594.9, 594.8, 611.7
- `sum_amount via parquet` throughput_per_second: 1.706, 1.699, 1.668
- `group_by_category via parquet` latency_p50_ms: 617.4, 651.2, 642.8
- `group_by_category via parquet` latency_p95_ms: 625.5, 668.4, 648.5
- `group_by_category via parquet` latency_p99_ms: 626.2, 669.9, 649
- `group_by_category via parquet` throughput_per_second: 1.628, 1.579, 1.576
- `filtered_sum via parquet` latency_p50_ms: 574.7, 573.4, 580.6
- `filtered_sum via parquet` latency_p95_ms: 582, 583, 580.7
- `filtered_sum via parquet` latency_p99_ms: 582.7, 583.9, 580.7
- `filtered_sum via parquet` throughput_per_second: 1.755, 1.751, 1.73
- `numeric_filtered_sum via parquet` latency_p50_ms: 583, 583.1, 594.4
- `numeric_filtered_sum via parquet` latency_p95_ms: 595.3, 584.3, 596.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 596.4, 584.4, 596.5
- `numeric_filtered_sum via parquet` throughput_per_second: 1.737, 1.722, 1.693

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260825T023708Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e99819b4b13d373a52ced151e449b6cf4118950b (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

