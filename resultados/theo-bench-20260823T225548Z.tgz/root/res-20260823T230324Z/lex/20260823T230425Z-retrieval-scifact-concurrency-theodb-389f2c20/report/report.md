# retrieval/scifact/concurrency on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T230425Z-retrieval-scifact-concurrency-theodb-389f2c20`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical @ 1 clientes | 341 | _not measured_ | 2.762 | 3.351 | 3.622 | **no** |
| pipeline=lexical @ 5 clientes | 1,499 | _not measured_ | 3.032 | 4.111 | 4.949 | **no** |
| pipeline=lexical @ 10 clientes | 2,241 | _not measured_ | 4.131 | 5.76 | 8.554 | **no** |
| pipeline=lexical @ 20 clientes | 1,321 | _not measured_ | 12.69 | 32.54 | 47.36 | **no** |
| pipeline=lexical @ 40 clientes | 1,547 | _not measured_ | 21.31 | 57.06 | 79.25 | yes |
| pipeline=lexical @ 80 clientes | 1,717 | _not measured_ | 37.44 | 106.3 | 146.3 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=lexical @ 1 clientes`: latency_p95_ms cv=0.065; latency_p99_ms cv=0.071
- `pipeline=lexical @ 5 clientes`: latency_p99_ms cv=0.067
- `pipeline=lexical @ 10 clientes`: latency_p95_ms cv=0.059; latency_p99_ms cv=0.125
- `pipeline=lexical @ 20 clientes`: latency_p99_ms cv=0.063

### Repetitions

Every repetition is retained:

- `pipeline=lexical @ 1 clientes` latency_p50_ms: 2.706, 2.762, 2.813
- `pipeline=lexical @ 1 clientes` latency_p95_ms: 3.612, 3.173, 3.351
- `pipeline=lexical @ 1 clientes` latency_p99_ms: 3.917, 3.403, 3.622
- `pipeline=lexical @ 1 clientes` mrr: 0.6493, 0.6493, 0.6493
- `pipeline=lexical @ 1 clientes` ndcg_at_10: 0.6864, 0.6864, 0.6864
- `pipeline=lexical @ 1 clientes` recall_at_k: 0.8227, 0.8227, 0.8227
- `pipeline=lexical @ 1 clientes` throughput_per_second: 341, 343.2, 333.1
- `pipeline=lexical @ 5 clientes` latency_p50_ms: 2.998, 3.062, 3.032
- `pipeline=lexical @ 5 clientes` latency_p95_ms: 3.877, 4.206, 4.111
- `pipeline=lexical @ 5 clientes` latency_p99_ms: 4.949, 4.843, 5.481
- `pipeline=lexical @ 5 clientes` stage_response_p50_ms_seconds: 2.998, 3.062, 3.032
- `pipeline=lexical @ 5 clientes` stage_service_p50_ms_seconds: 2.998, 3.062, 3.032
- `pipeline=lexical @ 5 clientes` throughput_per_second: 1,532, 1,499, 1,483
- `pipeline=lexical @ 10 clientes` latency_p50_ms: 4.06, 4.131, 4.17
- `pipeline=lexical @ 10 clientes` latency_p95_ms: 5.372, 5.76, 6.05
- `pipeline=lexical @ 10 clientes` latency_p99_ms: 6.869, 8.64, 8.554
- `pipeline=lexical @ 10 clientes` stage_response_p50_ms_seconds: 4.061, 4.132, 4.171
- `pipeline=lexical @ 10 clientes` stage_service_p50_ms_seconds: 4.061, 4.132, 4.171
- `pipeline=lexical @ 10 clientes` throughput_per_second: 2,308, 2,241, 2,205
- `pipeline=lexical @ 20 clientes` latency_p50_ms: 12.89, 12.42, 12.69
- `pipeline=lexical @ 20 clientes` latency_p95_ms: 34.53, 32.54, 32.15
- `pipeline=lexical @ 20 clientes` latency_p99_ms: 51.4, 47.36, 45.44
- `pipeline=lexical @ 20 clientes` stage_response_p50_ms_seconds: 12.89, 12.42, 12.7
- `pipeline=lexical @ 20 clientes` stage_service_p50_ms_seconds: 12.89, 12.42, 12.7
- `pipeline=lexical @ 20 clientes` throughput_per_second: 1,276, 1,342, 1,321
- `pipeline=lexical @ 40 clientes` latency_p50_ms: 21.4, 21.06, 21.31
- `pipeline=lexical @ 40 clientes` latency_p95_ms: 57.06, 56.63, 57.64
- `pipeline=lexical @ 40 clientes` latency_p99_ms: 79.25, 81.53, 77.76
- `pipeline=lexical @ 40 clientes` stage_response_p50_ms_seconds: 21.4, 21.06, 21.31
- `pipeline=lexical @ 40 clientes` stage_service_p50_ms_seconds: 21.4, 21.06, 21.31
- `pipeline=lexical @ 40 clientes` throughput_per_second: 1,547, 1,563, 1,537
- `pipeline=lexical @ 80 clientes` latency_p50_ms: 37.61, 37.44, 37.22
- `pipeline=lexical @ 80 clientes` latency_p95_ms: 106.3, 106.4, 105.3
- `pipeline=lexical @ 80 clientes` latency_p99_ms: 146.3, 149, 144.5
- `pipeline=lexical @ 80 clientes` stage_response_p50_ms_seconds: 37.61, 37.45, 37.23
- `pipeline=lexical @ 80 clientes` stage_service_p50_ms_seconds: 37.61, 37.45, 37.23
- `pipeline=lexical @ 80 clientes` throughput_per_second: 1,707, 1,717, 1,720

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T225548Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424534528 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e33e1ade0d002e02afd40f98201d1fabd1ad04e4 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

