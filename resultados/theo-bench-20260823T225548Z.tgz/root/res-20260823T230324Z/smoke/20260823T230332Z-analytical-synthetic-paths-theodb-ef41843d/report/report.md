# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T230332Z-analytical-synthetic-paths-theodb-ef41843d`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 90.31 | _not measured_ | 11.42 | 11.89 | 11.93 | **no** |
| sum_amount via row | 71.62 | _not measured_ | 14.8 | 17.88 | 18.07 | **no** |
| group_by_category via row | 36.03 | _not measured_ | 28.73 | 28.89 | 28.91 | **no** |
| filtered_sum via row | 54.71 | _not measured_ | 18.51 | 19.71 | 19.76 | **no** |
| numeric_filtered_sum via row | 57.21 | _not measured_ | 18.75 | 18.75 | 18.75 | yes |
| total_rows via columnar | 412.7 | _not measured_ | 2.481 | 2.584 | 2.588 | yes |
| sum_amount via columnar | 208.1 | _not measured_ | 4.912 | 5.346 | 5.384 | **no** |
| group_by_category via columnar | 34.8 | _not measured_ | 30.06 | 31.45 | 31.57 | **no** |
| filtered_sum via columnar | 36.9 | _not measured_ | 29.19 | 29.97 | 30.03 | yes |
| numeric_filtered_sum via columnar | 124 | _not measured_ | 8.438 | 8.675 | 8.696 | **no** |
| total_rows via parquet | 1.61 | _not measured_ | 628.5 | 630.9 | 632.7 | yes |
| sum_amount via parquet | 1.473 | _not measured_ | 689.9 | 700.4 | 701.8 | yes |
| group_by_category via parquet | 1.399 | _not measured_ | 730.6 | 738.5 | 739.2 | yes |
| filtered_sum via parquet | 1.511 | _not measured_ | 669.5 | 675.8 | 676.4 | yes |
| numeric_filtered_sum via parquet | 1.498 | _not measured_ | 695.9 | 700.7 | 700.7 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p50_ms cv=0.195; latency_p95_ms cv=0.202; latency_p99_ms cv=0.202; throughput_per_second cv=0.075
- `sum_amount via row`: latency_p95_ms cv=0.063; latency_p99_ms cv=0.068
- `group_by_category via row`: latency_p99_ms cv=0.051
- `filtered_sum via row`: latency_p95_ms cv=0.058; latency_p99_ms cv=0.064
- `sum_amount via columnar`: latency_p50_ms cv=0.079; latency_p95_ms cv=0.081; latency_p99_ms cv=0.082
- `group_by_category via columnar`: latency_p50_ms cv=0.051; latency_p95_ms cv=0.063; latency_p99_ms cv=0.064; throughput_per_second cv=0.091
- `numeric_filtered_sum via columnar`: latency_p95_ms cv=0.096; latency_p99_ms cv=0.101

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 15.42, 11.42, 10.95
- `total_rows via row` latency_p95_ms: 16.2, 11.89, 11.36
- `total_rows via row` latency_p99_ms: 16.27, 11.93, 11.4
- `total_rows via row` throughput_per_second: 81.53, 90.31, 94.51
- `sum_amount via row` latency_p50_ms: 14.8, 14.67, 15.74
- `sum_amount via row` latency_p95_ms: 17.53, 19.67, 17.88
- `sum_amount via row` latency_p99_ms: 17.77, 20.12, 18.07
- `sum_amount via row` throughput_per_second: 69.97, 71.99, 71.62
- `group_by_category via row` latency_p50_ms: 28.83, 28.73, 28.15
- `group_by_category via row` latency_p95_ms: 31.2, 28.89, 28.63
- `group_by_category via row` latency_p99_ms: 31.41, 28.91, 28.67
- `group_by_category via row` throughput_per_second: 36.81, 35.04, 36.03
- `filtered_sum via row` latency_p50_ms: 18.51, 18.39, 19.24
- `filtered_sum via row` latency_p95_ms: 19.66, 21.72, 19.71
- `filtered_sum via row` latency_p99_ms: 19.76, 22.02, 19.75
- `filtered_sum via row` throughput_per_second: 55.54, 54.71, 54.15
- `numeric_filtered_sum via row` latency_p50_ms: 18.87, 18.75, 18.15
- `numeric_filtered_sum via row` latency_p95_ms: 19.2, 18.75, 18.45
- `numeric_filtered_sum via row` latency_p99_ms: 19.22, 18.75, 18.48
- `numeric_filtered_sum via row` throughput_per_second: 57.4, 54.02, 57.21
- `total_rows via columnar` latency_p50_ms: 2.481, 2.548, 2.449
- `total_rows via columnar` latency_p95_ms: 2.585, 2.584, 2.56
- `total_rows via columnar` latency_p99_ms: 2.594, 2.588, 2.57
- `total_rows via columnar` throughput_per_second: 408.2, 412.7, 418.9
- `sum_amount via columnar` latency_p50_ms: 4.669, 4.912, 5.438
- `sum_amount via columnar` latency_p95_ms: 4.77, 5.346, 5.604
- `sum_amount via columnar` latency_p99_ms: 4.779, 5.384, 5.619
- `sum_amount via columnar` throughput_per_second: 214.9, 208.1, 201.9
- `group_by_category via columnar` latency_p50_ms: 27.64, 30.35, 30.06
- `group_by_category via columnar` latency_p95_ms: 28.46, 32.03, 31.45
- `group_by_category via columnar` latency_p99_ms: 28.53, 32.18, 31.57
- `group_by_category via columnar` throughput_per_second: 40.07, 33.99, 34.8
- `filtered_sum via columnar` latency_p50_ms: 29.19, 29.34, 28.24
- `filtered_sum via columnar` latency_p95_ms: 29.97, 30.15, 29.82
- `filtered_sum via columnar` latency_p99_ms: 30.03, 30.22, 29.96
- `filtered_sum via columnar` throughput_per_second: 36.97, 35.61, 36.9
- `numeric_filtered_sum via columnar` latency_p50_ms: 8.438, 8.601, 7.941
- `numeric_filtered_sum via columnar` latency_p95_ms: 8.675, 9.636, 7.961
- `numeric_filtered_sum via columnar` latency_p99_ms: 8.696, 9.728, 7.963
- `numeric_filtered_sum via columnar` throughput_per_second: 122.9, 124, 127.6
- `total_rows via parquet` latency_p50_ms: 628.5, 610.2, 628.5
- `total_rows via parquet` latency_p95_ms: 630.6, 630.9, 673.8
- `total_rows via parquet` latency_p99_ms: 630.7, 632.7, 677.8
- `total_rows via parquet` throughput_per_second: 1.61, 1.654, 1.603
- `sum_amount via parquet` latency_p50_ms: 689.9, 684.7, 708.1
- `sum_amount via parquet` latency_p95_ms: 690.3, 700.4, 712.3
- `sum_amount via parquet` latency_p99_ms: 690.4, 701.8, 712.7
- `sum_amount via parquet` throughput_per_second: 1.493, 1.473, 1.439
- `group_by_category via parquet` latency_p50_ms: 716.8, 730.6, 744.4
- `group_by_category via parquet` latency_p95_ms: 734.1, 738.5, 746.1
- `group_by_category via parquet` latency_p99_ms: 735.7, 739.2, 746.2
- `group_by_category via parquet` throughput_per_second: 1.421, 1.389, 1.399
- `filtered_sum via parquet` latency_p50_ms: 641.1, 669.5, 672
- `filtered_sum via parquet` latency_p95_ms: 662.2, 675.8, 680.8
- `filtered_sum via parquet` latency_p99_ms: 664.1, 676.4, 681.6
- `filtered_sum via parquet` throughput_per_second: 1.565, 1.511, 1.501
- `numeric_filtered_sum via parquet` latency_p50_ms: 672.6, 700.1, 695.9
- `numeric_filtered_sum via parquet` latency_p95_ms: 673, 700.7, 716
- `numeric_filtered_sum via parquet` latency_p99_ms: 673, 700.7, 717.7
- `numeric_filtered_sum via parquet` throughput_per_second: 1.505, 1.498, 1.454

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T225548Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424534528 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e33e1ade0d002e02afd40f98201d1fabd1ad04e4 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

