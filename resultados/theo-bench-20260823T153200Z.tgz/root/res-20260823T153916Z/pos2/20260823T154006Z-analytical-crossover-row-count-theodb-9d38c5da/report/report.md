# analytical/crossover/row-count on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T154006Z-analytical-crossover-row-count-theodb-9d38c5da`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row @ 10000 linhas | 1,740 | _not measured_ | 0.5994 | 0.6453 | 0.6506 | **no** |
| sum_amount via row @ 10000 linhas | 1,407 | _not measured_ | 0.7359 | 0.8794 | 0.8885 | **no** |
| group_by_category via row @ 10000 linhas | 571.1 | _not measured_ | 1.783 | 1.849 | 1.85 | yes |
| filtered_sum via row @ 10000 linhas | 1,117 | _not measured_ | 0.9231 | 0.9766 | 0.9779 | **no** |
| numeric_filtered_sum via row @ 10000 linhas | 1,259 | _not measured_ | 0.8264 | 0.8912 | 0.8913 | **no** |
| total_rows via columnar @ 10000 linhas | 1,180 | _not measured_ | 0.8975 | 1.053 | 1.067 | **no** |
| sum_amount via columnar @ 10000 linhas | 1,039 | _not measured_ | 0.9726 | 1.091 | 1.096 | yes |
| group_by_category via columnar @ 10000 linhas | 466.6 | _not measured_ | 2.192 | 2.232 | 2.233 | yes |
| filtered_sum via columnar @ 10000 linhas | 431.1 | _not measured_ | 2.337 | 2.378 | 2.382 | **no** |
| numeric_filtered_sum via columnar @ 10000 linhas | 713.7 | _not measured_ | 1.463 | 1.596 | 1.599 | **no** |
| total_rows via parquet @ 10000 linhas | 38.78 | _not measured_ | 25.94 | 26.09 | 26.11 | yes |
| sum_amount via parquet @ 10000 linhas | 34.75 | _not measured_ | 29.1 | 29.33 | 29.36 | yes |
| group_by_category via parquet @ 10000 linhas | 32.53 | _not measured_ | 31.06 | 31.17 | 31.17 | yes |
| filtered_sum via parquet @ 10000 linhas | 35.75 | _not measured_ | 28.14 | 28.3 | 28.32 | yes |
| numeric_filtered_sum via parquet @ 10000 linhas | 35.33 | _not measured_ | 28.42 | 28.43 | 28.43 | yes |
| total_rows via row @ 50000 linhas | 383.9 | _not measured_ | 2.77 | 2.871 | 2.886 | yes |
| sum_amount via row @ 50000 linhas | 308.6 | _not measured_ | 3.318 | 3.346 | 3.348 | yes |
| group_by_category via row @ 50000 linhas | 119 | _not measured_ | 8.529 | 8.71 | 8.726 | yes |
| filtered_sum via row @ 50000 linhas | 243.7 | _not measured_ | 4.193 | 4.219 | 4.221 | yes |
| numeric_filtered_sum via row @ 50000 linhas | 270.6 | _not measured_ | 3.741 | 3.778 | 3.781 | yes |
| total_rows via columnar @ 50000 linhas | 862.2 | _not measured_ | 1.178 | 1.329 | 1.342 | **no** |
| sum_amount via columnar @ 50000 linhas | 592.2 | _not measured_ | 1.722 | 1.754 | 1.757 | **no** |
| group_by_category via columnar @ 50000 linhas | 134.2 | _not measured_ | 7.604 | 7.749 | 7.762 | yes |
| filtered_sum via columnar @ 50000 linhas | 128.9 | _not measured_ | 7.811 | 7.852 | 7.855 | yes |
| numeric_filtered_sum via columnar @ 50000 linhas | 370 | _not measured_ | 2.763 | 2.908 | 2.921 | yes |
| total_rows via parquet @ 50000 linhas | 6.871 | _not measured_ | 147.5 | 147.8 | 147.8 | yes |
| sum_amount via parquet @ 50000 linhas | 6.222 | _not measured_ | 161.1 | 161.3 | 161.4 | yes |
| group_by_category via parquet @ 50000 linhas | 5.882 | _not measured_ | 170.8 | 172 | 172.1 | yes |
| filtered_sum via parquet @ 50000 linhas | 6.404 | _not measured_ | 157.1 | 158.7 | 158.7 | yes |
| numeric_filtered_sum via parquet @ 50000 linhas | 6.278 | _not measured_ | 159.4 | 159.7 | 159.8 | yes |
| total_rows via row @ 100000 linhas | 181.9 | _not measured_ | 5.68 | 5.781 | 5.79 | yes |
| sum_amount via row @ 100000 linhas | 145.9 | _not measured_ | 6.864 | 6.94 | 6.947 | yes |
| group_by_category via row @ 100000 linhas | 59.03 | _not measured_ | 17.11 | 17.37 | 17.37 | yes |
| filtered_sum via row @ 100000 linhas | 116.1 | _not measured_ | 8.665 | 8.714 | 8.718 | yes |
| numeric_filtered_sum via row @ 100000 linhas | 133.3 | _not measured_ | 7.732 | 7.738 | 7.738 | yes |
| total_rows via columnar @ 100000 linhas | 705.9 | _not measured_ | 1.475 | 1.586 | 1.598 | yes |
| sum_amount via columnar @ 100000 linhas | 400.1 | _not measured_ | 2.524 | 2.593 | 2.599 | yes |
| group_by_category via columnar @ 100000 linhas | 71.09 | _not measured_ | 14.22 | 14.26 | 14.26 | yes |
| filtered_sum via columnar @ 100000 linhas | 72.01 | _not measured_ | 14.11 | 14.19 | 14.19 | yes |
| numeric_filtered_sum via columnar @ 100000 linhas | 243.9 | _not measured_ | 4.342 | 4.416 | 4.423 | yes |
| total_rows via parquet @ 100000 linhas | 3.42 | _not measured_ | 295.1 | 296.9 | 297.1 | yes |
| sum_amount via parquet @ 100000 linhas | 3.106 | _not measured_ | 326.2 | 330.7 | 331.1 | yes |
| group_by_category via parquet @ 100000 linhas | 2.888 | _not measured_ | 346.7 | 347.4 | 347.5 | yes |
| filtered_sum via parquet @ 100000 linhas | 3.137 | _not measured_ | 322.6 | 323.1 | 323.1 | yes |
| numeric_filtered_sum via parquet @ 100000 linhas | 3.121 | _not measured_ | 323.3 | 334.3 | 335.3 | yes |
| total_rows via row @ 500000 linhas | 55.26 | _not measured_ | 18.16 | 19.56 | 19.68 | **no** |
| sum_amount via row @ 500000 linhas | 46.18 | _not measured_ | 21.87 | 23.64 | 23.79 | **no** |
| group_by_category via row @ 500000 linhas | 25.51 | _not measured_ | 39.3 | 42.33 | 42.6 | **no** |
| filtered_sum via row @ 500000 linhas | 40.32 | _not measured_ | 24.86 | 25 | 25.01 | **no** |
| numeric_filtered_sum via row @ 500000 linhas | 42.62 | _not measured_ | 23.61 | 23.62 | 23.62 | **no** |
| total_rows via columnar @ 500000 linhas | 252.4 | _not measured_ | 4.028 | 4.246 | 4.265 | yes |
| sum_amount via columnar @ 500000 linhas | 107 | _not measured_ | 9.478 | 9.501 | 9.503 | yes |
| group_by_category via columnar @ 500000 linhas | 15.54 | _not measured_ | 64.75 | 64.98 | 64.98 | yes |
| filtered_sum via columnar @ 500000 linhas | 15.75 | _not measured_ | 63.85 | 64.09 | 64.11 | yes |
| numeric_filtered_sum via columnar @ 500000 linhas | 62.93 | _not measured_ | 15.95 | 16.09 | 16.09 | yes |
| total_rows via parquet @ 500000 linhas | 0.6693 | _not measured_ | 1,504 | 1,507 | 1,508 | yes |
| sum_amount via parquet @ 500000 linhas | 0.6024 | _not measured_ | 1,666 | 1,668 | 1,668 | yes |
| group_by_category via parquet @ 500000 linhas | 0.5723 | _not measured_ | 1,754 | 1,767 | 1,769 | yes |
| filtered_sum via parquet @ 500000 linhas | 0.6188 | _not measured_ | 1,625 | 1,626 | 1,626 | yes |
| numeric_filtered_sum via parquet @ 500000 linhas | 0.6163 | _not measured_ | 1,631 | 1,633 | 1,633 | yes |
| total_rows via row @ 1000000 linhas | 36.33 | _not measured_ | 27.63 | 32.53 | 32.97 | **no** |
| sum_amount via row @ 1000000 linhas | 29.08 | _not measured_ | 34.51 | 34.67 | 34.69 | **no** |
| group_by_category via row @ 1000000 linhas | 14.81 | _not measured_ | 68.13 | 75.96 | 76.76 | **no** |
| filtered_sum via row @ 1000000 linhas | 24.94 | _not measured_ | 40.31 | 40.6 | 40.63 | **no** |
| numeric_filtered_sum via row @ 1000000 linhas | 26.73 | _not measured_ | 37.6 | 37.81 | 37.83 | **no** |
| total_rows via columnar @ 1000000 linhas | 135.5 | _not measured_ | 7.393 | 7.633 | 7.654 | yes |
| sum_amount via columnar @ 1000000 linhas | 56.3 | _not measured_ | 17.79 | 17.82 | 17.82 | yes |
| group_by_category via columnar @ 1000000 linhas | 7.883 | _not measured_ | 128.2 | 128.3 | 128.3 | yes |
| filtered_sum via columnar @ 1000000 linhas | 8.02 | _not measured_ | 126 | 126.2 | 126.2 | yes |
| numeric_filtered_sum via columnar @ 1000000 linhas | 33.35 | _not measured_ | 30.33 | 30.67 | 30.74 | yes |
| total_rows via parquet @ 1000000 linhas | 0.3327 | _not measured_ | 3,027 | 3,049 | 3,051 | yes |
| sum_amount via parquet @ 1000000 linhas | 0.2999 | _not measured_ | 3,361 | 3,410 | 3,414 | yes |
| group_by_category via parquet @ 1000000 linhas | 0.283 | _not measured_ | 3,542 | 3,549 | 3,549 | yes |
| filtered_sum via parquet @ 1000000 linhas | 0.3125 | _not measured_ | 3,222 | 3,234 | 3,236 | yes |
| numeric_filtered_sum via parquet @ 1000000 linhas | 0.3091 | _not measured_ | 3,253 | 3,308 | 3,312 | yes |
| total_rows via row @ 2000000 linhas | 23.3 | _not measured_ | 43 | 43.55 | 43.58 | **no** |
| sum_amount via row @ 2000000 linhas | 17.95 | _not measured_ | 55.8 | 56.42 | 56.46 | **no** |
| group_by_category via row @ 2000000 linhas | 8.241 | _not measured_ | 121.5 | 121.9 | 121.9 | yes |
| filtered_sum via row @ 2000000 linhas | 15 | _not measured_ | 66.78 | 67.55 | 67.55 | yes |
| numeric_filtered_sum via row @ 2000000 linhas | 16.09 | _not measured_ | 62.33 | 63.97 | 64.12 | yes |
| total_rows via columnar @ 2000000 linhas | 71.32 | _not measured_ | 14.14 | 14.23 | 14.25 | yes |
| sum_amount via columnar @ 2000000 linhas | 28.81 | _not measured_ | 34.85 | 35.17 | 35.2 | yes |
| group_by_category via columnar @ 2000000 linhas | 3.924 | _not measured_ | 255.3 | 256.5 | 256.6 | yes |
| filtered_sum via columnar @ 2000000 linhas | 4.048 | _not measured_ | 247.1 | 252.5 | 253.1 | yes |
| numeric_filtered_sum via columnar @ 2000000 linhas | 17.57 | _not measured_ | 57.46 | 57.94 | 57.99 | yes |
| total_rows via parquet @ 2000000 linhas | 0.1602 | _not measured_ | 6,242 | 6,308 | 6,317 | yes |
| sum_amount via parquet @ 2000000 linhas | 0.1456 | _not measured_ | 6,919 | 6,967 | 6,971 | yes |
| group_by_category via parquet @ 2000000 linhas | 0.138 | _not measured_ | 7,259 | 7,334 | 7,341 | yes |
| filtered_sum via parquet @ 2000000 linhas | 0.1486 | _not measured_ | 6,759 | 6,845 | 6,850 | yes |
| numeric_filtered_sum via parquet @ 2000000 linhas | 0.1486 | _not measured_ | 6,784 | 6,859 | 6,862 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row @ 10000 linhas`: latency_p50_ms cv=0.103; latency_p95_ms cv=0.058; latency_p99_ms cv=0.055; throughput_per_second cv=0.088
- `sum_amount via row @ 10000 linhas`: latency_p95_ms cv=0.102; latency_p99_ms cv=0.109
- `filtered_sum via row @ 10000 linhas`: latency_p95_ms cv=0.068; latency_p99_ms cv=0.073
- `numeric_filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.055; latency_p95_ms cv=0.082; latency_p99_ms cv=0.088; throughput_per_second cv=0.058
- `total_rows via columnar @ 10000 linhas`: latency_p95_ms cv=0.078; latency_p99_ms cv=0.082; throughput_per_second cv=0.075
- `filtered_sum via columnar @ 10000 linhas`: latency_p95_ms cv=0.083; latency_p99_ms cv=0.089
- `numeric_filtered_sum via columnar @ 10000 linhas`: latency_p95_ms cv=0.061; latency_p99_ms cv=0.066; throughput_per_second cv=0.055
- `total_rows via columnar @ 50000 linhas`: latency_p50_ms cv=0.053; throughput_per_second cv=0.064
- `sum_amount via columnar @ 50000 linhas`: latency_p50_ms cv=0.053
- `total_rows via row @ 500000 linhas`: latency_p50_ms cv=0.100; latency_p95_ms cv=0.086; latency_p99_ms cv=0.086; throughput_per_second cv=0.095
- `sum_amount via row @ 500000 linhas`: latency_p50_ms cv=0.195; latency_p95_ms cv=0.187; latency_p99_ms cv=0.186; throughput_per_second cv=0.071
- `group_by_category via row @ 500000 linhas`: latency_p95_ms cv=0.124; latency_p99_ms cv=0.135
- `filtered_sum via row @ 500000 linhas`: latency_p50_ms cv=0.055; latency_p95_ms cv=0.054; latency_p99_ms cv=0.054; throughput_per_second cv=0.057
- `numeric_filtered_sum via row @ 500000 linhas`: latency_p95_ms cv=0.050; latency_p99_ms cv=0.051; throughput_per_second cv=0.053
- `total_rows via row @ 1000000 linhas`: latency_p50_ms cv=0.116; latency_p95_ms cv=0.081; latency_p99_ms cv=0.081; throughput_per_second cv=0.112
- `sum_amount via row @ 1000000 linhas`: latency_p50_ms cv=0.060; latency_p95_ms cv=0.060; latency_p99_ms cv=0.060; throughput_per_second cv=0.057
- `group_by_category via row @ 1000000 linhas`: latency_p95_ms cv=0.192; latency_p99_ms cv=0.204
- `filtered_sum via row @ 1000000 linhas`: latency_p95_ms cv=0.059; latency_p99_ms cv=0.060
- `numeric_filtered_sum via row @ 1000000 linhas`: latency_p50_ms cv=0.053; latency_p95_ms cv=0.054; latency_p99_ms cv=0.054; throughput_per_second cv=0.055
- `total_rows via row @ 2000000 linhas`: latency_p95_ms cv=0.127; latency_p99_ms cv=0.138
- `sum_amount via row @ 2000000 linhas`: latency_p95_ms cv=0.156; latency_p99_ms cv=0.169

### Repetitions

Every repetition is retained:

- `total_rows via row @ 10000 linhas` latency_p50_ms: 0.7042, 0.5994, 0.5858
- `total_rows via row @ 10000 linhas` latency_p95_ms: 0.7054, 0.6339, 0.6453
- `total_rows via row @ 10000 linhas` latency_p99_ms: 0.7055, 0.637, 0.6506
- `total_rows via row @ 10000 linhas` throughput_per_second: 1,497, 1,740, 1,760
- `sum_amount via row @ 10000 linhas` latency_p50_ms: 0.7768, 0.7359, 0.7345
- `sum_amount via row @ 10000 linhas` latency_p95_ms: 0.8794, 0.8902, 0.7376
- `sum_amount via row @ 10000 linhas` latency_p99_ms: 0.8885, 0.9039, 0.7378
- `sum_amount via row @ 10000 linhas` throughput_per_second: 1,308, 1,413, 1,407
- `group_by_category via row @ 10000 linhas` latency_p50_ms: 1.833, 1.783, 1.769
- `group_by_category via row @ 10000 linhas` latency_p95_ms: 1.849, 1.963, 1.802
- `group_by_category via row @ 10000 linhas` latency_p99_ms: 1.85, 1.979, 1.805
- `group_by_category via row @ 10000 linhas` throughput_per_second: 571.1, 568.6, 579.8
- `filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.9621, 0.9231, 0.8958
- `filtered_sum via row @ 10000 linhas` latency_p95_ms: 0.9766, 1.082, 0.9554
- `filtered_sum via row @ 10000 linhas` latency_p99_ms: 0.9779, 1.097, 0.9607
- `filtered_sum via row @ 10000 linhas` throughput_per_second: 1,047, 1,147, 1,117
- `numeric_filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.8904, 0.8264, 0.8009
- `numeric_filtered_sum via row @ 10000 linhas` latency_p95_ms: 0.8912, 0.9587, 0.8127
- `numeric_filtered_sum via row @ 10000 linhas` latency_p99_ms: 0.8913, 0.9705, 0.8138
- `numeric_filtered_sum via row @ 10000 linhas` throughput_per_second: 1,148, 1,281, 1,259
- `total_rows via columnar @ 10000 linhas` latency_p50_ms: 0.95, 0.8975, 0.8926
- `total_rows via columnar @ 10000 linhas` latency_p95_ms: 1.174, 1.012, 1.053
- `total_rows via columnar @ 10000 linhas` latency_p99_ms: 1.194, 1.022, 1.067
- `total_rows via columnar @ 10000 linhas` throughput_per_second: 1,077, 1,180, 1,251
- `sum_amount via columnar @ 10000 linhas` latency_p50_ms: 1.035, 0.9511, 0.9726
- `sum_amount via columnar @ 10000 linhas` latency_p95_ms: 1.091, 1.159, 1.071
- `sum_amount via columnar @ 10000 linhas` latency_p99_ms: 1.096, 1.177, 1.08
- `sum_amount via columnar @ 10000 linhas` throughput_per_second: 991, 1,055, 1,039
- `group_by_category via columnar @ 10000 linhas` latency_p50_ms: 2.192, 2.182, 2.224
- `group_by_category via columnar @ 10000 linhas` latency_p95_ms: 2.202, 2.372, 2.232
- `group_by_category via columnar @ 10000 linhas` latency_p99_ms: 2.202, 2.389, 2.233
- `group_by_category via columnar @ 10000 linhas` throughput_per_second: 463.3, 466.6, 469.5
- `filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 2.343, 2.337, 2.29
- `filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 2.378, 2.697, 2.316
- `filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 2.382, 2.729, 2.318
- `filtered_sum via columnar @ 10000 linhas` throughput_per_second: 430.2, 431.1, 437
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 1.561, 1.439, 1.463
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 1.596, 1.686, 1.492
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 1.599, 1.708, 1.495
- `numeric_filtered_sum via columnar @ 10000 linhas` throughput_per_second: 652.9, 713.7, 724.3
- `total_rows via parquet @ 10000 linhas` latency_p50_ms: 26.16, 25.82, 25.94
- `total_rows via parquet @ 10000 linhas` latency_p95_ms: 28.13, 25.89, 26.09
- `total_rows via parquet @ 10000 linhas` latency_p99_ms: 28.31, 25.9, 26.11
- `total_rows via parquet @ 10000 linhas` throughput_per_second: 38.75, 38.92, 38.78
- `sum_amount via parquet @ 10000 linhas` latency_p50_ms: 29.36, 29.1, 28.93
- `sum_amount via parquet @ 10000 linhas` latency_p95_ms: 29.55, 29.19, 29.33
- `sum_amount via parquet @ 10000 linhas` latency_p99_ms: 29.56, 29.2, 29.36
- `sum_amount via parquet @ 10000 linhas` throughput_per_second: 34.81, 34.47, 34.75
- `group_by_category via parquet @ 10000 linhas` latency_p50_ms: 31.15, 30.91, 31.06
- `group_by_category via parquet @ 10000 linhas` latency_p95_ms: 31.17, 31.22, 31.11
- `group_by_category via parquet @ 10000 linhas` latency_p99_ms: 31.17, 31.25, 31.12
- `group_by_category via parquet @ 10000 linhas` throughput_per_second: 32.42, 32.53, 32.61
- `filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 28.14, 28.05, 28.2
- `filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 28.16, 28.3, 28.4
- `filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 28.16, 28.32, 28.42
- `filtered_sum via parquet @ 10000 linhas` throughput_per_second: 35.68, 35.75, 36.01
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 28.28, 28.61, 28.42
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 28.34, 28.9, 28.43
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 28.34, 28.92, 28.43
- `numeric_filtered_sum via parquet @ 10000 linhas` throughput_per_second: 35.4, 35.22, 35.33
- `total_rows via row @ 50000 linhas` latency_p50_ms: 2.804, 2.694, 2.77
- `total_rows via row @ 50000 linhas` latency_p95_ms: 2.804, 2.871, 2.881
- `total_rows via row @ 50000 linhas` latency_p99_ms: 2.804, 2.886, 2.891
- `total_rows via row @ 50000 linhas` throughput_per_second: 395, 376.2, 383.9
- `sum_amount via row @ 50000 linhas` latency_p50_ms: 3.318, 3.365, 3.28
- `sum_amount via row @ 50000 linhas` latency_p95_ms: 3.346, 3.379, 3.297
- `sum_amount via row @ 50000 linhas` latency_p99_ms: 3.348, 3.38, 3.298
- `sum_amount via row @ 50000 linhas` throughput_per_second: 311, 300.4, 308.6
- `group_by_category via row @ 50000 linhas` latency_p50_ms: 8.467, 8.593, 8.529
- `group_by_category via row @ 50000 linhas` latency_p95_ms: 8.641, 8.876, 8.71
- `group_by_category via row @ 50000 linhas` latency_p99_ms: 8.656, 8.901, 8.726
- `group_by_category via row @ 50000 linhas` throughput_per_second: 119, 118.5, 119.8
- `filtered_sum via row @ 50000 linhas` latency_p50_ms: 4.077, 4.193, 4.221
- `filtered_sum via row @ 50000 linhas` latency_p95_ms: 4.102, 4.219, 4.284
- `filtered_sum via row @ 50000 linhas` latency_p99_ms: 4.104, 4.221, 4.29
- `filtered_sum via row @ 50000 linhas` throughput_per_second: 246.5, 243.7, 237.8
- `numeric_filtered_sum via row @ 50000 linhas` latency_p50_ms: 3.599, 3.779, 3.741
- `numeric_filtered_sum via row @ 50000 linhas` latency_p95_ms: 3.647, 3.907, 3.778
- `numeric_filtered_sum via row @ 50000 linhas` latency_p99_ms: 3.652, 3.919, 3.781
- `numeric_filtered_sum via row @ 50000 linhas` throughput_per_second: 278.3, 266, 270.6
- `total_rows via columnar @ 50000 linhas` latency_p50_ms: 1.114, 1.239, 1.178
- `total_rows via columnar @ 50000 linhas` latency_p95_ms: 1.262, 1.343, 1.329
- `total_rows via columnar @ 50000 linhas` latency_p99_ms: 1.276, 1.352, 1.342
- `total_rows via columnar @ 50000 linhas` throughput_per_second: 961, 861.1, 862.2
- `sum_amount via columnar @ 50000 linhas` latency_p50_ms: 1.663, 1.843, 1.722
- `sum_amount via columnar @ 50000 linhas` latency_p95_ms: 1.746, 1.857, 1.754
- `sum_amount via columnar @ 50000 linhas` latency_p99_ms: 1.753, 1.858, 1.757
- `sum_amount via columnar @ 50000 linhas` throughput_per_second: 601.4, 548.7, 592.2
- `group_by_category via columnar @ 50000 linhas` latency_p50_ms: 7.48, 7.648, 7.604
- `group_by_category via columnar @ 50000 linhas` latency_p95_ms: 7.507, 7.763, 7.749
- `group_by_category via columnar @ 50000 linhas` latency_p99_ms: 7.509, 7.773, 7.762
- `group_by_category via columnar @ 50000 linhas` throughput_per_second: 134.6, 134.2, 131.6
- `filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 7.503, 7.811, 7.823
- `filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 7.556, 7.868, 7.852
- `filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 7.561, 7.873, 7.855
- `filtered_sum via columnar @ 50000 linhas` throughput_per_second: 134.6, 128.9, 128.1
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 2.734, 2.802, 2.763
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 2.8, 2.936, 2.908
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 2.806, 2.948, 2.921
- `numeric_filtered_sum via columnar @ 50000 linhas` throughput_per_second: 377.2, 362.2, 370
- `total_rows via parquet @ 50000 linhas` latency_p50_ms: 147.5, 148.5, 146
- `total_rows via parquet @ 50000 linhas` latency_p95_ms: 147.8, 148.7, 146.7
- `total_rows via parquet @ 50000 linhas` latency_p99_ms: 147.8, 148.7, 146.7
- `total_rows via parquet @ 50000 linhas` throughput_per_second: 6.871, 6.759, 6.872
- `sum_amount via parquet @ 50000 linhas` latency_p50_ms: 161.7, 161.1, 160.9
- `sum_amount via parquet @ 50000 linhas` latency_p95_ms: 162.6, 161.3, 161.3
- `sum_amount via parquet @ 50000 linhas` latency_p99_ms: 162.7, 161.4, 161.3
- `sum_amount via parquet @ 50000 linhas` throughput_per_second: 6.224, 6.214, 6.222
- `group_by_category via parquet @ 50000 linhas` latency_p50_ms: 170.8, 170.7, 171.9
- `group_by_category via parquet @ 50000 linhas` latency_p95_ms: 173, 172, 171.9
- `group_by_category via parquet @ 50000 linhas` latency_p99_ms: 173.2, 172.1, 172
- `group_by_category via parquet @ 50000 linhas` throughput_per_second: 5.882, 5.884, 5.826
- `filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 158.3, 155.6, 157.1
- `filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 158.7, 156.4, 160.8
- `filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 158.7, 156.4, 161.2
- `filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.4, 6.457, 6.404
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 161.3, 159.4, 159.4
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 161.3, 159.7, 159.6
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 161.4, 159.8, 159.6
- `numeric_filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.24, 6.353, 6.278
- `total_rows via row @ 100000 linhas` latency_p50_ms: 5.748, 5.48, 5.68
- `total_rows via row @ 100000 linhas` latency_p95_ms: 5.913, 5.634, 5.781
- `total_rows via row @ 100000 linhas` latency_p99_ms: 5.928, 5.647, 5.79
- `total_rows via row @ 100000 linhas` throughput_per_second: 175.8, 188.3, 181.9
- `sum_amount via row @ 100000 linhas` latency_p50_ms: 6.864, 6.733, 6.938
- `sum_amount via row @ 100000 linhas` latency_p95_ms: 6.94, 6.773, 7.026
- `sum_amount via row @ 100000 linhas` latency_p99_ms: 6.947, 6.776, 7.033
- `sum_amount via row @ 100000 linhas` throughput_per_second: 145.9, 149.5, 144.6
- `group_by_category via row @ 100000 linhas` latency_p50_ms: 17.11, 17.09, 17.35
- `group_by_category via row @ 100000 linhas` latency_p95_ms: 17.38, 17.31, 17.37
- `group_by_category via row @ 100000 linhas` latency_p99_ms: 17.41, 17.33, 17.37
- `group_by_category via row @ 100000 linhas` throughput_per_second: 59.03, 58.65, 59.06
- `filtered_sum via row @ 100000 linhas` latency_p50_ms: 8.665, 8.505, 8.674
- `filtered_sum via row @ 100000 linhas` latency_p95_ms: 8.714, 8.575, 8.739
- `filtered_sum via row @ 100000 linhas` latency_p99_ms: 8.718, 8.582, 8.745
- `filtered_sum via row @ 100000 linhas` throughput_per_second: 116.1, 118, 115.4
- `numeric_filtered_sum via row @ 100000 linhas` latency_p50_ms: 7.758, 7.671, 7.732
- `numeric_filtered_sum via row @ 100000 linhas` latency_p95_ms: 7.787, 7.683, 7.738
- `numeric_filtered_sum via row @ 100000 linhas` latency_p99_ms: 7.79, 7.684, 7.738
- `numeric_filtered_sum via row @ 100000 linhas` throughput_per_second: 129.4, 133.3, 133.5
- `total_rows via columnar @ 100000 linhas` latency_p50_ms: 1.45, 1.475, 1.478
- `total_rows via columnar @ 100000 linhas` latency_p95_ms: 1.586, 1.585, 1.658
- `total_rows via columnar @ 100000 linhas` latency_p99_ms: 1.598, 1.595, 1.674
- `total_rows via columnar @ 100000 linhas` throughput_per_second: 712.2, 705.9, 688.9
- `sum_amount via columnar @ 100000 linhas` latency_p50_ms: 2.478, 2.524, 2.626
- `sum_amount via columnar @ 100000 linhas` latency_p95_ms: 2.517, 2.593, 2.668
- `sum_amount via columnar @ 100000 linhas` latency_p99_ms: 2.521, 2.599, 2.671
- `sum_amount via columnar @ 100000 linhas` throughput_per_second: 406.5, 400.1, 385.7
- `group_by_category via columnar @ 100000 linhas` latency_p50_ms: 14.27, 14.22, 14.13
- `group_by_category via columnar @ 100000 linhas` latency_p95_ms: 14.33, 14.26, 14.24
- `group_by_category via columnar @ 100000 linhas` latency_p99_ms: 14.33, 14.26, 14.25
- `group_by_category via columnar @ 100000 linhas` throughput_per_second: 70.21, 71.09, 71.77
- `filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 14.19, 14.11, 13.95
- `filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 14.29, 14.19, 14.03
- `filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 14.3, 14.19, 14.04
- `filtered_sum via columnar @ 100000 linhas` throughput_per_second: 71.5, 72.01, 72.01
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 4.454, 4.342, 4.217
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 4.514, 4.416, 4.286
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 4.52, 4.423, 4.292
- `numeric_filtered_sum via columnar @ 100000 linhas` throughput_per_second: 243.9, 243.2, 244.8
- `total_rows via parquet @ 100000 linhas` latency_p50_ms: 295.1, 296.4, 294.6
- `total_rows via parquet @ 100000 linhas` latency_p95_ms: 296.9, 297.8, 296.8
- `total_rows via parquet @ 100000 linhas` latency_p99_ms: 297.1, 297.9, 297
- `total_rows via parquet @ 100000 linhas` throughput_per_second: 3.42, 3.377, 3.434
- `sum_amount via parquet @ 100000 linhas` latency_p50_ms: 326.2, 330.8, 322.8
- `sum_amount via parquet @ 100000 linhas` latency_p95_ms: 330.7, 333.5, 323.5
- `sum_amount via parquet @ 100000 linhas` latency_p99_ms: 331.1, 333.8, 323.6
- `sum_amount via parquet @ 100000 linhas` throughput_per_second: 3.111, 3.034, 3.106
- `group_by_category via parquet @ 100000 linhas` latency_p50_ms: 348.2, 346.1, 346.7
- `group_by_category via parquet @ 100000 linhas` latency_p95_ms: 352.6, 347.4, 347.3
- `group_by_category via parquet @ 100000 linhas` latency_p99_ms: 352.9, 347.5, 347.4
- `group_by_category via parquet @ 100000 linhas` throughput_per_second: 2.887, 2.907, 2.888
- `filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 322.6, 320.5, 328.4
- `filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 323.1, 322.9, 332.4
- `filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 323.1, 323.1, 332.8
- `filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.169, 3.137, 3.054
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 323.3, 331.9, 322.6
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 323.4, 335.5, 334.3
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 323.5, 335.8, 335.3
- `numeric_filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.121, 3.064, 3.129
- `total_rows via row @ 500000 linhas` latency_p50_ms: 21.43, 18.16, 18.04
- `total_rows via row @ 500000 linhas` latency_p95_ms: 21.58, 19.56, 18.18
- `total_rows via row @ 500000 linhas` latency_p99_ms: 21.59, 19.68, 18.19
- `total_rows via row @ 500000 linhas` throughput_per_second: 46.98, 55.26, 55.99
- `sum_amount via row @ 500000 linhas` latency_p50_ms: 29.74, 21.27, 21.87
- `sum_amount via row @ 500000 linhas` latency_p95_ms: 30.75, 21.75, 23.64
- `sum_amount via row @ 500000 linhas` latency_p99_ms: 30.84, 21.8, 23.79
- `sum_amount via row @ 500000 linhas` throughput_per_second: 41.23, 47.18, 46.18
- `group_by_category via row @ 500000 linhas` latency_p50_ms: 41.88, 39.27, 39.3
- `group_by_category via row @ 500000 linhas` latency_p95_ms: 42, 42.33, 51.9
- `group_by_category via row @ 500000 linhas` latency_p99_ms: 42.01, 42.6, 53.02
- `group_by_category via row @ 500000 linhas` throughput_per_second: 23.89, 25.51, 25.55
- `filtered_sum via row @ 500000 linhas` latency_p50_ms: 27.26, 24.86, 24.8
- `filtered_sum via row @ 500000 linhas` latency_p95_ms: 27.42, 24.98, 25
- `filtered_sum via row @ 500000 linhas` latency_p99_ms: 27.43, 25, 25.01
- `filtered_sum via row @ 500000 linhas` throughput_per_second: 36.74, 40.32, 40.81
- `numeric_filtered_sum via row @ 500000 linhas` latency_p50_ms: 25.64, 23.61, 23.58
- `numeric_filtered_sum via row @ 500000 linhas` latency_p95_ms: 25.75, 23.62, 23.62
- `numeric_filtered_sum via row @ 500000 linhas` latency_p99_ms: 25.76, 23.62, 23.62
- `numeric_filtered_sum via row @ 500000 linhas` throughput_per_second: 39.04, 42.99, 42.62
- `total_rows via columnar @ 500000 linhas` latency_p50_ms: 4.028, 4.039, 3.977
- `total_rows via columnar @ 500000 linhas` latency_p95_ms: 4.322, 4.246, 4.216
- `total_rows via columnar @ 500000 linhas` latency_p99_ms: 4.348, 4.265, 4.238
- `total_rows via columnar @ 500000 linhas` throughput_per_second: 252.4, 250.6, 258.8
- `sum_amount via columnar @ 500000 linhas` latency_p50_ms: 9.478, 9.532, 9.455
- `sum_amount via columnar @ 500000 linhas` latency_p95_ms: 9.501, 9.547, 9.484
- `sum_amount via columnar @ 500000 linhas` latency_p99_ms: 9.503, 9.549, 9.487
- `sum_amount via columnar @ 500000 linhas` throughput_per_second: 107, 105.7, 107
- `group_by_category via columnar @ 500000 linhas` latency_p50_ms: 64.75, 64.96, 64.15
- `group_by_category via columnar @ 500000 linhas` latency_p95_ms: 65.15, 64.98, 64.91
- `group_by_category via columnar @ 500000 linhas` latency_p99_ms: 65.19, 64.98, 64.97
- `group_by_category via columnar @ 500000 linhas` throughput_per_second: 15.46, 15.54, 15.61
- `filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 64.37, 63.85, 63.28
- `filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 64.66, 64.09, 63.73
- `filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 64.68, 64.11, 63.77
- `filtered_sum via columnar @ 500000 linhas` throughput_per_second: 15.75, 15.72, 15.98
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 15.95, 16.05, 15.8
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 16.13, 16.09, 15.83
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 16.15, 16.09, 15.83
- `numeric_filtered_sum via columnar @ 500000 linhas` throughput_per_second: 62.93, 62.54, 63.88
- `total_rows via parquet @ 500000 linhas` latency_p50_ms: 1,489, 1,504, 1,521
- `total_rows via parquet @ 500000 linhas` latency_p95_ms: 1,489, 1,507, 1,543
- `total_rows via parquet @ 500000 linhas` latency_p99_ms: 1,489, 1,508, 1,544
- `total_rows via parquet @ 500000 linhas` throughput_per_second: 0.6751, 0.6693, 0.6594
- `sum_amount via parquet @ 500000 linhas` latency_p50_ms: 1,663, 1,667, 1,666
- `sum_amount via parquet @ 500000 linhas` latency_p95_ms: 1,668, 1,670, 1,667
- `sum_amount via parquet @ 500000 linhas` latency_p99_ms: 1,668, 1,670, 1,667
- `sum_amount via parquet @ 500000 linhas` throughput_per_second: 0.6084, 0.6024, 0.6002
- `group_by_category via parquet @ 500000 linhas` latency_p50_ms: 1,754, 1,752, 1,809
- `group_by_category via parquet @ 500000 linhas` latency_p95_ms: 1,767, 1,758, 1,817
- `group_by_category via parquet @ 500000 linhas` latency_p99_ms: 1,769, 1,758, 1,818
- `group_by_category via parquet @ 500000 linhas` throughput_per_second: 0.5761, 0.5723, 0.5696
- `filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,611, 1,625, 1,665
- `filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,619, 1,626, 1,670
- `filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,620, 1,626, 1,670
- `filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.623, 0.6188, 0.614
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,613, 1,631, 1,647
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,624, 1,633, 1,649
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,625, 1,633, 1,649
- `numeric_filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.6201, 0.6163, 0.6108
- `total_rows via row @ 1000000 linhas` latency_p50_ms: 33.45, 27.42, 27.63
- `total_rows via row @ 1000000 linhas` latency_p95_ms: 33.64, 28.75, 32.53
- `total_rows via row @ 1000000 linhas` latency_p99_ms: 33.65, 28.87, 32.97
- `total_rows via row @ 1000000 linhas` throughput_per_second: 29.91, 36.73, 36.33
- `sum_amount via row @ 1000000 linhas` latency_p50_ms: 38.13, 34.51, 34.31
- `sum_amount via row @ 1000000 linhas` latency_p95_ms: 38.24, 34.67, 34.42
- `sum_amount via row @ 1000000 linhas` latency_p99_ms: 38.24, 34.69, 34.43
- `sum_amount via row @ 1000000 linhas` throughput_per_second: 26.43, 29.08, 29.33
- `group_by_category via row @ 1000000 linhas` latency_p50_ms: 72.88, 68.13, 67.02
- `group_by_category via row @ 1000000 linhas` latency_p95_ms: 98.34, 68.41, 75.96
- `group_by_category via row @ 1000000 linhas` latency_p99_ms: 100.6, 68.43, 76.76
- `group_by_category via row @ 1000000 linhas` throughput_per_second: 13.78, 14.81, 14.94
- `filtered_sum via row @ 1000000 linhas` latency_p50_ms: 43.6, 40.31, 39.95
- `filtered_sum via row @ 1000000 linhas` latency_p95_ms: 44.87, 40.6, 40.5
- `filtered_sum via row @ 1000000 linhas` latency_p99_ms: 44.98, 40.63, 40.55
- `filtered_sum via row @ 1000000 linhas` throughput_per_second: 22.95, 24.94, 25.14
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p50_ms: 41.1, 37.44, 37.6
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p95_ms: 41.45, 37.77, 37.81
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p99_ms: 41.48, 37.8, 37.83
- `numeric_filtered_sum via row @ 1000000 linhas` throughput_per_second: 24.38, 26.73, 26.93
- `total_rows via columnar @ 1000000 linhas` latency_p50_ms: 7.33, 7.393, 7.395
- `total_rows via columnar @ 1000000 linhas` latency_p95_ms: 7.338, 7.633, 7.705
- `total_rows via columnar @ 1000000 linhas` latency_p99_ms: 7.339, 7.654, 7.732
- `total_rows via columnar @ 1000000 linhas` throughput_per_second: 139, 135.5, 135.3
- `sum_amount via columnar @ 1000000 linhas` latency_p50_ms: 17.52, 18.25, 17.79
- `sum_amount via columnar @ 1000000 linhas` latency_p95_ms: 17.72, 18.25, 17.82
- `sum_amount via columnar @ 1000000 linhas` latency_p99_ms: 17.74, 18.25, 17.82
- `sum_amount via columnar @ 1000000 linhas` throughput_per_second: 57.39, 55.1, 56.3
- `group_by_category via columnar @ 1000000 linhas` latency_p50_ms: 128.2, 128.6, 126.8
- `group_by_category via columnar @ 1000000 linhas` latency_p95_ms: 128.3, 129, 128.2
- `group_by_category via columnar @ 1000000 linhas` latency_p99_ms: 128.3, 129, 128.3
- `group_by_category via columnar @ 1000000 linhas` throughput_per_second: 7.835, 7.883, 7.918
- `filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 126, 126, 124.6
- `filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 126.2, 126.7, 125.4
- `filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 126.2, 126.7, 125.5
- `filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 8.02, 7.995, 8.044
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 30.44, 30.33, 29.84
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 30.8, 30.4, 30.67
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 30.83, 30.41, 30.74
- `numeric_filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 33.06, 33.35, 33.74
- `total_rows via parquet @ 1000000 linhas` latency_p50_ms: 3,019, 3,029, 3,027
- `total_rows via parquet @ 1000000 linhas` latency_p95_ms: 3,060, 3,049, 3,027
- `total_rows via parquet @ 1000000 linhas` latency_p99_ms: 3,063, 3,051, 3,027
- `total_rows via parquet @ 1000000 linhas` throughput_per_second: 0.3327, 0.3311, 0.3353
- `sum_amount via parquet @ 1000000 linhas` latency_p50_ms: 3,361, 3,414, 3,326
- `sum_amount via parquet @ 1000000 linhas` latency_p95_ms: 3,410, 3,426, 3,331
- `sum_amount via parquet @ 1000000 linhas` latency_p99_ms: 3,414, 3,427, 3,332
- `sum_amount via parquet @ 1000000 linhas` throughput_per_second: 0.2983, 0.2999, 0.3019
- `group_by_category via parquet @ 1000000 linhas` latency_p50_ms: 3,624, 3,542, 3,509
- `group_by_category via parquet @ 1000000 linhas` latency_p95_ms: 3,632, 3,549, 3,522
- `group_by_category via parquet @ 1000000 linhas` latency_p99_ms: 3,633, 3,549, 3,523
- `group_by_category via parquet @ 1000000 linhas` throughput_per_second: 0.2807, 0.283, 0.2861
- `filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,215, 3,258, 3,222
- `filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,234, 3,282, 3,228
- `filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,236, 3,285, 3,229
- `filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.312, 0.3125, 0.3133
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,253, 3,223, 3,265
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,308, 3,232, 3,338
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,312, 3,233, 3,344
- `numeric_filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.3091, 0.3114, 0.3077
- `total_rows via row @ 2000000 linhas` latency_p50_ms: 43.21, 43, 42.16
- `total_rows via row @ 2000000 linhas` latency_p95_ms: 43.55, 43.03, 53.57
- `total_rows via row @ 2000000 linhas` latency_p99_ms: 43.58, 43.03, 54.59
- `total_rows via row @ 2000000 linhas` throughput_per_second: 23.26, 23.3, 23.91
- `sum_amount via row @ 2000000 linhas` latency_p50_ms: 55.8, 55.99, 55.32
- `sum_amount via row @ 2000000 linhas` latency_p95_ms: 56.1, 56.42, 72.98
- `sum_amount via row @ 2000000 linhas` latency_p99_ms: 56.13, 56.46, 74.55
- `sum_amount via row @ 2000000 linhas` throughput_per_second: 17.93, 17.95, 18.08
- `group_by_category via row @ 2000000 linhas` latency_p50_ms: 123.3, 121.2, 121.5
- `group_by_category via row @ 2000000 linhas` latency_p95_ms: 123.8, 121.9, 121.8
- `group_by_category via row @ 2000000 linhas` latency_p99_ms: 123.9, 121.9, 121.8
- `group_by_category via row @ 2000000 linhas` throughput_per_second: 8.192, 8.268, 8.241
- `filtered_sum via row @ 2000000 linhas` latency_p50_ms: 66.78, 67.5, 66.7
- `filtered_sum via row @ 2000000 linhas` latency_p95_ms: 67.58, 67.55, 67
- `filtered_sum via row @ 2000000 linhas` latency_p99_ms: 67.65, 67.55, 67.03
- `filtered_sum via row @ 2000000 linhas` throughput_per_second: 15.05, 14.82, 15
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p50_ms: 62.33, 62.88, 62.09
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p95_ms: 63.97, 67.14, 62.18
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p99_ms: 64.12, 67.52, 62.19
- `numeric_filtered_sum via row @ 2000000 linhas` throughput_per_second: 16.09, 15.94, 16.13
- `total_rows via columnar @ 2000000 linhas` latency_p50_ms: 14.14, 14.46, 14.11
- `total_rows via columnar @ 2000000 linhas` latency_p95_ms: 14.22, 14.49, 14.23
- `total_rows via columnar @ 2000000 linhas` latency_p99_ms: 14.23, 14.5, 14.25
- `total_rows via columnar @ 2000000 linhas` throughput_per_second: 71.9, 70.77, 71.32
- `sum_amount via columnar @ 2000000 linhas` latency_p50_ms: 34.85, 36.17, 34.48
- `sum_amount via columnar @ 2000000 linhas` latency_p95_ms: 35.17, 36.77, 34.77
- `sum_amount via columnar @ 2000000 linhas` latency_p99_ms: 35.2, 36.83, 34.79
- `sum_amount via columnar @ 2000000 linhas` throughput_per_second: 28.81, 28.49, 29.17
- `group_by_category via columnar @ 2000000 linhas` latency_p50_ms: 257.5, 255.3, 252
- `group_by_category via columnar @ 2000000 linhas` latency_p95_ms: 257.7, 256.5, 252.3
- `group_by_category via columnar @ 2000000 linhas` latency_p99_ms: 257.7, 256.6, 252.4
- `group_by_category via columnar @ 2000000 linhas` throughput_per_second: 3.911, 3.924, 3.971
- `filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 250.3, 245.8, 247.1
- `filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 252.9, 252.5, 247.7
- `filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 253.1, 253.1, 247.8
- `filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 4.044, 4.074, 4.048
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 57.06, 57.46, 57.79
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 57.23, 57.94, 58.28
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 57.24, 57.99, 58.32
- `numeric_filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 17.57, 17.58, 17.33
- `total_rows via parquet @ 2000000 linhas` latency_p50_ms: 6,277, 6,210, 6,242
- `total_rows via parquet @ 2000000 linhas` latency_p95_ms: 6,320, 6,308, 6,243
- `total_rows via parquet @ 2000000 linhas` latency_p99_ms: 6,324, 6,317, 6,243
- `total_rows via parquet @ 2000000 linhas` throughput_per_second: 0.1602, 0.1615, 0.1602
- `sum_amount via parquet @ 2000000 linhas` latency_p50_ms: 6,883, 6,919, 6,956
- `sum_amount via parquet @ 2000000 linhas` latency_p95_ms: 6,900, 6,967, 7,028
- `sum_amount via parquet @ 2000000 linhas` latency_p99_ms: 6,902, 6,971, 7,035
- `sum_amount via parquet @ 2000000 linhas` throughput_per_second: 0.1456, 0.1457, 0.1451
- `group_by_category via parquet @ 2000000 linhas` latency_p50_ms: 7,256, 7,333, 7,259
- `group_by_category via parquet @ 2000000 linhas` latency_p95_ms: 7,334, 7,346, 7,284
- `group_by_category via parquet @ 2000000 linhas` latency_p99_ms: 7,341, 7,347, 7,286
- `group_by_category via parquet @ 2000000 linhas` throughput_per_second: 0.1383, 0.1369, 0.138
- `filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 6,759, 6,658, 6,783
- `filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 6,864, 6,689, 6,845
- `filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 6,874, 6,692, 6,850
- `filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1486, 0.1509, 0.1483
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 6,784, 6,827, 6,783
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 6,878, 6,859, 6,787
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 6,886, 6,862, 6,787
- `numeric_filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1486, 0.1488, 0.1476

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T153200Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

