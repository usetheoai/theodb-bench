# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T153920Z-analytical-synthetic-paths-theodb-2d78272f`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 93.9 | _not measured_ | 10.68 | 10.86 | 10.87 | yes |
| sum_amount via row | 73.72 | _not measured_ | 13.68 | 13.74 | 13.75 | yes |
| group_by_category via row | 38.35 | _not measured_ | 26.26 | 26.69 | 26.72 | **no** |
| filtered_sum via row | 59.31 | _not measured_ | 17.02 | 17.29 | 17.31 | yes |
| numeric_filtered_sum via row | 63.66 | _not measured_ | 15.81 | 15.94 | 15.95 | yes |
| total_rows via columnar | 487.6 | _not measured_ | 2.156 | 2.257 | 2.266 | yes |
| sum_amount via columnar | 234.6 | _not measured_ | 4.371 | 4.457 | 4.465 | **no** |
| group_by_category via columnar | 37.88 | _not measured_ | 26.49 | 26.88 | 26.91 | **no** |
| filtered_sum via columnar | 37.99 | _not measured_ | 26.37 | 26.67 | 26.7 | **no** |
| numeric_filtered_sum via columnar | 139.9 | _not measured_ | 7.269 | 7.325 | 7.327 | yes |
| total_rows via parquet | 1.724 | _not measured_ | 584 | 588.5 | 589 | yes |
| sum_amount via parquet | 1.565 | _not measured_ | 639.5 | 643.1 | 643.6 | yes |
| group_by_category via parquet | 1.468 | _not measured_ | 684.2 | 685.8 | 685.8 | yes |
| filtered_sum via parquet | 1.605 | _not measured_ | 627.2 | 631.2 | 631.6 | yes |
| numeric_filtered_sum via parquet | 1.581 | _not measured_ | 636.8 | 638.3 | 638.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.289; latency_p99_ms cv=0.310
- `sum_amount via columnar`: latency_p95_ms cv=0.055; latency_p99_ms cv=0.056
- `group_by_category via columnar`: latency_p50_ms cv=0.052; latency_p95_ms cv=0.054; latency_p99_ms cv=0.054; throughput_per_second cv=0.057
- `filtered_sum via columnar`: latency_p50_ms cv=0.069; throughput_per_second cv=0.071

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 11.15, 10.67, 10.68
- `total_rows via row` latency_p95_ms: 11.34, 10.68, 10.86
- `total_rows via row` latency_p99_ms: 11.36, 10.69, 10.87
- `total_rows via row` throughput_per_second: 90, 93.9, 94.15
- `sum_amount via row` latency_p50_ms: 14.4, 13.37, 13.68
- `sum_amount via row` latency_p95_ms: 14.43, 13.59, 13.74
- `sum_amount via row` latency_p99_ms: 14.44, 13.61, 13.75
- `sum_amount via row` throughput_per_second: 69.51, 75.52, 73.72
- `group_by_category via row` latency_p50_ms: 26.26, 26.25, 26.38
- `group_by_category via row` latency_p95_ms: 26.28, 42.42, 26.69
- `group_by_category via row` latency_p99_ms: 26.28, 43.86, 26.72
- `group_by_category via row` throughput_per_second: 38.35, 38.64, 38.24
- `filtered_sum via row` latency_p50_ms: 16.69, 17.02, 17.18
- `filtered_sum via row` latency_p95_ms: 16.9, 17.29, 17.72
- `filtered_sum via row` latency_p99_ms: 16.92, 17.31, 17.76
- `filtered_sum via row` throughput_per_second: 60.24, 59.31, 58.68
- `numeric_filtered_sum via row` latency_p50_ms: 15.76, 16.3, 15.81
- `numeric_filtered_sum via row` latency_p95_ms: 15.77, 16.35, 15.94
- `numeric_filtered_sum via row` latency_p99_ms: 15.77, 16.36, 15.95
- `numeric_filtered_sum via row` throughput_per_second: 63.66, 62.33, 64.09
- `total_rows via columnar` latency_p50_ms: 2.156, 2.101, 2.182
- `total_rows via columnar` latency_p95_ms: 2.257, 2.245, 2.33
- `total_rows via columnar` latency_p99_ms: 2.266, 2.258, 2.343
- `total_rows via columnar` throughput_per_second: 478.3, 495.8, 487.6
- `sum_amount via columnar` latency_p50_ms: 4.169, 4.451, 4.371
- `sum_amount via columnar` latency_p95_ms: 4.173, 4.653, 4.457
- `sum_amount via columnar` latency_p99_ms: 4.174, 4.671, 4.465
- `sum_amount via columnar` throughput_per_second: 240, 230.3, 234.6
- `group_by_category via columnar` latency_p50_ms: 24.48, 26.49, 27.07
- `group_by_category via columnar` latency_p95_ms: 24.76, 26.88, 27.45
- `group_by_category via columnar` latency_p99_ms: 24.79, 26.91, 27.48
- `group_by_category via columnar` throughput_per_second: 41.33, 37.88, 37.18
- `filtered_sum via columnar` latency_p50_ms: 23.51, 26.37, 26.69
- `filtered_sum via columnar` latency_p95_ms: 25.08, 26.67, 26.76
- `filtered_sum via columnar` latency_p99_ms: 25.22, 26.7, 26.77
- `filtered_sum via columnar` throughput_per_second: 42.75, 37.99, 37.77
- `numeric_filtered_sum via columnar` latency_p50_ms: 7.292, 7.269, 7.078
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.325, 7.571, 7.248
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.327, 7.598, 7.264
- `numeric_filtered_sum via columnar` throughput_per_second: 139.9, 138.4, 141.7
- `total_rows via parquet` latency_p50_ms: 581.7, 587.7, 584
- `total_rows via parquet` latency_p95_ms: 584.4, 594.5, 588.5
- `total_rows via parquet` latency_p99_ms: 584.6, 595.1, 589
- `total_rows via parquet` throughput_per_second: 1.726, 1.713, 1.724
- `sum_amount via parquet` latency_p50_ms: 638.2, 639.5, 649
- `sum_amount via parquet` latency_p95_ms: 643.1, 640.4, 654.1
- `sum_amount via parquet` latency_p99_ms: 643.6, 640.4, 654.5
- `sum_amount via parquet` throughput_per_second: 1.572, 1.565, 1.557
- `group_by_category via parquet` latency_p50_ms: 677.6, 684.2, 685.4
- `group_by_category via parquet` latency_p95_ms: 682.7, 705.1, 685.8
- `group_by_category via parquet` latency_p99_ms: 683.2, 706.9, 685.8
- `group_by_category via parquet` throughput_per_second: 1.477, 1.466, 1.468
- `filtered_sum via parquet` latency_p50_ms: 626.3, 629.7, 627.2
- `filtered_sum via parquet` latency_p95_ms: 631.2, 630.4, 632.9
- `filtered_sum via parquet` latency_p99_ms: 631.6, 630.5, 633.4
- `filtered_sum via parquet` throughput_per_second: 1.608, 1.605, 1.599
- `numeric_filtered_sum via parquet` latency_p50_ms: 636.8, 633, 639.8
- `numeric_filtered_sum via parquet` latency_p95_ms: 638.3, 634.3, 648
- `numeric_filtered_sum via parquet` latency_p99_ms: 638.4, 634.4, 648.8
- `numeric_filtered_sum via parquet` throughput_per_second: 1.595, 1.581, 1.579

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T153200Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

