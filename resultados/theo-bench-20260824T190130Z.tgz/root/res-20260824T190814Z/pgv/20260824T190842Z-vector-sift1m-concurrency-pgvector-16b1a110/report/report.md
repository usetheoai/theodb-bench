# vector/sift1m/concurrency on pgvector

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T190842Z-vector-sift1m-concurrency-pgvector-16b1a110`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 [c=16] | 1,418 | 0.9275 | 10.2 | 18.45 | 23.15 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64 [c=16]`: latency_p99_ms cv=0.065

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64 [c=16]` build_seconds: 1,441
- `hnsw m=16 ef_search=64 [c=16]` index_size_bytes: 8.183e+08
- `hnsw m=16 ef_search=64 [c=16]` latency_p50_ms: 10.28, 9.837, 10.2
- `hnsw m=16 ef_search=64 [c=16]` latency_p95_ms: 19.45, 18.45, 17.99
- `hnsw m=16 ef_search=64 [c=16]` latency_p99_ms: 25.37, 22.41, 23.15
- `hnsw m=16 ef_search=64 [c=16]` recall: 0.9275, 0.9275, 0.9275
- `hnsw m=16 ef_search=64 [c=16]` throughput_per_second: 1,383, 1,444, 1,418

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T190130Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: a92b338d7ae38c66021724b18d6dad7b3625c89e (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

