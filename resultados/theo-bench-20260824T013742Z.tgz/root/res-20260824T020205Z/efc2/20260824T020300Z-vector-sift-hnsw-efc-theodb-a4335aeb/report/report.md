# vector/sift/hnsw-efc on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T020300Z-vector-sift-hnsw-efc-theodb-a4335aeb`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw ef_construction=64 m=16 ef_search=256 | 524.7 | 0.9944 | 1.877 | 2.217 | 2.379 | yes |
| hnsw ef_construction=64 m=16 ef_search=1000 | 204.8 | 0.9964 | 4.867 | 5.899 | 6.503 | yes |
| hnsw ef_construction=256 m=16 ef_search=256 | 501.3 | 0.9952 | 1.936 | 2.316 | 2.576 | **no** |
| hnsw ef_construction=256 m=16 ef_search=1000 | 194.5 | 0.9962 | 5.148 | 6.248 | 6.723 | yes |
| hnsw ef_construction=1000 m=16 ef_search=256 | 510.3 | 0.9948 | 1.89 | 2.304 | 2.515 | **no** |
| hnsw ef_construction=1000 m=16 ef_search=1000 | 198.5 | 0.9948 | 5.008 | 6.104 | 6.524 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw ef_construction=256 m=16 ef_search=256`: latency_p99_ms cv=0.139
- `hnsw ef_construction=1000 m=16 ef_search=256`: latency_p99_ms cv=0.061

### Repetitions

Every repetition is retained:

- `hnsw ef_construction=64 m=16 ef_search=256` build_seconds: 8.108, 8.108, 8.108
- `hnsw ef_construction=64 m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=64 m=16 ef_search=256` latency_p50_ms: 1.877, 1.87, 1.895
- `hnsw ef_construction=64 m=16 ef_search=256` latency_p95_ms: 2.207, 2.265, 2.217
- `hnsw ef_construction=64 m=16 ef_search=256` latency_p99_ms: 2.341, 2.464, 2.379
- `hnsw ef_construction=64 m=16 ef_search=256` recall: 0.9944, 0.9944, 0.9944
- `hnsw ef_construction=64 m=16 ef_search=256` throughput_per_second: 528.5, 524.7, 519.7
- `hnsw ef_construction=64 m=16 ef_search=1000` build_seconds: 8.006, 8.006, 8.006
- `hnsw ef_construction=64 m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=64 m=16 ef_search=1000` latency_p50_ms: 4.881, 4.86, 4.867
- `hnsw ef_construction=64 m=16 ef_search=1000` latency_p95_ms: 5.874, 5.956, 5.899
- `hnsw ef_construction=64 m=16 ef_search=1000` latency_p99_ms: 6.287, 6.503, 6.607
- `hnsw ef_construction=64 m=16 ef_search=1000` recall: 0.9964, 0.9964, 0.9964
- `hnsw ef_construction=64 m=16 ef_search=1000` throughput_per_second: 204.8, 204.5, 205.9
- `hnsw ef_construction=256 m=16 ef_search=256` build_seconds: 17.44, 17.44, 17.44
- `hnsw ef_construction=256 m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=256 m=16 ef_search=256` latency_p50_ms: 1.936, 1.961, 1.892
- `hnsw ef_construction=256 m=16 ef_search=256` latency_p95_ms: 2.316, 2.38, 2.291
- `hnsw ef_construction=256 m=16 ef_search=256` latency_p99_ms: 3.18, 2.576, 2.477
- `hnsw ef_construction=256 m=16 ef_search=256` recall: 0.9952, 0.9952, 0.9952
- `hnsw ef_construction=256 m=16 ef_search=256` throughput_per_second: 501.3, 498.7, 515.5
- `hnsw ef_construction=256 m=16 ef_search=1000` build_seconds: 17.39, 17.39, 17.39
- `hnsw ef_construction=256 m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=256 m=16 ef_search=1000` latency_p50_ms: 5.355, 5.148, 5.104
- `hnsw ef_construction=256 m=16 ef_search=1000` latency_p95_ms: 6.688, 6.247, 6.248
- `hnsw ef_construction=256 m=16 ef_search=1000` latency_p99_ms: 7.053, 6.723, 6.624
- `hnsw ef_construction=256 m=16 ef_search=1000` recall: 0.9962, 0.9962, 0.9962
- `hnsw ef_construction=256 m=16 ef_search=1000` throughput_per_second: 186.4, 194.5, 196.8
- `hnsw ef_construction=1000 m=16 ef_search=256` build_seconds: 41.72, 41.72, 41.72
- `hnsw ef_construction=1000 m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=1000 m=16 ef_search=256` latency_p50_ms: 1.852, 1.89, 1.921
- `hnsw ef_construction=1000 m=16 ef_search=256` latency_p95_ms: 2.16, 2.341, 2.304
- `hnsw ef_construction=1000 m=16 ef_search=256` latency_p99_ms: 2.281, 2.557, 2.515
- `hnsw ef_construction=1000 m=16 ef_search=256` recall: 0.9948, 0.9948, 0.9948
- `hnsw ef_construction=1000 m=16 ef_search=256` throughput_per_second: 532.4, 510.3, 509
- `hnsw ef_construction=1000 m=16 ef_search=1000` build_seconds: 41.84, 41.84, 41.84
- `hnsw ef_construction=1000 m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw ef_construction=1000 m=16 ef_search=1000` latency_p50_ms: 5.076, 4.977, 5.008
- `hnsw ef_construction=1000 m=16 ef_search=1000` latency_p95_ms: 6.104, 6.032, 6.171
- `hnsw ef_construction=1000 m=16 ef_search=1000` latency_p99_ms: 6.524, 6.368, 6.66
- `hnsw ef_construction=1000 m=16 ef_search=1000` recall: 0.9948, 0.9948, 0.9948
- `hnsw ef_construction=1000 m=16 ef_search=1000` throughput_per_second: 196.8, 201.3, 198.5

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T013742Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 621204feed0e6303ca201fffc9a823cec261a05d (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

