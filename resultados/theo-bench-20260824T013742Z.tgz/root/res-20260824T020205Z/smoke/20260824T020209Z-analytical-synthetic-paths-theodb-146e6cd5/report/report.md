# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T020209Z-analytical-synthetic-paths-theodb-146e6cd5`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 116.4 | _not measured_ | 8.77 | 9.623 | 9.698 | yes |
| sum_amount via row | 93.09 | _not measured_ | 10.83 | 10.85 | 10.85 | **no** |
| group_by_category via row | 47.02 | _not measured_ | 21.45 | 21.8 | 21.84 | yes |
| filtered_sum via row | 76.35 | _not measured_ | 13.21 | 13.21 | 13.22 | yes |
| numeric_filtered_sum via row | 84.4 | _not measured_ | 11.98 | 12.45 | 12.49 | **no** |
| total_rows via columnar | 581 | _not measured_ | 1.847 | 1.953 | 1.961 | **no** |
| sum_amount via columnar | 294 | _not measured_ | 3.483 | 3.623 | 3.643 | yes |
| group_by_category via columnar | 44.86 | _not measured_ | 22.33 | 22.37 | 22.38 | **no** |
| filtered_sum via columnar | 45.76 | _not measured_ | 22.32 | 22.71 | 22.74 | yes |
| numeric_filtered_sum via columnar | 174.9 | _not measured_ | 5.824 | 5.852 | 5.854 | yes |
| total_rows via parquet | 1.931 | _not measured_ | 520 | 520.6 | 520.6 | yes |
| sum_amount via parquet | 1.754 | _not measured_ | 570.9 | 572 | 572.1 | yes |
| group_by_category via parquet | 1.648 | _not measured_ | 607.2 | 608.6 | 608.7 | yes |
| filtered_sum via parquet | 1.804 | _not measured_ | 557.4 | 559.5 | 559.7 | yes |
| numeric_filtered_sum via parquet | 1.769 | _not measured_ | 565.5 | 568.3 | 568.6 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `sum_amount via row`: latency_p95_ms cv=0.094; latency_p99_ms cv=0.102
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.243; latency_p99_ms cv=0.258
- `total_rows via columnar`: latency_p50_ms cv=0.065; latency_p95_ms cv=0.059; latency_p99_ms cv=0.059
- `group_by_category via columnar`: latency_p50_ms cv=0.058; latency_p95_ms cv=0.068; latency_p99_ms cv=0.069; throughput_per_second cv=0.063

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.002, 8.77, 8.641
- `total_rows via row` latency_p95_ms: 9.702, 9.623, 9.491
- `total_rows via row` latency_p99_ms: 9.764, 9.698, 9.567
- `total_rows via row` throughput_per_second: 116.4, 115.2, 119
- `sum_amount via row` latency_p50_ms: 10.84, 10.83, 10.75
- `sum_amount via row` latency_p95_ms: 10.85, 10.84, 12.71
- `sum_amount via row` latency_p99_ms: 10.85, 10.85, 12.88
- `sum_amount via row` throughput_per_second: 92.33, 93.09, 93.27
- `group_by_category via row` latency_p50_ms: 20.95, 21.75, 21.45
- `group_by_category via row` latency_p95_ms: 21.18, 22.74, 21.8
- `group_by_category via row` latency_p99_ms: 21.2, 22.83, 21.84
- `group_by_category via row` throughput_per_second: 48.04, 46.28, 47.02
- `filtered_sum via row` latency_p50_ms: 13.21, 13.28, 13.13
- `filtered_sum via row` latency_p95_ms: 13.21, 13.56, 13.19
- `filtered_sum via row` latency_p99_ms: 13.22, 13.59, 13.2
- `filtered_sum via row` throughput_per_second: 76.35, 75.71, 77.95
- `numeric_filtered_sum via row` latency_p50_ms: 12.7, 11.98, 11.97
- `numeric_filtered_sum via row` latency_p95_ms: 18.27, 12.45, 12.1
- `numeric_filtered_sum via row` latency_p99_ms: 18.76, 12.49, 12.11
- `numeric_filtered_sum via row` throughput_per_second: 83.03, 84.5, 84.4
- `total_rows via columnar` latency_p50_ms: 1.855, 1.651, 1.847
- `total_rows via columnar` latency_p95_ms: 1.953, 1.842, 2.072
- `total_rows via columnar` latency_p99_ms: 1.961, 1.859, 2.092
- `total_rows via columnar` throughput_per_second: 581, 608.9, 559
- `sum_amount via columnar` latency_p50_ms: 3.511, 3.398, 3.483
- `sum_amount via columnar` latency_p95_ms: 3.594, 3.623, 3.639
- `sum_amount via columnar` latency_p99_ms: 3.601, 3.643, 3.652
- `sum_amount via columnar` throughput_per_second: 287, 296.4, 294
- `group_by_category via columnar` latency_p50_ms: 20.28, 22.33, 22.6
- `group_by_category via columnar` latency_p95_ms: 20.3, 22.37, 23.18
- `group_by_category via columnar` latency_p99_ms: 20.3, 22.38, 23.23
- `group_by_category via columnar` throughput_per_second: 49.64, 44.86, 44.38
- `filtered_sum via columnar` latency_p50_ms: 23.03, 21.87, 22.32
- `filtered_sum via columnar` latency_p95_ms: 23.31, 21.97, 22.71
- `filtered_sum via columnar` latency_p99_ms: 23.34, 21.97, 22.74
- `filtered_sum via columnar` throughput_per_second: 47.23, 45.76, 45.4
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.988, 5.535, 5.824
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.053, 5.8, 5.852
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.058, 5.823, 5.854
- `numeric_filtered_sum via columnar` throughput_per_second: 171.7, 181.1, 174.9
- `total_rows via parquet` latency_p50_ms: 520, 516.6, 533.1
- `total_rows via parquet` latency_p95_ms: 520.6, 517.4, 535
- `total_rows via parquet` latency_p99_ms: 520.6, 517.5, 535.2
- `total_rows via parquet` throughput_per_second: 1.931, 1.947, 1.909
- `sum_amount via parquet` latency_p50_ms: 570.7, 570.9, 576.3
- `sum_amount via parquet` latency_p95_ms: 572, 571.2, 577.2
- `sum_amount via parquet` latency_p99_ms: 572.1, 571.3, 577.3
- `sum_amount via parquet` throughput_per_second: 1.754, 1.761, 1.738
- `group_by_category via parquet` latency_p50_ms: 607.2, 604.8, 611.3
- `group_by_category via parquet` latency_p95_ms: 608.6, 607.6, 614.5
- `group_by_category via parquet` latency_p99_ms: 608.7, 607.8, 614.8
- `group_by_category via parquet` throughput_per_second: 1.648, 1.66, 1.637
- `filtered_sum via parquet` latency_p50_ms: 557.4, 556.9, 567.8
- `filtered_sum via parquet` latency_p95_ms: 559.5, 557.5, 571
- `filtered_sum via parquet` latency_p99_ms: 559.7, 557.6, 571.3
- `filtered_sum via parquet` throughput_per_second: 1.805, 1.804, 1.783
- `numeric_filtered_sum via parquet` latency_p50_ms: 564.8, 565.5, 569.8
- `numeric_filtered_sum via parquet` latency_p95_ms: 568.3, 568, 570
- `numeric_filtered_sum via parquet` latency_p99_ms: 568.6, 568.2, 570
- `numeric_filtered_sum via parquet` throughput_per_second: 1.782, 1.769, 1.767

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T013742Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 621204feed0e6303ca201fffc9a823cec261a05d (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

