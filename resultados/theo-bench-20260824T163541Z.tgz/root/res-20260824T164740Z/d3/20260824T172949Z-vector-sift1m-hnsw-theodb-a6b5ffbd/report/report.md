# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T172949Z-vector-sift1m-hnsw-theodb-a6b5ffbd`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 715.2 | 0.897 | 1.354 | 1.597 | 1.745 | **no** |
| hnsw m=16 ef_search=256 | 262.4 | 0.99 | 3.832 | 4.44 | 4.812 | **no** |
| hnsw m=16 ef_search=512 | 163 | 0.998 | 6.255 | 7.458 | 7.848 | yes |
| hnsw m=16 ef_search=1000 | 94.06 | 0.9996 | 10.78 | 13.51 | 14.54 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.086; latency_p95_ms cv=0.054; latency_p99_ms cv=0.060; throughput_per_second cv=0.069
- `hnsw m=16 ef_search=256`: latency_p99_ms cv=0.059

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 203.4, 203.4, 203.4
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.177, 1.354, 1.386
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.455, 1.597, 1.606
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.575, 1.745, 1.759
- `hnsw m=16 ef_search=64` recall: 0.897, 0.897, 0.897
- `hnsw m=16 ef_search=64` throughput_per_second: 796.9, 715.2, 702.5
- `hnsw m=16 ef_search=256` build_seconds: 202.4, 202.4, 202.4
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.832, 3.946, 3.664
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.44, 4.623, 4.275
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.812, 5.121, 4.548
- `hnsw m=16 ef_search=256` recall: 0.99, 0.99, 0.99
- `hnsw m=16 ef_search=256` throughput_per_second: 262.4, 253.5, 273.6
- `hnsw m=16 ef_search=512` build_seconds: 201.7, 201.7, 201.7
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.254, 6.272, 6.255
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.573, 7.458, 7.43
- `hnsw m=16 ef_search=512` latency_p99_ms: 8.09, 7.848, 7.779
- `hnsw m=16 ef_search=512` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=512` throughput_per_second: 162, 163, 163.9
- `hnsw m=16 ef_search=1000` build_seconds: 201.6, 201.6, 201.6
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 10.78, 10.73, 10.87
- `hnsw m=16 ef_search=1000` latency_p95_ms: 13.36, 13.52, 13.51
- `hnsw m=16 ef_search=1000` latency_p99_ms: 14.09, 14.54, 14.86
- `hnsw m=16 ef_search=1000` recall: 0.9996, 0.9996, 0.9996
- `hnsw m=16 ef_search=1000` throughput_per_second: 94.06, 94.42, 93.39

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T163541Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

