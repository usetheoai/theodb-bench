# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T171711Z-vector-sift1m-hnsw-theodb-9b2d6c85`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 689.8 | 0.8992 | 1.404 | 1.67 | 1.834 | **no** |
| hnsw m=16 ef_search=256 | 287.8 | 0.9892 | 3.518 | 4.087 | 4.409 | yes |
| hnsw m=16 ef_search=512 | 165.5 | 0.9972 | 6.155 | 7.402 | 7.982 | yes |
| hnsw m=16 ef_search=1000 | 93.13 | 0.999 | 10.92 | 13.59 | 14.6 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.050
- `hnsw m=16 ef_search=1000`: latency_p99_ms cv=0.051

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 157.7, 157.7, 157.7
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.364, 1.404, 1.416
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.602, 1.67, 1.717
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.729, 1.834, 1.912
- `hnsw m=16 ef_search=64` recall: 0.8992, 0.8992, 0.8992
- `hnsw m=16 ef_search=64` throughput_per_second: 718.8, 689.8, 688.5
- `hnsw m=16 ef_search=256` build_seconds: 155.8, 155.8, 155.8
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.518, 3.445, 3.567
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.051, 4.087, 4.192
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.208, 4.409, 4.424
- `hnsw m=16 ef_search=256` recall: 0.9892, 0.9892, 0.9892
- `hnsw m=16 ef_search=256` throughput_per_second: 289.6, 287.8, 282.8
- `hnsw m=16 ef_search=512` build_seconds: 156.9, 156.9, 156.9
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.155, 5.999, 6.217
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.402, 7.369, 7.607
- `hnsw m=16 ef_search=512` latency_p99_ms: 7.903, 7.982, 8.338
- `hnsw m=16 ef_search=512` recall: 0.9972, 0.9972, 0.9972
- `hnsw m=16 ef_search=512` throughput_per_second: 165.5, 169.2, 162.8
- `hnsw m=16 ef_search=1000` build_seconds: 155.1, 155.1, 155.1
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 10.51, 10.92, 11.58
- `hnsw m=16 ef_search=1000` latency_p95_ms: 13.09, 13.59, 14.07
- `hnsw m=16 ef_search=1000` latency_p99_ms: 13.67, 15.11, 14.6
- `hnsw m=16 ef_search=1000` recall: 0.999, 0.999, 0.999
- `hnsw m=16 ef_search=1000` throughput_per_second: 96.23, 93.13, 88.88

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T163541Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

