# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T164744Z-analytical-synthetic-paths-theodb-3b4121a1`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 113.5 | _not measured_ | 9.009 | 9.687 | 9.747 | **no** |
| sum_amount via row | 89.92 | _not measured_ | 11.6 | 11.74 | 11.76 | **no** |
| group_by_category via row | 45.42 | _not measured_ | 22.35 | 23.55 | 23.67 | **no** |
| filtered_sum via row | 69.07 | _not measured_ | 15.02 | 15.69 | 15.73 | **no** |
| numeric_filtered_sum via row | 78.26 | _not measured_ | 12.94 | 12.96 | 12.96 | **no** |
| total_rows via columnar | 596.9 | _not measured_ | 1.77 | 1.932 | 1.944 | yes |
| sum_amount via columnar | 283.3 | _not measured_ | 3.57 | 3.834 | 3.861 | yes |
| group_by_category via columnar | 43.41 | _not measured_ | 23.37 | 23.89 | 23.94 | yes |
| filtered_sum via columnar | 43.69 | _not measured_ | 23.15 | 23.19 | 23.19 | **no** |
| numeric_filtered_sum via columnar | 166.6 | _not measured_ | 6.013 | 6.347 | 6.361 | yes |
| total_rows via parquet | 1.894 | _not measured_ | 531.5 | 535.3 | 535.6 | yes |
| sum_amount via parquet | 1.714 | _not measured_ | 586.8 | 589.2 | 589.4 | yes |
| group_by_category via parquet | 1.63 | _not measured_ | 618.9 | 621.9 | 622.2 | yes |
| filtered_sum via parquet | 1.769 | _not measured_ | 571.8 | 577.5 | 578 | **no** |
| numeric_filtered_sum via parquet | 1.716 | _not measured_ | 584.6 | 586.3 | 586.8 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p50_ms cv=0.083; throughput_per_second cv=0.081
- `sum_amount via row`: latency_p50_ms cv=0.061; latency_p95_ms cv=0.060; latency_p99_ms cv=0.060; throughput_per_second cv=0.065
- `group_by_category via row`: latency_p50_ms cv=0.068; latency_p95_ms cv=0.066; latency_p99_ms cv=0.067; throughput_per_second cv=0.064
- `filtered_sum via row`: latency_p50_ms cv=0.051; latency_p95_ms cv=0.065; latency_p99_ms cv=0.066
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.076; latency_p95_ms cv=0.077; latency_p99_ms cv=0.077; throughput_per_second cv=0.074
- `filtered_sum via columnar`: latency_p50_ms cv=0.085; latency_p95_ms cv=0.083; latency_p99_ms cv=0.083; throughput_per_second cv=0.083
- `filtered_sum via parquet`: latency_p99_ms cv=0.052

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 8.638, 10.11, 9.009
- `total_rows via row` latency_p95_ms: 9.271, 10.11, 9.687
- `total_rows via row` latency_p99_ms: 9.328, 10.11, 9.747
- `total_rows via row` throughput_per_second: 117.3, 100.3, 113.5
- `sum_amount via row` latency_p50_ms: 10.87, 12.29, 11.6
- `sum_amount via row` latency_p95_ms: 10.93, 12.33, 11.74
- `sum_amount via row` latency_p99_ms: 10.93, 12.33, 11.76
- `sum_amount via row` throughput_per_second: 92.56, 81.64, 89.92
- `group_by_category via row` latency_p50_ms: 22.35, 25.01, 22.2
- `group_by_category via row` latency_p95_ms: 22.45, 25.58, 23.55
- `group_by_category via row` latency_p99_ms: 22.46, 25.63, 23.67
- `group_by_category via row` throughput_per_second: 46.22, 40.95, 45.42
- `filtered_sum via row` latency_p50_ms: 13.88, 15.3, 15.02
- `filtered_sum via row` latency_p95_ms: 14.19, 15.69, 16.06
- `filtered_sum via row` latency_p99_ms: 14.22, 15.73, 16.15
- `filtered_sum via row` throughput_per_second: 72.92, 68.3, 69.07
- `numeric_filtered_sum via row` latency_p50_ms: 12.94, 14.71, 12.94
- `numeric_filtered_sum via row` latency_p95_ms: 12.95, 14.77, 12.96
- `numeric_filtered_sum via row` latency_p99_ms: 12.95, 14.77, 12.96
- `numeric_filtered_sum via row` throughput_per_second: 78.26, 69.1, 79.11
- `total_rows via columnar` latency_p50_ms: 1.77, 1.795, 1.711
- `total_rows via columnar` latency_p95_ms: 1.971, 1.932, 1.835
- `total_rows via columnar` latency_p99_ms: 1.988, 1.944, 1.846
- `total_rows via columnar` throughput_per_second: 566.6, 596.9, 606.3
- `sum_amount via columnar` latency_p50_ms: 3.534, 3.701, 3.57
- `sum_amount via columnar` latency_p95_ms: 3.834, 3.891, 3.584
- `sum_amount via columnar` latency_p99_ms: 3.861, 3.908, 3.586
- `sum_amount via columnar` throughput_per_second: 283.3, 271.6, 289.4
- `group_by_category via columnar` latency_p50_ms: 22.19, 23.63, 23.37
- `group_by_category via columnar` latency_p95_ms: 22.86, 23.94, 23.89
- `group_by_category via columnar` latency_p99_ms: 22.92, 23.97, 23.94
- `group_by_category via columnar` throughput_per_second: 46.06, 42.53, 43.41
- `filtered_sum via columnar` latency_p50_ms: 20.55, 23.15, 24.3
- `filtered_sum via columnar` latency_p95_ms: 20.88, 23.19, 24.67
- `filtered_sum via columnar` latency_p99_ms: 20.91, 23.19, 24.7
- `filtered_sum via columnar` throughput_per_second: 48.72, 43.69, 41.5
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.866, 6.187, 6.013
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.952, 6.347, 6.455
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.96, 6.361, 6.494
- `numeric_filtered_sum via columnar` throughput_per_second: 171.3, 162, 166.6
- `total_rows via parquet` latency_p50_ms: 526.7, 531.5, 535
- `total_rows via parquet` latency_p95_ms: 531.6, 535.3, 550.1
- `total_rows via parquet` latency_p99_ms: 532, 535.6, 551.5
- `total_rows via parquet` throughput_per_second: 1.909, 1.894, 1.871
- `sum_amount via parquet` latency_p50_ms: 586.3, 594.6, 586.8
- `sum_amount via parquet` latency_p95_ms: 588.6, 623.2, 589.2
- `sum_amount via parquet` latency_p99_ms: 588.8, 625.7, 589.4
- `sum_amount via parquet` throughput_per_second: 1.714, 1.693, 1.714
- `group_by_category via parquet` latency_p50_ms: 613.9, 618.9, 626.5
- `group_by_category via parquet` latency_p95_ms: 616.4, 621.9, 628.3
- `group_by_category via parquet` latency_p99_ms: 616.6, 622.2, 628.4
- `group_by_category via parquet` throughput_per_second: 1.63, 1.625, 1.635
- `filtered_sum via parquet` latency_p50_ms: 564.3, 571.8, 581.3
- `filtered_sum via parquet` latency_p95_ms: 564.8, 577.5, 619.6
- `filtered_sum via parquet` latency_p99_ms: 564.8, 578, 623
- `filtered_sum via parquet` throughput_per_second: 1.776, 1.769, 1.754
- `numeric_filtered_sum via parquet` latency_p50_ms: 586, 580.2, 584.6
- `numeric_filtered_sum via parquet` latency_p95_ms: 586.3, 586.3, 590.3
- `numeric_filtered_sum via parquet` latency_p99_ms: 586.3, 586.8, 590.9
- `numeric_filtered_sum via parquet` throughput_per_second: 1.714, 1.745, 1.716

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T163541Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

