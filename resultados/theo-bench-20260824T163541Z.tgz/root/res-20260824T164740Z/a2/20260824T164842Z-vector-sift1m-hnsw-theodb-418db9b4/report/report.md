# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T164842Z-vector-sift1m-hnsw-theodb-418db9b4`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 710.2 | 0.898 | 1.377 | 1.642 | 1.82 | **no** |
| hnsw m=16 ef_search=256 | 276.5 | 0.99 | 3.613 | 4.253 | 4.641 | yes |
| hnsw m=16 ef_search=512 | 162.9 | 0.9974 | 6.226 | 7.573 | 7.962 | yes |
| hnsw m=16 ef_search=1000 | 91.12 | 0.999 | 11.16 | 13.9 | 14.8 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.061; latency_p99_ms cv=0.054

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 159, 159, 159
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.251, 1.404, 1.377
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.559, 1.654, 1.642
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.668, 1.82, 1.844
- `hnsw m=16 ef_search=64` recall: 0.898, 0.898, 0.898
- `hnsw m=16 ef_search=64` throughput_per_second: 757.9, 690.9, 710.2
- `hnsw m=16 ef_search=256` build_seconds: 156.8, 156.8, 156.8
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.52, 3.678, 3.613
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.15, 4.345, 4.253
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.403, 4.641, 4.789
- `hnsw m=16 ef_search=256` recall: 0.99, 0.99, 0.99
- `hnsw m=16 ef_search=256` throughput_per_second: 285.6, 270.6, 276.5
- `hnsw m=16 ef_search=512` build_seconds: 157, 157, 157
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.101, 6.226, 6.286
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.339, 7.573, 7.586
- `hnsw m=16 ef_search=512` latency_p99_ms: 7.859, 8.176, 7.962
- `hnsw m=16 ef_search=512` recall: 0.9974, 0.9974, 0.9974
- `hnsw m=16 ef_search=512` throughput_per_second: 166.7, 162.3, 162.9
- `hnsw m=16 ef_search=1000` build_seconds: 156.9, 156.9, 156.9
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 11.83, 11.16, 11.16
- `hnsw m=16 ef_search=1000` latency_p95_ms: 14.56, 13.9, 13.62
- `hnsw m=16 ef_search=1000` latency_p99_ms: 15.54, 14.8, 14.36
- `hnsw m=16 ef_search=1000` recall: 0.999, 0.999, 0.999
- `hnsw m=16 ef_search=1000` throughput_per_second: 86.02, 91.12, 91.57

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T163541Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

