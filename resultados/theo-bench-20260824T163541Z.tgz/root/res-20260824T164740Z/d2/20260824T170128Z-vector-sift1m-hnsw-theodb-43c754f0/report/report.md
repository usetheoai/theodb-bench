# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T170128Z-vector-sift1m-hnsw-theodb-43c754f0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 699.4 | 0.9008 | 1.384 | 1.632 | 1.824 | yes |
| hnsw m=16 ef_search=256 | 286.8 | 0.9892 | 3.517 | 4.063 | 4.333 | yes |
| hnsw m=16 ef_search=512 | 168.3 | 0.9976 | 6.025 | 7.299 | 7.845 | yes |
| hnsw m=16 ef_search=1000 | 93.87 | 0.9998 | 10.89 | 13.55 | 14.74 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=1000`: latency_p99_ms cv=0.058

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 203.1, 203.1, 203.1
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.379, 1.384, 1.417
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.63, 1.632, 1.672
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.761, 1.824, 1.865
- `hnsw m=16 ef_search=64` recall: 0.9008, 0.9008, 0.9008
- `hnsw m=16 ef_search=64` throughput_per_second: 709.6, 699.4, 684.8
- `hnsw m=16 ef_search=256` build_seconds: 202.1, 202.1, 202.1
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.517, 3.566, 3.459
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.063, 4.174, 4.026
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.307, 4.572, 4.333
- `hnsw m=16 ef_search=256` recall: 0.9892, 0.9892, 0.9892
- `hnsw m=16 ef_search=256` throughput_per_second: 286.8, 279, 291.9
- `hnsw m=16 ef_search=512` build_seconds: 201.7, 201.7, 201.7
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.025, 5.982, 6.092
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.305, 7.299, 7.274
- `hnsw m=16 ef_search=512` latency_p99_ms: 7.883, 7.845, 7.752
- `hnsw m=16 ef_search=512` recall: 0.9976, 0.9976, 0.9976
- `hnsw m=16 ef_search=512` throughput_per_second: 168.3, 168.9, 166.7
- `hnsw m=16 ef_search=1000` build_seconds: 201.3, 201.3, 201.3
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 11.46, 10.72, 10.89
- `hnsw m=16 ef_search=1000` latency_p95_ms: 14.36, 13.18, 13.55
- `hnsw m=16 ef_search=1000` latency_p99_ms: 16, 14.34, 14.74
- `hnsw m=16 ef_search=1000` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=1000` throughput_per_second: 88.24, 95.48, 93.87

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T163541Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

