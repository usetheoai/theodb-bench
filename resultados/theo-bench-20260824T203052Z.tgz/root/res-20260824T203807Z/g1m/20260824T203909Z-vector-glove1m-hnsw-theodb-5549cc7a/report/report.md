# vector/glove1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T203909Z-vector-glove1m-hnsw-theodb-5549cc7a`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 682.9 | 0.5562 | 1.321 | 1.764 | 1.941 | yes |
| hnsw m=16 ef_search=64 | 540 | 0.7048 | 1.655 | 2.423 | 2.828 | yes |
| hnsw m=16 ef_search=256 | 226.1 | 0.859 | 4.293 | 5.636 | 6.441 | yes |
| hnsw m=16 ef_search=512 | 116.3 | 0.9026 | 8.582 | 10.85 | 12.06 | yes |
| hnsw m=16 ef_search=1000 | 66.75 | 0.9396 | 15.03 | 19.35 | 20.44 | yes |

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 573.2
- `hnsw m=16 ef_search=16` index_size_bytes: 7.625e+08
- `hnsw m=16 ef_search=16` latency_p50_ms: 1.35, 1.321, 1.271
- `hnsw m=16 ef_search=16` latency_p95_ms: 1.764, 1.768, 1.69
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.941, 1.943, 1.831
- `hnsw m=16 ef_search=16` recall: 0.5562, 0.5562, 0.5562
- `hnsw m=16 ef_search=16` throughput_per_second: 657.1, 682.9, 709.6
- `hnsw m=16 ef_search=64` build_seconds: 588.3
- `hnsw m=16 ef_search=64` index_size_bytes: 7.625e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.636, 1.662, 1.655
- `hnsw m=16 ef_search=64` latency_p95_ms: 2.403, 2.423, 2.499
- `hnsw m=16 ef_search=64` latency_p99_ms: 2.781, 2.94, 2.828
- `hnsw m=16 ef_search=64` recall: 0.7048, 0.7048, 0.7048
- `hnsw m=16 ef_search=64` throughput_per_second: 548.7, 531.1, 540
- `hnsw m=16 ef_search=256` build_seconds: 572.7
- `hnsw m=16 ef_search=256` index_size_bytes: 7.625e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 4.283, 4.293, 4.385
- `hnsw m=16 ef_search=256` latency_p95_ms: 5.636, 5.635, 5.811
- `hnsw m=16 ef_search=256` latency_p99_ms: 6.386, 6.441, 6.475
- `hnsw m=16 ef_search=256` recall: 0.859, 0.859, 0.859
- `hnsw m=16 ef_search=256` throughput_per_second: 226.7, 226.1, 221.6
- `hnsw m=16 ef_search=512` build_seconds: 572.1
- `hnsw m=16 ef_search=512` index_size_bytes: 7.625e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 8.593, 8.582, 8.12
- `hnsw m=16 ef_search=512` latency_p95_ms: 10.85, 11.05, 10.55
- `hnsw m=16 ef_search=512` latency_p99_ms: 12.06, 12.64, 11.69
- `hnsw m=16 ef_search=512` recall: 0.9026, 0.9026, 0.9026
- `hnsw m=16 ef_search=512` throughput_per_second: 116.3, 116, 122
- `hnsw m=16 ef_search=1000` build_seconds: 570.7
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.625e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 14.97, 15.03, 15.05
- `hnsw m=16 ef_search=1000` latency_p95_ms: 19.35, 19.4, 19.21
- `hnsw m=16 ef_search=1000` latency_p99_ms: 20.44, 20.31, 20.96
- `hnsw m=16 ef_search=1000` recall: 0.9396, 0.9396, 0.9396
- `hnsw m=16 ef_search=1000` throughput_per_second: 66.74, 66.84, 66.75

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T203052Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 050b36413669fe60d2fede065a7aeffebc534b07 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

