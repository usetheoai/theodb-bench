# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T203811Z-analytical-synthetic-paths-theodb-d8d4ea20`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 95.52 | _not measured_ | 10.6 | 10.86 | 10.89 | **no** |
| sum_amount via row | 75.27 | _not measured_ | 13.84 | 14.17 | 14.19 | yes |
| group_by_category via row | 39.99 | _not measured_ | 25.24 | 25.75 | 25.8 | yes |
| filtered_sum via row | 61.15 | _not measured_ | 16.74 | 23.52 | 24.13 | **no** |
| numeric_filtered_sum via row | 66.47 | _not measured_ | 15.05 | 15.18 | 15.19 | **no** |
| total_rows via columnar | 514.7 | _not measured_ | 1.988 | 2.075 | 2.082 | **no** |
| sum_amount via columnar | 242.6 | _not measured_ | 4.306 | 4.442 | 4.445 | yes |
| group_by_category via columnar | 37.11 | _not measured_ | 27.55 | 27.67 | 27.68 | **no** |
| filtered_sum via columnar | 37.55 | _not measured_ | 26.91 | 27.18 | 27.2 | **no** |
| numeric_filtered_sum via columnar | 142 | _not measured_ | 7.19 | 7.461 | 7.485 | **no** |
| total_rows via parquet | 1.681 | _not measured_ | 596.1 | 605.5 | 605.8 | yes |
| sum_amount via parquet | 1.529 | _not measured_ | 657.4 | 660.3 | 660.5 | yes |
| group_by_category via parquet | 1.43 | _not measured_ | 702.1 | 704.6 | 704.8 | yes |
| filtered_sum via parquet | 1.563 | _not measured_ | 643.9 | 645.2 | 645.5 | yes |
| numeric_filtered_sum via parquet | 1.539 | _not measured_ | 654.3 | 668.6 | 669.9 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p50_ms cv=0.064; latency_p95_ms cv=0.106; latency_p99_ms cv=0.109
- `filtered_sum via row`: latency_p50_ms cv=0.225; latency_p95_ms cv=0.214; latency_p99_ms cv=0.220
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.074; latency_p95_ms cv=0.235; latency_p99_ms cv=0.247; throughput_per_second cv=0.053
- `total_rows via columnar`: latency_p50_ms cv=0.054; latency_p95_ms cv=0.096; latency_p99_ms cv=0.099
- `group_by_category via columnar`: latency_p50_ms cv=0.076; latency_p95_ms cv=0.069; latency_p99_ms cv=0.068; throughput_per_second cv=0.069
- `filtered_sum via columnar`: latency_p50_ms cv=0.068; latency_p95_ms cv=0.071; latency_p99_ms cv=0.072; throughput_per_second cv=0.067
- `numeric_filtered_sum via columnar`: throughput_per_second cv=0.055

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 11.7, 10.6, 10.43
- `total_rows via row` latency_p95_ms: 12.79, 10.86, 10.58
- `total_rows via row` latency_p99_ms: 12.89, 10.89, 10.59
- `total_rows via row` throughput_per_second: 91.61, 95.52, 99.13
- `sum_amount via row` latency_p50_ms: 13.84, 13.98, 13.3
- `sum_amount via row` latency_p95_ms: 14.54, 14.17, 13.35
- `sum_amount via row` latency_p99_ms: 14.6, 14.19, 13.35
- `sum_amount via row` throughput_per_second: 75.27, 73.44, 77.23
- `group_by_category via row` latency_p50_ms: 26.16, 25.19, 25.24
- `group_by_category via row` latency_p95_ms: 26.23, 25.75, 25.43
- `group_by_category via row` latency_p99_ms: 26.24, 25.8, 25.45
- `group_by_category via row` throughput_per_second: 38.33, 39.99, 40.06
- `filtered_sum via row` latency_p50_ms: 16.74, 23.68, 15.99
- `filtered_sum via row` latency_p95_ms: 23.52, 24.24, 16.03
- `filtered_sum via row` latency_p99_ms: 24.13, 24.29, 16.04
- `filtered_sum via row` throughput_per_second: 59.85, 61.15, 64.46
- `numeric_filtered_sum via row` latency_p50_ms: 16.83, 15.05, 14.68
- `numeric_filtered_sum via row` latency_p95_ms: 21.96, 15.18, 14.71
- `numeric_filtered_sum via row` latency_p99_ms: 22.41, 15.19, 14.72
- `numeric_filtered_sum via row` throughput_per_second: 62.28, 66.47, 69.21
- `total_rows via columnar` latency_p50_ms: 2.168, 1.988, 1.968
- `total_rows via columnar` latency_p95_ms: 2.422, 2.075, 2.049
- `total_rows via columnar` latency_p99_ms: 2.445, 2.082, 2.057
- `total_rows via columnar` throughput_per_second: 499.6, 515.3, 514.7
- `sum_amount via columnar` latency_p50_ms: 4.177, 4.306, 4.407
- `sum_amount via columnar` latency_p95_ms: 4.206, 4.493, 4.442
- `sum_amount via columnar` latency_p99_ms: 4.208, 4.509, 4.445
- `sum_amount via columnar` throughput_per_second: 242.6, 243.1, 235.3
- `group_by_category via columnar` latency_p50_ms: 24.23, 27.55, 27.85
- `group_by_category via columnar` latency_p95_ms: 24.6, 27.67, 27.87
- `group_by_category via columnar` latency_p99_ms: 24.64, 27.68, 27.87
- `group_by_category via columnar` throughput_per_second: 41.32, 36.43, 37.11
- `filtered_sum via columnar` latency_p50_ms: 23.88, 26.91, 26.97
- `filtered_sum via columnar` latency_p95_ms: 23.99, 27.26, 27.18
- `filtered_sum via columnar` latency_p99_ms: 24, 27.29, 27.2
- `filtered_sum via columnar` throughput_per_second: 41.94, 37.3, 37.55
- `numeric_filtered_sum via columnar` latency_p50_ms: 7.455, 7.19, 6.874
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.548, 7.461, 7.106
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.556, 7.485, 7.127
- `numeric_filtered_sum via columnar` throughput_per_second: 139.3, 142, 154.2
- `total_rows via parquet` latency_p50_ms: 594.6, 602.3, 596.1
- `total_rows via parquet` latency_p95_ms: 599.8, 605.5, 605.7
- `total_rows via parquet` latency_p99_ms: 600.3, 605.8, 606.5
- `total_rows via parquet` throughput_per_second: 1.685, 1.68, 1.681
- `sum_amount via parquet` latency_p50_ms: 663.3, 654.6, 657.4
- `sum_amount via parquet` latency_p95_ms: 682.2, 657.1, 660.3
- `sum_amount via parquet` latency_p99_ms: 683.9, 657.4, 660.5
- `sum_amount via parquet` throughput_per_second: 1.528, 1.529, 1.53
- `group_by_category via parquet` latency_p50_ms: 701, 703.2, 702.1
- `group_by_category via parquet` latency_p95_ms: 702.3, 704.6, 710.6
- `group_by_category via parquet` latency_p99_ms: 702.4, 704.8, 711.3
- `group_by_category via parquet` throughput_per_second: 1.438, 1.43, 1.427
- `filtered_sum via parquet` latency_p50_ms: 641.8, 649.8, 643.9
- `filtered_sum via parquet` latency_p95_ms: 645.2, 650.8, 644.1
- `filtered_sum via parquet` latency_p99_ms: 645.5, 650.9, 644.1
- `filtered_sum via parquet` throughput_per_second: 1.565, 1.543, 1.563
- `numeric_filtered_sum via parquet` latency_p50_ms: 650.7, 654.3, 665.1
- `numeric_filtered_sum via parquet` latency_p95_ms: 653.2, 668.6, 674.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 653.4, 669.9, 675.2
- `numeric_filtered_sum via parquet` throughput_per_second: 1.539, 1.541, 1.507

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T203052Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 050b36413669fe60d2fede065a7aeffebc534b07 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

