# vector/sift/hnsw on pgvector

**Status:** INVALID · **Profile:** nightly · **Run:** `20260822T184637Z-vector-sift-hnsw-pgvector-9470f950`

> This run is **INVALID**. It failed protocol validation, which says nothing about whether the numbers were favourable -- invalidation is never based on the measured outcome.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,180 | 0.8856 | 0.7015 | 0.9036 | 1 | **no** |
| hnsw m=16 ef_search=64 | 697.1 | 0.988 | 1.352 | 1.646 | 1.759 | **no** |
| hnsw m=16 ef_search=256 | 299.7 | 0.9998 | 3.251 | 4.126 | 4.46 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.061; latency_p95_ms cv=0.057; latency_p99_ms cv=0.056
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.062

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 33.06, 33.06, 33.06
- `hnsw m=16 ef_search=16` index_size_bytes: 8.313e+07, 8.313e+07, 8.313e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.7771, 0.6987, 0.7015
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.9807, 0.8793, 0.9036
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.092, 1, 0.9864
- `hnsw m=16 ef_search=16` recall: 0.8856, 0.8856, 0.8856
- `hnsw m=16 ef_search=16` throughput_per_second: 1,147, 1,180, 1,216
- `hnsw m=16 ef_search=64` build_seconds: 35.09, 35.09, 35.09
- `hnsw m=16 ef_search=64` index_size_bytes: 8.312e+07, 8.312e+07, 8.312e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.352, 1.382, 1.315
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.646, 1.734, 1.601
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.759, 1.926, 1.713
- `hnsw m=16 ef_search=64` recall: 0.988, 0.988, 0.988
- `hnsw m=16 ef_search=64` throughput_per_second: 697.1, 666.3, 722.3
- `hnsw m=16 ef_search=256` build_seconds: 33.34, 33.34, 33.34
- `hnsw m=16 ef_search=256` index_size_bytes: 8.315e+07, 8.315e+07, 8.315e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.315, 3.251, 3.172
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.154, 4.126, 3.955
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.46, 4.512, 4.194
- `hnsw m=16 ef_search=256` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=256` throughput_per_second: 297.1, 299.7, 309.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | yes |  |
| cpu_limit | UNAVAILABLE | yes | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | yes | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |
| regression_baseline | UNAVAILABLE | no | ProfileName.NIGHTLY gates on regression and no baseline was supplied: unavailable: no baseline supplied for this run. No regression detection was performed |

Invalidated by: `cpu_limit`, `memory_limit`

Invalidation is based on protocol criteria, never on whether the numbers looked good.

## Environment

- Host: theo-bench-20260822T183627Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d38fbf857070b835eafbe8984ac2b6a2e42a283a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

