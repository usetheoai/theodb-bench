# vector/sift/hnsw on theodb

**Status:** INVALID · **Profile:** nightly · **Run:** `20260822T184509Z-vector-sift-hnsw-theodb-694d3a80`

> This run is **INVALID**. It failed protocol validation, which says nothing about whether the numbers were favourable -- invalidation is never based on the measured outcome.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,066 | 0.869 | 0.8414 | 1.054 | 1.178 | **no** |
| hnsw m=16 ef_search=64 | 880.3 | 0.9606 | 1.043 | 1.32 | 1.417 | yes |
| hnsw m=16 ef_search=256 | 369.3 | 0.9952 | 2.656 | 3.32 | 3.531 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p95_ms cv=0.088; latency_p99_ms cv=0.110; throughput_per_second cv=0.059

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 10.34, 10.34, 10.34
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.8414, 0.8056, 0.8744
- `hnsw m=16 ef_search=16` latency_p95_ms: 1.054, 1.005, 1.19
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.178, 1.117, 1.373
- `hnsw m=16 ef_search=16` recall: 0.869, 0.869, 0.869
- `hnsw m=16 ef_search=16` throughput_per_second: 1,066, 1,127, 1,002
- `hnsw m=16 ef_search=64` build_seconds: 9.206, 9.206, 9.206
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.036, 1.065, 1.043
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.33, 1.32, 1.267
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.49, 1.417, 1.39
- `hnsw m=16 ef_search=64` recall: 0.9606, 0.9606, 0.9606
- `hnsw m=16 ef_search=64` throughput_per_second: 880.3, 837.3, 880.9
- `hnsw m=16 ef_search=256` build_seconds: 9.234, 9.234, 9.234
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.659, 2.656, 2.614
- `hnsw m=16 ef_search=256` latency_p95_ms: 3.32, 3.25, 3.329
- `hnsw m=16 ef_search=256` latency_p99_ms: 3.531, 3.531, 3.669
- `hnsw m=16 ef_search=256` recall: 0.9952, 0.9952, 0.9952
- `hnsw m=16 ef_search=256` throughput_per_second: 363.2, 369.3, 374.4

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | yes |  |
| cpu_limit | UNAVAILABLE | yes | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | yes | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |
| regression_baseline | UNAVAILABLE | no | ProfileName.NIGHTLY gates on regression and no baseline was supplied: unavailable: no baseline supplied for this run. No regression detection was performed |

Invalidated by: `cpu_limit`, `memory_limit`

Invalidation is based on protocol criteria, never on whether the numbers looked good.

## Environment

- Host: theo-bench-20260822T183627Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d38fbf857070b835eafbe8984ac2b6a2e42a283a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

