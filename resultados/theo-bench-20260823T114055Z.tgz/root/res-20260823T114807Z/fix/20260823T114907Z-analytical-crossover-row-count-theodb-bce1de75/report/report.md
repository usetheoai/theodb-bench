# analytical/crossover/row-count on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T114907Z-analytical-crossover-row-count-theodb-bce1de75`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row @ 10000 linhas | 1,613 | _not measured_ | 0.7205 | 1.099 | 1.133 | **no** |
| sum_amount via row @ 10000 linhas | 1,375 | _not measured_ | 0.7833 | 0.9093 | 0.9226 | **no** |
| group_by_category via row @ 10000 linhas | 552.6 | _not measured_ | 1.958 | 2.253 | 2.279 | **no** |
| filtered_sum via row @ 10000 linhas | 1,097 | _not measured_ | 0.9523 | 1.136 | 1.143 | **no** |
| numeric_filtered_sum via row @ 10000 linhas | 1,269 | _not measured_ | 0.8147 | 1.598 | 1.668 | **no** |
| total_rows via columnar @ 10000 linhas | 1,080 | _not measured_ | 1.067 | 1.205 | 1.217 | **no** |
| sum_amount via columnar @ 10000 linhas | 899.1 | _not measured_ | 1.249 | 1.315 | 1.32 | yes |
| group_by_category via columnar @ 10000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 10000 linhas | 403.6 | _not measured_ | 2.548 | 2.991 | 3.034 | **no** |
| numeric_filtered_sum via columnar @ 10000 linhas | 648.6 | _not measured_ | 1.643 | 1.751 | 1.753 | **no** |
| total_rows via parquet @ 10000 linhas | 39.52 | _not measured_ | 29.52 | 33.01 | 33.02 | **no** |
| sum_amount via parquet @ 10000 linhas | 35.97 | _not measured_ | 29.31 | 33.44 | 33.8 | **no** |
| group_by_category via parquet @ 10000 linhas | 31.92 | _not measured_ | 34.77 | 36.94 | 37.13 | **no** |
| filtered_sum via parquet @ 10000 linhas | 34.29 | _not measured_ | 38.23 | 48.29 | 49.18 | **no** |
| numeric_filtered_sum via parquet @ 10000 linhas | 30.98 | _not measured_ | 35.36 | 38.38 | 38.65 | **no** |
| total_rows via row @ 50000 linhas | 384.8 | _not measured_ | 3.054 | 3.3 | 3.303 | **no** |
| sum_amount via row @ 50000 linhas | 308.4 | _not measured_ | 3.412 | 4.729 | 4.864 | **no** |
| group_by_category via row @ 50000 linhas | 124.6 | _not measured_ | 8.194 | 8.774 | 8.837 | **no** |
| filtered_sum via row @ 50000 linhas | 256.4 | _not measured_ | 3.988 | 6.182 | 6.386 | **no** |
| numeric_filtered_sum via row @ 50000 linhas | 287.3 | _not measured_ | 3.549 | 3.842 | 3.867 | **no** |
| total_rows via columnar @ 50000 linhas | 791.9 | _not measured_ | 1.313 | 1.383 | 1.389 | **no** |
| sum_amount via columnar @ 50000 linhas | 515.2 | _not measured_ | 1.942 | 2.077 | 2.089 | **no** |
| group_by_category via columnar @ 50000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 50000 linhas | 136.6 | _not measured_ | 7.683 | 10.04 | 10.09 | **no** |
| numeric_filtered_sum via columnar @ 50000 linhas | 362.8 | _not measured_ | 2.824 | 2.826 | 2.826 | **no** |
| total_rows via parquet @ 50000 linhas | 6.293 | _not measured_ | 163.1 | 166.4 | 167 | **no** |
| sum_amount via parquet @ 50000 linhas | 5.745 | _not measured_ | 192.7 | 221.5 | 223.9 | **no** |
| group_by_category via parquet @ 50000 linhas | 5.474 | _not measured_ | 190.1 | 193.1 | 193.4 | **no** |
| filtered_sum via parquet @ 50000 linhas | 6.032 | _not measured_ | 166.4 | 180.8 | 181.1 | **no** |
| numeric_filtered_sum via parquet @ 50000 linhas | 5.712 | _not measured_ | 180.6 | 190.8 | 191.7 | **no** |
| total_rows via row @ 100000 linhas | 199.9 | _not measured_ | 5.37 | 6.837 | 6.912 | **no** |
| sum_amount via row @ 100000 linhas | 163.9 | _not measured_ | 6.888 | 7.932 | 8.058 | **no** |
| group_by_category via row @ 100000 linhas | 62.45 | _not measured_ | 16.83 | 17.35 | 17.4 | **no** |
| filtered_sum via row @ 100000 linhas | 128.8 | _not measured_ | 7.959 | 10.61 | 10.85 | **no** |
| numeric_filtered_sum via row @ 100000 linhas | 146.1 | _not measured_ | 6.951 | 8.71 | 8.88 | **no** |
| total_rows via columnar @ 100000 linhas | 412.1 | _not measured_ | 2.462 | 2.539 | 2.545 | **no** |
| sum_amount via columnar @ 100000 linhas | 284.2 | _not measured_ | 3.577 | 3.6 | 3.602 | **no** |
| group_by_category via columnar @ 100000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 100000 linhas | 59.95 | _not measured_ | 18.73 | 21.13 | 21.21 | **no** |
| numeric_filtered_sum via columnar @ 100000 linhas | 228.2 | _not measured_ | 4.455 | 4.527 | 4.534 | **no** |
| total_rows via parquet @ 100000 linhas | 3.144 | _not measured_ | 322.5 | 326.1 | 326.4 | yes |
| sum_amount via parquet @ 100000 linhas | 2.892 | _not measured_ | 349.1 | 365.4 | 366.8 | **no** |
| group_by_category via parquet @ 100000 linhas | 2.549 | _not measured_ | 400 | 411 | 412 | **no** |
| filtered_sum via parquet @ 100000 linhas | 2.947 | _not measured_ | 365.1 | 400.5 | 404.3 | **no** |
| numeric_filtered_sum via parquet @ 100000 linhas | 2.919 | _not measured_ | 354.7 | 358.8 | 359.2 | yes |
| total_rows via row @ 500000 linhas | 42.46 | _not measured_ | 24.18 | 27.03 | 27.28 | **no** |
| sum_amount via row @ 500000 linhas | 35.95 | _not measured_ | 28.32 | 30.13 | 30.29 | **no** |
| group_by_category via row @ 500000 linhas | 20.47 | _not measured_ | 51.34 | 54.65 | 54.94 | **no** |
| filtered_sum via row @ 500000 linhas | 34.11 | _not measured_ | 29.67 | 32.9 | 33.19 | **no** |
| numeric_filtered_sum via row @ 500000 linhas | 35.98 | _not measured_ | 29.22 | 29.96 | 30.03 | **no** |
| total_rows via columnar @ 500000 linhas | 197.3 | _not measured_ | 5.079 | 5.41 | 5.44 | **no** |
| sum_amount via columnar @ 500000 linhas | 90.31 | _not measured_ | 11.17 | 11.28 | 11.29 | **no** |
| group_by_category via columnar @ 500000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 500000 linhas | 13.94 | _not measured_ | 75.81 | 77.5 | 77.59 | **no** |
| numeric_filtered_sum via columnar @ 500000 linhas | 57.22 | _not measured_ | 17.64 | 18.06 | 18.1 | yes |
| total_rows via parquet @ 500000 linhas | 0.5958 | _not measured_ | 1,701 | 1,778 | 1,785 | **no** |
| sum_amount via parquet @ 500000 linhas | 0.5133 | _not measured_ | 2,038 | 2,090 | 2,095 | **no** |
| group_by_category via parquet @ 500000 linhas | 0.5047 | _not measured_ | 2,122 | 2,237 | 2,247 | **no** |
| filtered_sum via parquet @ 500000 linhas | 0.5533 | _not measured_ | 1,822 | 1,949 | 1,960 | **no** |
| numeric_filtered_sum via parquet @ 500000 linhas | 0.5917 | _not measured_ | 1,744 | 1,845 | 1,854 | **no** |
| total_rows via row @ 1000000 linhas | 34.34 | _not measured_ | 29.77 | 32.7 | 32.96 | **no** |
| sum_amount via row @ 1000000 linhas | 26.35 | _not measured_ | 41.57 | 47.53 | 48.01 | **no** |
| group_by_category via row @ 1000000 linhas | 13.51 | _not measured_ | 76.55 | 76.79 | 76.81 | **no** |
| filtered_sum via row @ 1000000 linhas | 21.66 | _not measured_ | 50.08 | 59.43 | 60.27 | **no** |
| numeric_filtered_sum via row @ 1000000 linhas | 24.58 | _not measured_ | 42.13 | 44.77 | 45.01 | **no** |
| total_rows via columnar @ 1000000 linhas | 91.92 | _not measured_ | 11.36 | 11.82 | 11.82 | **no** |
| sum_amount via columnar @ 1000000 linhas | 40.94 | _not measured_ | 25.02 | 25.25 | 25.26 | **no** |
| group_by_category via columnar @ 1000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 1000000 linhas | 6.79 | _not measured_ | 151.6 | 160.5 | 161.3 | **no** |
| numeric_filtered_sum via columnar @ 1000000 linhas | 28.96 | _not measured_ | 34.61 | 35.46 | 35.6 | **no** |
| total_rows via parquet @ 1000000 linhas | 0.306 | _not measured_ | 3,316 | 3,414 | 3,425 | yes |
| sum_amount via parquet @ 1000000 linhas | 0.2802 | _not measured_ | 3,611 | 3,650 | 3,654 | yes |
| group_by_category via parquet @ 1000000 linhas | 0.2679 | _not measured_ | 3,735 | 3,879 | 3,891 | yes |
| filtered_sum via parquet @ 1000000 linhas | 0.2882 | _not measured_ | 3,507 | 3,719 | 3,743 | yes |
| numeric_filtered_sum via parquet @ 1000000 linhas | 0.2848 | _not measured_ | 3,670 | 3,688 | 3,690 | **no** |
| total_rows via row @ 2000000 linhas | 19.16 | _not measured_ | 57.87 | 63.94 | 63.96 | **no** |
| sum_amount via row @ 2000000 linhas | 14.39 | _not measured_ | 70.67 | 74.62 | 74.98 | **no** |
| group_by_category via row @ 2000000 linhas | 6.873 | _not measured_ | 149.3 | 158.1 | 158.9 | **no** |
| filtered_sum via row @ 2000000 linhas | 12.64 | _not measured_ | 80.19 | 88.59 | 89.34 | **no** |
| numeric_filtered_sum via row @ 2000000 linhas | 13.48 | _not measured_ | 75.41 | 77.95 | 78.23 | **no** |
| total_rows via columnar @ 2000000 linhas | 43.26 | _not measured_ | 23.24 | 23.66 | 23.7 | **no** |
| sum_amount via columnar @ 2000000 linhas | 20.83 | _not measured_ | 49.06 | 49.84 | 49.91 | **no** |
| group_by_category via columnar @ 2000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar @ 2000000 linhas | 3.473 | _not measured_ | 292.4 | 299.5 | 300.1 | **no** |
| numeric_filtered_sum via columnar @ 2000000 linhas | 13.21 | _not measured_ | 75.78 | 77.34 | 77.41 | **no** |
| total_rows via parquet @ 2000000 linhas | 0.1477 | _not measured_ | 6,825 | 7,137 | 7,164 | yes |
| sum_amount via parquet @ 2000000 linhas | 0.1337 | _not measured_ | 7,593 | 7,869 | 7,909 | yes |
| group_by_category via parquet @ 2000000 linhas | 0.1262 | _not measured_ | 7,997 | 8,273 | 8,284 | yes |
| filtered_sum via parquet @ 2000000 linhas | 0.1314 | _not measured_ | 7,759 | 7,990 | 8,011 | yes |
| numeric_filtered_sum via parquet @ 2000000 linhas | 0.1336 | _not measured_ | 7,786 | 7,793 | 7,794 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row @ 10000 linhas`: latency_p50_ms cv=0.578; latency_p95_ms cv=0.428; latency_p99_ms cv=0.419
- `sum_amount via row @ 10000 linhas`: latency_p50_ms cv=0.276; latency_p95_ms cv=0.513; latency_p99_ms cv=0.527
- `group_by_category via row @ 10000 linhas`: latency_p50_ms cv=0.133; latency_p95_ms cv=0.208; latency_p99_ms cv=0.213
- `filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.064; latency_p95_ms cv=0.440; latency_p99_ms cv=0.468
- `numeric_filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.255; latency_p99_ms cv=0.268; throughput_per_second cv=0.069
- `total_rows via columnar @ 10000 linhas`: latency_p50_ms cv=0.095; latency_p95_ms cv=0.096; latency_p99_ms cv=0.096; throughput_per_second cv=0.107
- `filtered_sum via columnar @ 10000 linhas`: latency_p95_ms cv=0.059; latency_p99_ms cv=0.063
- `numeric_filtered_sum via columnar @ 10000 linhas`: latency_p95_ms cv=0.076; latency_p99_ms cv=0.080; throughput_per_second cv=0.063
- `total_rows via parquet @ 10000 linhas`: latency_p50_ms cv=0.128; latency_p95_ms cv=0.070; latency_p99_ms cv=0.068; throughput_per_second cv=0.133
- `sum_amount via parquet @ 10000 linhas`: latency_p50_ms cv=0.122; latency_p95_ms cv=0.096; latency_p99_ms cv=0.094; throughput_per_second cv=0.102
- `group_by_category via parquet @ 10000 linhas`: latency_p50_ms cv=0.155; latency_p95_ms cv=0.214; latency_p99_ms cv=0.220; throughput_per_second cv=0.172
- `filtered_sum via parquet @ 10000 linhas`: latency_p50_ms cv=0.188; latency_p95_ms cv=0.229; latency_p99_ms cv=0.232; throughput_per_second cv=0.117
- `numeric_filtered_sum via parquet @ 10000 linhas`: latency_p50_ms cv=0.088; latency_p95_ms cv=0.089; latency_p99_ms cv=0.090; throughput_per_second cv=0.167
- `total_rows via row @ 50000 linhas`: latency_p50_ms cv=0.086; latency_p95_ms cv=0.094; latency_p99_ms cv=0.097
- `sum_amount via row @ 50000 linhas`: latency_p50_ms cv=0.370; latency_p95_ms cv=0.350; latency_p99_ms cv=0.350
- `group_by_category via row @ 50000 linhas`: latency_p50_ms cv=0.119; latency_p95_ms cv=0.131; latency_p99_ms cv=0.132
- `filtered_sum via row @ 50000 linhas`: latency_p50_ms cv=0.238; latency_p95_ms cv=0.235; latency_p99_ms cv=0.241; throughput_per_second cv=0.182
- `numeric_filtered_sum via row @ 50000 linhas`: latency_p95_ms cv=0.275; latency_p99_ms cv=0.294
- `total_rows via columnar @ 50000 linhas`: latency_p50_ms cv=0.157; latency_p95_ms cv=0.142; latency_p99_ms cv=0.141; throughput_per_second cv=0.135
- `sum_amount via columnar @ 50000 linhas`: latency_p50_ms cv=0.157; latency_p95_ms cv=0.132; latency_p99_ms cv=0.130; throughput_per_second cv=0.145
- `filtered_sum via columnar @ 50000 linhas`: latency_p50_ms cv=0.144; latency_p95_ms cv=0.081; latency_p99_ms cv=0.084; throughput_per_second cv=0.141
- `numeric_filtered_sum via columnar @ 50000 linhas`: latency_p50_ms cv=0.113; latency_p95_ms cv=0.122; latency_p99_ms cv=0.122; throughput_per_second cv=0.108
- `total_rows via parquet @ 50000 linhas`: latency_p50_ms cv=0.126; latency_p95_ms cv=0.162; latency_p99_ms cv=0.165; throughput_per_second cv=0.085
- `sum_amount via parquet @ 50000 linhas`: latency_p50_ms cv=0.052; latency_p95_ms cv=0.119; latency_p99_ms cv=0.125; throughput_per_second cv=0.056
- `group_by_category via parquet @ 50000 linhas`: latency_p95_ms cv=0.086; latency_p99_ms cv=0.090
- `filtered_sum via parquet @ 50000 linhas`: latency_p95_ms cv=0.095; latency_p99_ms cv=0.103
- `numeric_filtered_sum via parquet @ 50000 linhas`: latency_p50_ms cv=0.064
- `total_rows via row @ 100000 linhas`: latency_p50_ms cv=0.071; latency_p95_ms cv=0.114; latency_p99_ms cv=0.121; throughput_per_second cv=0.087
- `sum_amount via row @ 100000 linhas`: latency_p50_ms cv=0.212; latency_p95_ms cv=0.309; latency_p99_ms cv=0.317
- `group_by_category via row @ 100000 linhas`: latency_p50_ms cv=0.255; latency_p95_ms cv=0.376; latency_p99_ms cv=0.386; throughput_per_second cv=0.126
- `filtered_sum via row @ 100000 linhas`: latency_p50_ms cv=0.222; latency_p95_ms cv=0.213; latency_p99_ms cv=0.216
- `numeric_filtered_sum via row @ 100000 linhas`: latency_p50_ms cv=0.156; latency_p95_ms cv=0.150; latency_p99_ms cv=0.154; throughput_per_second cv=0.138
- `total_rows via columnar @ 100000 linhas`: latency_p50_ms cv=0.347; latency_p95_ms cv=0.365; latency_p99_ms cv=0.367; throughput_per_second cv=0.152
- `sum_amount via columnar @ 100000 linhas`: latency_p50_ms cv=0.182; latency_p95_ms cv=0.188; latency_p99_ms cv=0.188; throughput_per_second cv=0.206
- `filtered_sum via columnar @ 100000 linhas`: latency_p50_ms cv=0.190; latency_p95_ms cv=0.284; latency_p99_ms cv=0.294; throughput_per_second cv=0.186
- `numeric_filtered_sum via columnar @ 100000 linhas`: latency_p50_ms cv=0.177; latency_p95_ms cv=0.168; latency_p99_ms cv=0.167; throughput_per_second cv=0.158
- `sum_amount via parquet @ 100000 linhas`: latency_p50_ms cv=0.060; latency_p95_ms cv=0.057; latency_p99_ms cv=0.057
- `group_by_category via parquet @ 100000 linhas`: latency_p50_ms cv=0.081; latency_p95_ms cv=0.213; latency_p99_ms cv=0.223
- `filtered_sum via parquet @ 100000 linhas`: latency_p50_ms cv=0.069; latency_p95_ms cv=0.082; latency_p99_ms cv=0.084; throughput_per_second cv=0.092
- `total_rows via row @ 500000 linhas`: latency_p50_ms cv=0.226; latency_p95_ms cv=0.229; latency_p99_ms cv=0.230; throughput_per_second cv=0.167
- `sum_amount via row @ 500000 linhas`: latency_p50_ms cv=0.116; latency_p95_ms cv=0.128; latency_p99_ms cv=0.129; throughput_per_second cv=0.095
- `group_by_category via row @ 500000 linhas`: latency_p50_ms cv=0.117; latency_p95_ms cv=0.144; latency_p99_ms cv=0.149; throughput_per_second cv=0.122
- `filtered_sum via row @ 500000 linhas`: latency_p50_ms cv=0.090; latency_p95_ms cv=0.100; latency_p99_ms cv=0.102; throughput_per_second cv=0.088
- `numeric_filtered_sum via row @ 500000 linhas`: latency_p50_ms cv=0.101; latency_p95_ms cv=0.116; latency_p99_ms cv=0.117; throughput_per_second cv=0.131
- `total_rows via columnar @ 500000 linhas`: latency_p50_ms cv=0.309; latency_p95_ms cv=0.342; latency_p99_ms cv=0.344; throughput_per_second cv=0.261
- `sum_amount via columnar @ 500000 linhas`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.055
- `filtered_sum via columnar @ 500000 linhas`: latency_p50_ms cv=0.069; latency_p95_ms cv=0.092; latency_p99_ms cv=0.094; throughput_per_second cv=0.064
- `total_rows via parquet @ 500000 linhas`: latency_p50_ms cv=0.116; latency_p95_ms cv=0.113; latency_p99_ms cv=0.113; throughput_per_second cv=0.121
- `sum_amount via parquet @ 500000 linhas`: latency_p50_ms cv=0.092; latency_p95_ms cv=0.088; latency_p99_ms cv=0.088; throughput_per_second cv=0.090
- `group_by_category via parquet @ 500000 linhas`: latency_p50_ms cv=0.087; latency_p95_ms cv=0.117; latency_p99_ms cv=0.120; throughput_per_second cv=0.085
- `filtered_sum via parquet @ 500000 linhas`: latency_p50_ms cv=0.111; latency_p95_ms cv=0.096; latency_p99_ms cv=0.095; throughput_per_second cv=0.098
- `numeric_filtered_sum via parquet @ 500000 linhas`: latency_p50_ms cv=0.069; latency_p95_ms cv=0.082; latency_p99_ms cv=0.083; throughput_per_second cv=0.073
- `total_rows via row @ 1000000 linhas`: latency_p50_ms cv=0.128; latency_p95_ms cv=0.174; latency_p99_ms cv=0.177; throughput_per_second cv=0.125
- `sum_amount via row @ 1000000 linhas`: latency_p50_ms cv=0.078; latency_p95_ms cv=0.147; latency_p99_ms cv=0.153; throughput_per_second cv=0.101
- `group_by_category via row @ 1000000 linhas`: latency_p50_ms cv=0.173; latency_p95_ms cv=0.217; latency_p99_ms cv=0.221; throughput_per_second cv=0.111
- `filtered_sum via row @ 1000000 linhas`: latency_p50_ms cv=0.102; latency_p95_ms cv=0.181; latency_p99_ms cv=0.187; throughput_per_second cv=0.077
- `numeric_filtered_sum via row @ 1000000 linhas`: latency_p95_ms cv=0.079; latency_p99_ms cv=0.084
- `total_rows via columnar @ 1000000 linhas`: latency_p50_ms cv=0.119; latency_p95_ms cv=0.123; latency_p99_ms cv=0.123; throughput_per_second cv=0.112
- `sum_amount via columnar @ 1000000 linhas`: latency_p50_ms cv=0.074; latency_p95_ms cv=0.084; latency_p99_ms cv=0.084; throughput_per_second cv=0.073
- `filtered_sum via columnar @ 1000000 linhas`: latency_p50_ms cv=0.152; latency_p95_ms cv=0.152; latency_p99_ms cv=0.152; throughput_per_second cv=0.107
- `numeric_filtered_sum via columnar @ 1000000 linhas`: latency_p50_ms cv=0.084; latency_p95_ms cv=0.066; latency_p99_ms cv=0.065; throughput_per_second cv=0.060
- `numeric_filtered_sum via parquet @ 1000000 linhas`: latency_p95_ms cv=0.068; latency_p99_ms cv=0.072
- `total_rows via row @ 2000000 linhas`: latency_p50_ms cv=0.097; latency_p95_ms cv=0.147; latency_p99_ms cv=0.155; throughput_per_second cv=0.110
- `sum_amount via row @ 2000000 linhas`: latency_p50_ms cv=0.075; latency_p95_ms cv=0.079; latency_p99_ms cv=0.080; throughput_per_second cv=0.075
- `group_by_category via row @ 2000000 linhas`: latency_p95_ms cv=0.102; latency_p99_ms cv=0.108
- `filtered_sum via row @ 2000000 linhas`: latency_p50_ms cv=0.071
- `numeric_filtered_sum via row @ 2000000 linhas`: latency_p50_ms cv=0.061; latency_p95_ms cv=0.090; latency_p99_ms cv=0.093
- `total_rows via columnar @ 2000000 linhas`: latency_p50_ms cv=0.100; throughput_per_second cv=0.110
- `sum_amount via columnar @ 2000000 linhas`: latency_p50_ms cv=0.067; latency_p95_ms cv=0.075; latency_p99_ms cv=0.076; throughput_per_second cv=0.062
- `filtered_sum via columnar @ 2000000 linhas`: latency_p50_ms cv=0.095; latency_p95_ms cv=0.104; latency_p99_ms cv=0.105; throughput_per_second cv=0.079
- `numeric_filtered_sum via columnar @ 2000000 linhas`: latency_p50_ms cv=0.054; throughput_per_second cv=0.081

### Repetitions

Every repetition is retained:

- `total_rows via row @ 10000 linhas` latency_p50_ms: 0.7205, 0.6177, 1.669
- `total_rows via row @ 10000 linhas` latency_p95_ms: 1.099, 0.6965, 1.683
- `total_rows via row @ 10000 linhas` latency_p99_ms: 1.133, 0.7036, 1.684
- `total_rows via row @ 10000 linhas` throughput_per_second: 1,613, 1,715, 1,570
- `sum_amount via row @ 10000 linhas` latency_p50_ms: 0.7833, 0.7596, 1.209
- `sum_amount via row @ 10000 linhas` latency_p95_ms: 0.8882, 0.9093, 2.032
- `sum_amount via row @ 10000 linhas` latency_p99_ms: 0.8975, 0.9226, 2.105
- `sum_amount via row @ 10000 linhas` throughput_per_second: 1,295, 1,408, 1,375
- `group_by_category via row @ 10000 linhas` latency_p50_ms: 1.854, 1.958, 2.371
- `group_by_category via row @ 10000 linhas` latency_p95_ms: 1.965, 2.253, 2.929
- `group_by_category via row @ 10000 linhas` latency_p99_ms: 1.975, 2.279, 2.978
- `group_by_category via row @ 10000 linhas` throughput_per_second: 552.6, 554.8, 535.5
- `filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.9523, 1.058, 0.9469
- `filtered_sum via row @ 10000 linhas` latency_p95_ms: 1.034, 1.136, 2.189
- `filtered_sum via row @ 10000 linhas` latency_p99_ms: 1.041, 1.143, 2.299
- `filtered_sum via row @ 10000 linhas` throughput_per_second: 1,059, 1,097, 1,109
- `numeric_filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.8905, 0.8053, 0.8147
- `numeric_filtered_sum via row @ 10000 linhas` latency_p95_ms: 1.199, 1.598, 2.016
- `numeric_filtered_sum via row @ 10000 linhas` latency_p99_ms: 1.226, 1.668, 2.123
- `numeric_filtered_sum via row @ 10000 linhas` throughput_per_second: 1,129, 1,269, 1,279
- `total_rows via columnar @ 10000 linhas` latency_p50_ms: 1.195, 0.9915, 1.067
- `total_rows via columnar @ 10000 linhas` latency_p95_ms: 1.316, 1.086, 1.205
- `total_rows via columnar @ 10000 linhas` latency_p99_ms: 1.327, 1.094, 1.217
- `total_rows via columnar @ 10000 linhas` throughput_per_second: 894, 1,080, 1,084
- `sum_amount via columnar @ 10000 linhas` latency_p50_ms: 1.249, 1.154, 1.252
- `sum_amount via columnar @ 10000 linhas` latency_p95_ms: 1.286, 1.364, 1.315
- `sum_amount via columnar @ 10000 linhas` latency_p99_ms: 1.289, 1.383, 1.32
- `sum_amount via columnar @ 10000 linhas` throughput_per_second: 835.5, 899.1, 902.6
- `filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 2.548, 2.575, 2.511
- `filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 3.205, 2.853, 2.991
- `filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 3.263, 2.878, 3.034
- `filtered_sum via columnar @ 10000 linhas` throughput_per_second: 405.5, 403.6, 399.5
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 1.726, 1.643, 1.58
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 1.751, 1.845, 1.586
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 1.753, 1.863, 1.587
- `numeric_filtered_sum via columnar @ 10000 linhas` throughput_per_second: 589.9, 667, 648.6
- `total_rows via parquet @ 10000 linhas` latency_p50_ms: 25.41, 32.87, 29.52
- `total_rows via parquet @ 10000 linhas` latency_p95_ms: 29.9, 33.01, 34.29
- `total_rows via parquet @ 10000 linhas` latency_p99_ms: 30.3, 33.02, 34.72
- `total_rows via parquet @ 10000 linhas` throughput_per_second: 40.75, 31.61, 39.52
- `sum_amount via parquet @ 10000 linhas` latency_p50_ms: 28.03, 35.09, 29.31
- `sum_amount via parquet @ 10000 linhas` latency_p95_ms: 31.54, 37.97, 33.44
- `sum_amount via parquet @ 10000 linhas` latency_p99_ms: 31.85, 38.23, 33.8
- `sum_amount via parquet @ 10000 linhas` throughput_per_second: 36.22, 30.09, 35.97
- `group_by_category via parquet @ 10000 linhas` latency_p50_ms: 30.96, 41.92, 34.77
- `group_by_category via parquet @ 10000 linhas` latency_p95_ms: 36.37, 52.19, 36.94
- `group_by_category via parquet @ 10000 linhas` latency_p99_ms: 36.86, 53.1, 37.13
- `group_by_category via parquet @ 10000 linhas` throughput_per_second: 33.84, 24.1, 31.92
- `filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 28.34, 41.27, 38.23
- `filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 32.19, 50.55, 48.29
- `filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 32.54, 51.37, 49.18
- `filtered_sum via parquet @ 10000 linhas` throughput_per_second: 35.39, 28.28, 34.29
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 32.96, 39.22, 35.36
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 33.41, 39.69, 38.38
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 33.45, 39.73, 38.65
- `numeric_filtered_sum via parquet @ 10000 linhas` throughput_per_second: 30.98, 26.57, 37.09
- `total_rows via row @ 50000 linhas` latency_p50_ms: 2.753, 3.27, 3.054
- `total_rows via row @ 50000 linhas` latency_p95_ms: 2.918, 3.3, 3.522
- `total_rows via row @ 50000 linhas` latency_p99_ms: 2.933, 3.303, 3.564
- `total_rows via row @ 50000 linhas` throughput_per_second: 394.1, 384.8, 370.7
- `sum_amount via row @ 50000 linhas` latency_p50_ms: 3.412, 3.208, 6.005
- `sum_amount via row @ 50000 linhas` latency_p95_ms: 3.695, 4.729, 7.245
- `sum_amount via row @ 50000 linhas` latency_p99_ms: 3.72, 4.864, 7.356
- `sum_amount via row @ 50000 linhas` throughput_per_second: 308.4, 315.8, 297.4
- `group_by_category via row @ 50000 linhas` latency_p50_ms: 9.927, 8.059, 8.194
- `group_by_category via row @ 50000 linhas` latency_p95_ms: 10.77, 8.774, 8.549
- `group_by_category via row @ 50000 linhas` latency_p99_ms: 10.85, 8.837, 8.58
- `group_by_category via row @ 50000 linhas` throughput_per_second: 116.6, 124.9, 124.6
- `filtered_sum via row @ 50000 linhas` latency_p50_ms: 5.816, 3.887, 3.988
- `filtered_sum via row @ 50000 linhas` latency_p95_ms: 6.887, 6.182, 4.26
- `filtered_sum via row @ 50000 linhas` latency_p99_ms: 6.982, 6.386, 4.284
- `filtered_sum via row @ 50000 linhas` throughput_per_second: 184.1, 258.2, 256.4
- `numeric_filtered_sum via row @ 50000 linhas` latency_p50_ms: 3.549, 3.486, 3.568
- `numeric_filtered_sum via row @ 50000 linhas` latency_p95_ms: 5.762, 3.537, 3.842
- `numeric_filtered_sum via row @ 50000 linhas` latency_p99_ms: 5.959, 3.542, 3.867
- `numeric_filtered_sum via row @ 50000 linhas` throughput_per_second: 287.4, 287.3, 286.2
- `total_rows via columnar @ 50000 linhas` latency_p50_ms: 1.272, 1.313, 1.678
- `total_rows via columnar @ 50000 linhas` latency_p95_ms: 1.346, 1.383, 1.728
- `total_rows via columnar @ 50000 linhas` latency_p99_ms: 1.352, 1.389, 1.732
- `total_rows via columnar @ 50000 linhas` throughput_per_second: 799.3, 791.9, 623.1
- `sum_amount via columnar @ 50000 linhas` latency_p50_ms: 1.937, 1.942, 2.517
- `sum_amount via columnar @ 50000 linhas` latency_p95_ms: 1.99, 2.077, 2.531
- `sum_amount via columnar @ 50000 linhas` latency_p99_ms: 1.995, 2.089, 2.532
- `sum_amount via columnar @ 50000 linhas` throughput_per_second: 534.2, 515.2, 404
- `filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 7.34, 7.683, 9.537
- `filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 8.994, 10.56, 10.04
- `filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 9.141, 10.82, 10.09
- `filtered_sum via columnar @ 50000 linhas` throughput_per_second: 137.3, 136.6, 106.1
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 2.754, 2.824, 3.371
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 2.756, 2.826, 3.421
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 2.757, 2.826, 3.426
- `numeric_filtered_sum via columnar @ 50000 linhas` throughput_per_second: 363.7, 362.8, 299.1
- `total_rows via parquet @ 50000 linhas` latency_p50_ms: 199.3, 163.1, 159.6
- `total_rows via parquet @ 50000 linhas` latency_p95_ms: 216, 163.6, 166.4
- `total_rows via parquet @ 50000 linhas` latency_p99_ms: 217.5, 163.6, 167
- `total_rows via parquet @ 50000 linhas` throughput_per_second: 5.44, 6.293, 6.364
- `sum_amount via parquet @ 50000 linhas` latency_p50_ms: 192.7, 193.8, 176.3
- `sum_amount via parquet @ 50000 linhas` latency_p95_ms: 226.4, 221.5, 180.8
- `sum_amount via parquet @ 50000 linhas` latency_p99_ms: 229.4, 223.9, 181.2
- `sum_amount via parquet @ 50000 linhas` throughput_per_second: 5.207, 5.755, 5.745
- `group_by_category via parquet @ 50000 linhas` latency_p50_ms: 195.7, 183.4, 190.1
- `group_by_category via parquet @ 50000 linhas` latency_p95_ms: 217.8, 185.2, 193.1
- `group_by_category via parquet @ 50000 linhas` latency_p99_ms: 219.8, 185.4, 193.4
- `group_by_category via parquet @ 50000 linhas` throughput_per_second: 5.474, 5.536, 5.408
- `filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 165.1, 166.4, 177.1
- `filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 165.2, 199.8, 180.8
- `filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 165.2, 202.8, 181.1
- `filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.081, 6.032, 5.711
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 180.6, 193.4, 170.4
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 190.8, 199.9, 182.8
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 191.7, 200.5, 183.9
- `numeric_filtered_sum via parquet @ 50000 linhas` throughput_per_second: 5.557, 5.712, 5.944
- `total_rows via row @ 100000 linhas` latency_p50_ms: 5.996, 5.37, 5.264
- `total_rows via row @ 100000 linhas` latency_p95_ms: 6.837, 5.59, 6.888
- `total_rows via row @ 100000 linhas` latency_p99_ms: 6.912, 5.609, 7.033
- `total_rows via row @ 100000 linhas` throughput_per_second: 174.2, 205.6, 199.9
- `sum_amount via row @ 100000 linhas` latency_p50_ms: 6.507, 6.888, 9.47
- `sum_amount via row @ 100000 linhas` latency_p95_ms: 7.932, 7.007, 12.26
- `sum_amount via row @ 100000 linhas` latency_p99_ms: 8.058, 7.017, 12.51
- `sum_amount via row @ 100000 linhas` throughput_per_second: 160.2, 164.8, 163.9
- `group_by_category via row @ 100000 linhas` latency_p50_ms: 16.82, 16.83, 25.56
- `group_by_category via row @ 100000 linhas` latency_p95_ms: 16.9, 17.35, 31.38
- `group_by_category via row @ 100000 linhas` latency_p99_ms: 16.91, 17.4, 31.9
- `group_by_category via row @ 100000 linhas` throughput_per_second: 62.75, 62.45, 49.83
- `filtered_sum via row @ 100000 linhas` latency_p50_ms: 7.79, 11.35, 7.959
- `filtered_sum via row @ 100000 linhas` latency_p95_ms: 7.791, 12.03, 10.61
- `filtered_sum via row @ 100000 linhas` latency_p99_ms: 7.791, 12.09, 10.85
- `filtered_sum via row @ 100000 linhas` throughput_per_second: 129.6, 123.3, 128.8
- `numeric_filtered_sum via row @ 100000 linhas` latency_p50_ms: 6.951, 8.908, 6.799
- `numeric_filtered_sum via row @ 100000 linhas` latency_p95_ms: 6.978, 9.415, 8.71
- `numeric_filtered_sum via row @ 100000 linhas` latency_p99_ms: 6.981, 9.46, 8.88
- `numeric_filtered_sum via row @ 100000 linhas` throughput_per_second: 146.1, 114.6, 148.1
- `total_rows via columnar @ 100000 linhas` latency_p50_ms: 2.462, 2.005, 3.852
- `total_rows via columnar @ 100000 linhas` latency_p95_ms: 2.539, 2.184, 4.221
- `total_rows via columnar @ 100000 linhas` latency_p99_ms: 2.545, 2.199, 4.253
- `total_rows via columnar @ 100000 linhas` throughput_per_second: 412.1, 518.8, 394.3
- `sum_amount via columnar @ 100000 linhas` latency_p50_ms: 4.232, 3.577, 2.931
- `sum_amount via columnar @ 100000 linhas` latency_p95_ms: 4.287, 3.6, 2.935
- `sum_amount via columnar @ 100000 linhas` latency_p99_ms: 4.292, 3.602, 2.935
- `sum_amount via columnar @ 100000 linhas` throughput_per_second: 236.8, 284.2, 356.7
- `filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 20.16, 18.73, 13.8
- `filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 21.13, 24.98, 13.81
- `filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 21.21, 25.53, 13.81
- `filtered_sum via columnar @ 100000 linhas` throughput_per_second: 50.47, 59.95, 73.08
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 5.91, 4.363, 4.455
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 5.978, 4.516, 4.527
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 5.984, 4.529, 4.534
- `numeric_filtered_sum via columnar @ 100000 linhas` throughput_per_second: 172.5, 232.3, 228.2
- `total_rows via parquet @ 100000 linhas` latency_p50_ms: 319.7, 332.5, 322.5
- `total_rows via parquet @ 100000 linhas` latency_p95_ms: 321.5, 335.6, 326.1
- `total_rows via parquet @ 100000 linhas` latency_p99_ms: 321.6, 335.8, 326.4
- `total_rows via parquet @ 100000 linhas` throughput_per_second: 3.178, 3.098, 3.144
- `sum_amount via parquet @ 100000 linhas` latency_p50_ms: 349.1, 385.2, 346.4
- `sum_amount via parquet @ 100000 linhas` latency_p95_ms: 365.4, 394.4, 353.1
- `sum_amount via parquet @ 100000 linhas` latency_p99_ms: 366.8, 395.2, 353.7
- `sum_amount via parquet @ 100000 linhas` throughput_per_second: 2.892, 2.75, 2.912
- `group_by_category via parquet @ 100000 linhas` latency_p50_ms: 385.7, 400, 449.2
- `group_by_category via parquet @ 100000 linhas` latency_p95_ms: 392.5, 411, 569.8
- `group_by_category via parquet @ 100000 linhas` latency_p99_ms: 393.1, 412, 580.6
- `group_by_category via parquet @ 100000 linhas` throughput_per_second: 2.671, 2.518, 2.549
- `filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 406.5, 365.1, 358.7
- `filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 448.8, 383.8, 400.5
- `filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 452.5, 385.4, 404.3
- `filtered_sum via parquet @ 100000 linhas` throughput_per_second: 2.563, 2.947, 3.067
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 341.6, 354.7, 359.2
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 353.6, 358.8, 384.5
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 354.7, 359.2, 386.8
- `numeric_filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.013, 2.919, 2.836
- `total_rows via row @ 500000 linhas` latency_p50_ms: 24.18, 29.81, 18.85
- `total_rows via row @ 500000 linhas` latency_p95_ms: 27.03, 30.28, 18.99
- `total_rows via row @ 500000 linhas` latency_p99_ms: 27.28, 30.32, 19
- `total_rows via row @ 500000 linhas` throughput_per_second: 42.46, 39.14, 53.49
- `sum_amount via row @ 500000 linhas` latency_p50_ms: 28.32, 30.36, 24.1
- `sum_amount via row @ 500000 linhas` latency_p95_ms: 30.13, 31.31, 24.47
- `sum_amount via row @ 500000 linhas` latency_p99_ms: 30.29, 31.4, 24.5
- `sum_amount via row @ 500000 linhas` throughput_per_second: 35.81, 35.95, 42.09
- `group_by_category via row @ 500000 linhas` latency_p50_ms: 52.18, 51.34, 41.95
- `group_by_category via row @ 500000 linhas` latency_p95_ms: 68.22, 54.65, 52.77
- `group_by_category via row @ 500000 linhas` latency_p99_ms: 69.64, 54.94, 53.74
- `group_by_category via row @ 500000 linhas` throughput_per_second: 20.07, 20.47, 24.86
- `filtered_sum via row @ 500000 linhas` latency_p50_ms: 29.67, 32.35, 26.99
- `filtered_sum via row @ 500000 linhas` latency_p95_ms: 32.9, 33.22, 27.63
- `filtered_sum via row @ 500000 linhas` latency_p99_ms: 33.19, 33.29, 27.68
- `filtered_sum via row @ 500000 linhas` throughput_per_second: 34.11, 33.9, 39.46
- `numeric_filtered_sum via row @ 500000 linhas` latency_p50_ms: 29.22, 31.22, 25.53
- `numeric_filtered_sum via row @ 500000 linhas` latency_p95_ms: 29.96, 33.01, 26.15
- `numeric_filtered_sum via row @ 500000 linhas` latency_p99_ms: 30.03, 33.17, 26.21
- `numeric_filtered_sum via row @ 500000 linhas` throughput_per_second: 35.98, 32.27, 41.79
- `total_rows via columnar @ 500000 linhas` latency_p50_ms: 5.076, 5.079, 8.382
- `total_rows via columnar @ 500000 linhas` latency_p95_ms: 5.41, 5.232, 9.239
- `total_rows via columnar @ 500000 linhas` latency_p99_ms: 5.44, 5.245, 9.316
- `total_rows via columnar @ 500000 linhas` throughput_per_second: 207.1, 197.3, 123.1
- `sum_amount via columnar @ 500000 linhas` latency_p50_ms: 10.75, 11.65, 11.17
- `sum_amount via columnar @ 500000 linhas` latency_p95_ms: 10.84, 12.05, 11.28
- `sum_amount via columnar @ 500000 linhas` latency_p99_ms: 10.85, 12.08, 11.29
- `sum_amount via columnar @ 500000 linhas` throughput_per_second: 93.41, 87.74, 90.31
- `filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 76.43, 75.81, 67.44
- `filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 77.5, 81.81, 68.21
- `filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 77.59, 82.34, 68.27
- `filtered_sum via columnar @ 500000 linhas` throughput_per_second: 13.94, 13.27, 15.05
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 18.12, 17.64, 17.57
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 19.09, 18.06, 17.93
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 19.18, 18.1, 17.96
- `numeric_filtered_sum via columnar @ 500000 linhas` throughput_per_second: 56.21, 58.08, 57.22
- `total_rows via parquet @ 500000 linhas` latency_p50_ms: 1,701, 1,957, 1,557
- `total_rows via parquet @ 500000 linhas` latency_p95_ms: 1,778, 1,995, 1,592
- `total_rows via parquet @ 500000 linhas` latency_p99_ms: 1,785, 1,999, 1,595
- `total_rows via parquet @ 500000 linhas` throughput_per_second: 0.5958, 0.5146, 0.6572
- `sum_amount via parquet @ 500000 linhas` latency_p50_ms: 2,079, 2,038, 1,749
- `sum_amount via parquet @ 500000 linhas` latency_p95_ms: 2,119, 2,090, 1,799
- `sum_amount via parquet @ 500000 linhas` latency_p99_ms: 2,123, 2,095, 1,803
- `sum_amount via parquet @ 500000 linhas` throughput_per_second: 0.5072, 0.5133, 0.5942
- `group_by_category via parquet @ 500000 linhas` latency_p50_ms: 2,122, 2,156, 1,834
- `group_by_category via parquet @ 500000 linhas` latency_p95_ms: 2,237, 2,289, 1,835
- `group_by_category via parquet @ 500000 linhas` latency_p99_ms: 2,247, 2,301, 1,835
- `group_by_category via parquet @ 500000 linhas` throughput_per_second: 0.4761, 0.5047, 0.562
- `filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,822, 2,076, 1,666
- `filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,949, 2,090, 1,723
- `filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,960, 2,091, 1,728
- `filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.5533, 0.5089, 0.618
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,951, 1,744, 1,727
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 2,066, 1,845, 1,767
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 2,076, 1,854, 1,770
- `numeric_filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.5286, 0.5917, 0.6088
- `total_rows via row @ 1000000 linhas` latency_p50_ms: 36.74, 29.57, 29.77
- `total_rows via row @ 1000000 linhas` latency_p95_ms: 41.95, 30.48, 32.7
- `total_rows via row @ 1000000 linhas` latency_p99_ms: 42.41, 30.56, 32.96
- `total_rows via row @ 1000000 linhas` throughput_per_second: 27.46, 34.34, 34.51
- `sum_amount via row @ 1000000 linhas` latency_p50_ms: 42.07, 36.45, 41.57
- `sum_amount via row @ 1000000 linhas` latency_p95_ms: 47.53, 36.93, 48.86
- `sum_amount via row @ 1000000 linhas` latency_p99_ms: 48.01, 36.97, 49.51
- `sum_amount via row @ 1000000 linhas` throughput_per_second: 24.08, 29.46, 26.35
- `group_by_category via row @ 1000000 linhas` latency_p50_ms: 76.55, 72.18, 98.83
- `group_by_category via row @ 1000000 linhas` latency_p95_ms: 76.79, 72.52, 106.5
- `group_by_category via row @ 1000000 linhas` latency_p99_ms: 76.81, 72.55, 107.2
- `group_by_category via row @ 1000000 linhas` throughput_per_second: 13.51, 14.06, 11.33
- `filtered_sum via row @ 1000000 linhas` latency_p50_ms: 50.08, 44.29, 54.41
- `filtered_sum via row @ 1000000 linhas` latency_p95_ms: 59.43, 44.66, 64.13
- `filtered_sum via row @ 1000000 linhas` latency_p99_ms: 60.27, 44.7, 64.99
- `filtered_sum via row @ 1000000 linhas` throughput_per_second: 21.66, 22.94, 19.66
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p50_ms: 42.21, 40.47, 42.13
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p95_ms: 48.09, 41.01, 44.77
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p99_ms: 48.62, 41.05, 45.01
- `numeric_filtered_sum via row @ 1000000 linhas` throughput_per_second: 24.37, 24.93, 24.58
- `total_rows via columnar @ 1000000 linhas` latency_p50_ms: 11.77, 11.36, 9.362
- `total_rows via columnar @ 1000000 linhas` latency_p95_ms: 11.82, 11.85, 9.491
- `total_rows via columnar @ 1000000 linhas` latency_p99_ms: 11.82, 11.9, 9.503
- `total_rows via columnar @ 1000000 linhas` throughput_per_second: 91.92, 88.05, 108.3
- `sum_amount via columnar @ 1000000 linhas` latency_p50_ms: 25.02, 25.12, 22
- `sum_amount via columnar @ 1000000 linhas` latency_p95_ms: 25.81, 25.25, 22.04
- `sum_amount via columnar @ 1000000 linhas` latency_p99_ms: 25.88, 25.26, 22.04
- `sum_amount via columnar @ 1000000 linhas` throughput_per_second: 40.94, 40.31, 45.94
- `filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 131.6, 151.6, 178
- `filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 136.9, 160.5, 185.9
- `filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 137.4, 161.3, 186.6
- `filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 7.785, 6.79, 6.33
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 33.83, 39.41, 34.61
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 35.45, 39.69, 35.46
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 35.6, 39.71, 35.54
- `numeric_filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 29.64, 26.42, 28.96
- `total_rows via parquet @ 1000000 linhas` latency_p50_ms: 3,290, 3,316, 3,467
- `total_rows via parquet @ 1000000 linhas` latency_p95_ms: 3,414, 3,369, 3,514
- `total_rows via parquet @ 1000000 linhas` latency_p99_ms: 3,425, 3,374, 3,518
- `total_rows via parquet @ 1000000 linhas` throughput_per_second: 0.3145, 0.306, 0.3
- `sum_amount via parquet @ 1000000 linhas` latency_p50_ms: 3,555, 3,611, 3,689
- `sum_amount via parquet @ 1000000 linhas` latency_p95_ms: 3,628, 3,650, 3,705
- `sum_amount via parquet @ 1000000 linhas` latency_p99_ms: 3,635, 3,654, 3,707
- `sum_amount via parquet @ 1000000 linhas` throughput_per_second: 0.2867, 0.2802, 0.2767
- `group_by_category via parquet @ 1000000 linhas` latency_p50_ms: 3,700, 3,833, 3,735
- `group_by_category via parquet @ 1000000 linhas` latency_p95_ms: 3,713, 3,979, 3,879
- `group_by_category via parquet @ 1000000 linhas` latency_p99_ms: 3,714, 3,992, 3,891
- `group_by_category via parquet @ 1000000 linhas` throughput_per_second: 0.2757, 0.2659, 0.2679
- `filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,634, 3,507, 3,448
- `filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,777, 3,569, 3,719
- `filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,789, 3,574, 3,743
- `filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.2882, 0.2868, 0.297
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,670, 3,773, 3,574
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,688, 4,109, 3,633
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,690, 4,139, 3,638
- `numeric_filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.2848, 0.269, 0.2905
- `total_rows via row @ 2000000 linhas` latency_p50_ms: 63.72, 52.48, 57.87
- `total_rows via row @ 2000000 linhas` latency_p95_ms: 63.94, 55.85, 74.81
- `total_rows via row @ 2000000 linhas` latency_p99_ms: 63.96, 56.15, 76.32
- `total_rows via row @ 2000000 linhas` throughput_per_second: 15.95, 19.16, 19.66
- `sum_amount via row @ 2000000 linhas` latency_p50_ms: 70.67, 64.06, 74.33
- `sum_amount via row @ 2000000 linhas` latency_p95_ms: 74.62, 66.98, 78.41
- `sum_amount via row @ 2000000 linhas` latency_p99_ms: 74.98, 67.24, 78.77
- `sum_amount via row @ 2000000 linhas` throughput_per_second: 14.39, 16.28, 14.28
- `group_by_category via row @ 2000000 linhas` latency_p50_ms: 158.2, 147.8, 149.3
- `group_by_category via row @ 2000000 linhas` latency_p95_ms: 181.4, 149.1, 158.1
- `group_by_category via row @ 2000000 linhas` latency_p99_ms: 183.5, 149.2, 158.9
- `group_by_category via row @ 2000000 linhas` throughput_per_second: 6.692, 6.873, 6.893
- `filtered_sum via row @ 2000000 linhas` latency_p50_ms: 78.43, 89.44, 80.19
- `filtered_sum via row @ 2000000 linhas` latency_p95_ms: 86.94, 90.72, 88.59
- `filtered_sum via row @ 2000000 linhas` latency_p99_ms: 87.7, 90.84, 89.34
- `filtered_sum via row @ 2000000 linhas` throughput_per_second: 12.77, 12.13, 12.64
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p50_ms: 74.74, 83.23, 75.41
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p95_ms: 77.95, 89.37, 75.79
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p99_ms: 78.23, 89.91, 75.82
- `numeric_filtered_sum via row @ 2000000 linhas` throughput_per_second: 13.48, 13.99, 13.44
- `total_rows via columnar @ 2000000 linhas` latency_p50_ms: 24.45, 20.07, 23.24
- `total_rows via columnar @ 2000000 linhas` latency_p95_ms: 25.06, 23.21, 23.66
- `total_rows via columnar @ 2000000 linhas` latency_p99_ms: 25.11, 23.49, 23.7
- `total_rows via columnar @ 2000000 linhas` throughput_per_second: 42.3, 51.46, 43.26
- `sum_amount via columnar @ 2000000 linhas` latency_p50_ms: 49.06, 44.84, 51.18
- `sum_amount via columnar @ 2000000 linhas` latency_p95_ms: 49.84, 45.32, 52.68
- `sum_amount via columnar @ 2000000 linhas` latency_p99_ms: 49.91, 45.36, 52.82
- `sum_amount via columnar @ 2000000 linhas` throughput_per_second: 20.83, 22.45, 19.87
- `filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 292.4, 279.9, 334.6
- `filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 299.5, 294.6, 353.7
- `filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 300.1, 295.9, 355.4
- `filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 3.473, 3.578, 3.074
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 75.78, 69.38, 76.62
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 76.5, 80.76, 77.34
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 76.56, 81.77, 77.41
- `numeric_filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 13.21, 15.12, 13.15
- `total_rows via parquet @ 2000000 linhas` latency_p50_ms: 6,813, 6,833, 6,825
- `total_rows via parquet @ 2000000 linhas` latency_p95_ms: 6,980, 7,137, 7,143
- `total_rows via parquet @ 2000000 linhas` latency_p99_ms: 6,995, 7,164, 7,171
- `total_rows via parquet @ 2000000 linhas` throughput_per_second: 0.1489, 0.1466, 0.1477
- `sum_amount via parquet @ 2000000 linhas` latency_p50_ms: 7,410, 7,593, 7,765
- `sum_amount via parquet @ 2000000 linhas` latency_p95_ms: 7,869, 7,633, 8,229
- `sum_amount via parquet @ 2000000 linhas` latency_p99_ms: 7,909, 7,636, 8,270
- `sum_amount via parquet @ 2000000 linhas` throughput_per_second: 0.1359, 0.1337, 0.1315
- `group_by_category via parquet @ 2000000 linhas` latency_p50_ms: 8,154, 7,980, 7,997
- `group_by_category via parquet @ 2000000 linhas` latency_p95_ms: 8,273, 8,070, 8,409
- `group_by_category via parquet @ 2000000 linhas` latency_p99_ms: 8,284, 8,078, 8,445
- `group_by_category via parquet @ 2000000 linhas` throughput_per_second: 0.1266, 0.1262, 0.1253
- `filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 7,759, 7,741, 8,097
- `filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 7,990, 7,753, 8,126
- `filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 8,011, 7,755, 8,129
- `filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1314, 0.1335, 0.1245
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 7,786, 7,642, 8,066
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 7,793, 7,780, 8,090
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 7,794, 7,792, 8,092
- `numeric_filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1336, 0.1359, 0.1313

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T114055Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 407d5a862a5217ea9d22fcccccca489ea753117a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

