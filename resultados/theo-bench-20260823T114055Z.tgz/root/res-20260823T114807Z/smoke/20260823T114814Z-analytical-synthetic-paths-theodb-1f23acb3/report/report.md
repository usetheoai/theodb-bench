# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T114814Z-analytical-synthetic-paths-theodb-1f23acb3`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 97.66 | _not measured_ | 10.49 | 12.21 | 12.36 | **no** |
| sum_amount via row | 80.19 | _not measured_ | 12.94 | 13.22 | 13.24 | yes |
| group_by_category via row | 37.25 | _not measured_ | 27.54 | 28.83 | 28.95 | **no** |
| filtered_sum via row | 58.22 | _not measured_ | 17.34 | 18.18 | 18.26 | **no** |
| numeric_filtered_sum via row | 58.51 | _not measured_ | 17.33 | 19.36 | 19.54 | **no** |
| total_rows via columnar | 368.4 | _not measured_ | 2.942 | 3.02 | 3.027 | **no** |
| sum_amount via columnar | 182.6 | _not measured_ | 5.593 | 5.67 | 5.677 | **no** |
| group_by_category via columnar | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| filtered_sum via columnar | 34.7 | _not measured_ | 30.23 | 34.55 | 35 | **no** |
| numeric_filtered_sum via columnar | 118.2 | _not measured_ | 8.512 | 8.611 | 8.619 | **no** |
| total_rows via parquet | 1.548 | _not measured_ | 653.7 | 682.4 | 685 | yes |
| sum_amount via parquet | 1.404 | _not measured_ | 725.9 | 740.1 | 741.3 | **no** |
| group_by_category via parquet | 1.35 | _not measured_ | 750.5 | 752.2 | 753.3 | **no** |
| filtered_sum via parquet | 1.449 | _not measured_ | 696.1 | 707.7 | 710.1 | yes |
| numeric_filtered_sum via parquet | 1.385 | _not measured_ | 739.9 | 794.7 | 798.6 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.101; latency_p99_ms cv=0.104
- `group_by_category via row`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.054
- `filtered_sum via row`: latency_p50_ms cv=0.073; latency_p95_ms cv=0.051; throughput_per_second cv=0.055
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.091; latency_p95_ms cv=0.224; latency_p99_ms cv=0.234; throughput_per_second cv=0.095
- `total_rows via columnar`: latency_p50_ms cv=0.191; latency_p95_ms cv=0.181; latency_p99_ms cv=0.180; throughput_per_second cv=0.169
- `sum_amount via columnar`: latency_p50_ms cv=0.090; latency_p95_ms cv=0.074; latency_p99_ms cv=0.073; throughput_per_second cv=0.102
- `filtered_sum via columnar`: latency_p50_ms cv=0.080; latency_p95_ms cv=0.067; latency_p99_ms cv=0.066
- `numeric_filtered_sum via columnar`: latency_p50_ms cv=0.090; latency_p95_ms cv=0.080; latency_p99_ms cv=0.080; throughput_per_second cv=0.087
- `sum_amount via parquet`: latency_p50_ms cv=0.058; latency_p95_ms cv=0.076; latency_p99_ms cv=0.077
- `group_by_category via parquet`: latency_p95_ms cv=0.055; latency_p99_ms cv=0.057
- `numeric_filtered_sum via parquet`: latency_p99_ms cv=0.050

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.98, 11.16, 10.49
- `total_rows via row` latency_p95_ms: 11.28, 13.76, 12.21
- `total_rows via row` latency_p99_ms: 11.39, 13.99, 12.36
- `total_rows via row` throughput_per_second: 102, 93.5, 97.66
- `sum_amount via row` latency_p50_ms: 12.94, 12.69, 13.43
- `sum_amount via row` latency_p95_ms: 13.22, 13.01, 13.82
- `sum_amount via row` latency_p99_ms: 13.24, 13.04, 13.85
- `sum_amount via row` throughput_per_second: 77.47, 80.19, 81.91
- `group_by_category via row` latency_p50_ms: 27.54, 29.47, 27.05
- `group_by_category via row` latency_p95_ms: 28.83, 30.55, 27.45
- `group_by_category via row` latency_p99_ms: 28.95, 30.64, 27.48
- `group_by_category via row` throughput_per_second: 37.36, 34.38, 37.25
- `filtered_sum via row` latency_p50_ms: 17.24, 19.57, 17.34
- `filtered_sum via row` latency_p95_ms: 18.18, 19.83, 18.15
- `filtered_sum via row` latency_p99_ms: 18.26, 19.85, 18.22
- `filtered_sum via row` throughput_per_second: 58.22, 52.95, 58.38
- `numeric_filtered_sum via row` latency_p50_ms: 16.66, 17.33, 19.76
- `numeric_filtered_sum via row` latency_p95_ms: 17.52, 19.36, 26.48
- `numeric_filtered_sum via row` latency_p99_ms: 17.6, 19.54, 27.08
- `numeric_filtered_sum via row` throughput_per_second: 61.06, 58.51, 50.67
- `total_rows via columnar` latency_p50_ms: 3.681, 2.529, 2.942
- `total_rows via columnar` latency_p95_ms: 3.797, 2.679, 3.02
- `total_rows via columnar` latency_p99_ms: 3.807, 2.692, 3.027
- `total_rows via columnar` throughput_per_second: 283.7, 397.6, 368.4
- `sum_amount via columnar` latency_p50_ms: 5.876, 4.921, 5.593
- `sum_amount via columnar` latency_p95_ms: 5.971, 5.151, 5.67
- `sum_amount via columnar` latency_p99_ms: 5.98, 5.171, 5.677
- `sum_amount via columnar` throughput_per_second: 170.7, 208.2, 182.6
- `filtered_sum via columnar` latency_p50_ms: 34.13, 29.46, 30.23
- `filtered_sum via columnar` latency_p95_ms: 37.95, 34.55, 33.41
- `filtered_sum via columnar` latency_p99_ms: 38.29, 35, 33.69
- `filtered_sum via columnar` throughput_per_second: 33.61, 34.7, 35.17
- `numeric_filtered_sum via columnar` latency_p50_ms: 9.402, 7.867, 8.512
- `numeric_filtered_sum via columnar` latency_p95_ms: 9.504, 8.117, 8.611
- `numeric_filtered_sum via columnar` latency_p99_ms: 9.513, 8.14, 8.619
- `numeric_filtered_sum via columnar` throughput_per_second: 108.2, 128.8, 118.2
- `total_rows via parquet` latency_p50_ms: 644.6, 668, 653.7
- `total_rows via parquet` latency_p95_ms: 681.5, 699.5, 682.4
- `total_rows via parquet` latency_p99_ms: 684.8, 702.3, 685
- `total_rows via parquet` throughput_per_second: 1.582, 1.5, 1.548
- `sum_amount via parquet` latency_p50_ms: 706.9, 789.5, 725.9
- `sum_amount via parquet` latency_p95_ms: 713.8, 823.9, 740.1
- `sum_amount via parquet` latency_p99_ms: 714.4, 827, 741.3
- `sum_amount via parquet` throughput_per_second: 1.427, 1.355, 1.404
- `group_by_category via parquet` latency_p50_ms: 735.9, 776.8, 750.5
- `group_by_category via parquet` latency_p95_ms: 751.8, 825.7, 752.2
- `group_by_category via parquet` latency_p99_ms: 753.3, 830, 752.3
- `group_by_category via parquet` throughput_per_second: 1.411, 1.295, 1.35
- `filtered_sum via parquet` latency_p50_ms: 696.1, 748.1, 681.4
- `filtered_sum via parquet` latency_p95_ms: 703.7, 751.4, 707.7
- `filtered_sum via parquet` latency_p99_ms: 704.4, 751.7, 710.1
- `filtered_sum via parquet` throughput_per_second: 1.449, 1.381, 1.471
- `numeric_filtered_sum via parquet` latency_p50_ms: 739.9, 731.3, 751.7
- `numeric_filtered_sum via parquet` latency_p95_ms: 794.7, 731.4, 794.8
- `numeric_filtered_sum via parquet` latency_p99_ms: 799.6, 731.4, 798.6
- `numeric_filtered_sum via parquet` throughput_per_second: 1.385, 1.372, 1.417

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T114055Z
- CPU: Intel(R) Xeon(R) Platinum 8168 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 407d5a862a5217ea9d22fcccccca489ea753117a (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

