# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T092611Z-analytical-synthetic-paths-theodb-96814204`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 125.9 | _not measured_ | 8.061 | 8.358 | 8.376 | yes |
| sum_amount via row | 98.5 | _not measured_ | 10.17 | 10.32 | 10.33 | yes |
| group_by_category via row | 49.96 | _not measured_ | 20.39 | 20.67 | 20.7 | yes |
| filtered_sum via row | 78.03 | _not measured_ | 13.09 | 13.25 | 13.26 | **no** |
| numeric_filtered_sum via row | 87.41 | _not measured_ | 11.81 | 11.97 | 11.98 | yes |
| total_rows via columnar | 572.1 | _not measured_ | 1.768 | 1.952 | 1.969 | yes |
| sum_amount via columnar | 278 | _not measured_ | 3.629 | 3.738 | 3.755 | yes |
| group_by_category via columnar | 48.24 | _not measured_ | 20.84 | 20.98 | 20.99 | **no** |
| filtered_sum via columnar | 48.57 | _not measured_ | 20.76 | 20.86 | 20.87 | **no** |
| numeric_filtered_sum via columnar | 174.6 | _not measured_ | 5.754 | 5.79 | 5.79 | yes |
| total_rows via parquet | 2.031 | _not measured_ | 496.7 | 502.6 | 502.7 | yes |
| sum_amount via parquet | 1.811 | _not measured_ | 555.8 | 556.8 | 557.1 | yes |
| group_by_category via parquet | 1.691 | _not measured_ | 593.8 | 597.9 | 598.6 | yes |
| filtered_sum via parquet | 1.888 | _not measured_ | 543.8 | 545 | 545.1 | yes |
| numeric_filtered_sum via parquet | 1.858 | _not measured_ | 541.4 | 545.4 | 545.7 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via row`: latency_p50_ms cv=0.241; latency_p95_ms cv=0.246; latency_p99_ms cv=0.246
- `group_by_category via columnar`: latency_p50_ms cv=0.082; latency_p95_ms cv=0.093; latency_p99_ms cv=0.094; throughput_per_second cv=0.086
- `filtered_sum via columnar`: latency_p50_ms cv=0.078; latency_p95_ms cv=0.081; latency_p99_ms cv=0.081; throughput_per_second cv=0.076

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 7.861, 8.061, 8.16
- `total_rows via row` latency_p95_ms: 8.091, 8.479, 8.358
- `total_rows via row` latency_p99_ms: 8.111, 8.516, 8.376
- `total_rows via row` throughput_per_second: 131.1, 125.9, 125.6
- `sum_amount via row` latency_p50_ms: 10.16, 10.56, 10.17
- `sum_amount via row` latency_p95_ms: 10.32, 10.83, 10.17
- `sum_amount via row` latency_p99_ms: 10.33, 10.86, 10.18
- `sum_amount via row` throughput_per_second: 100.4, 96.49, 98.5
- `group_by_category via row` latency_p50_ms: 19.94, 20.39, 21.1
- `group_by_category via row` latency_p95_ms: 20.45, 20.67, 21.32
- `group_by_category via row` latency_p99_ms: 20.5, 20.7, 21.34
- `group_by_category via row` throughput_per_second: 51.03, 49.75, 49.96
- `filtered_sum via row` latency_p50_ms: 19.44, 13.09, 13.08
- `filtered_sum via row` latency_p95_ms: 19.73, 13.14, 13.25
- `filtered_sum via row` latency_p99_ms: 19.76, 13.14, 13.26
- `filtered_sum via row` throughput_per_second: 78.27, 78.03, 77.99
- `numeric_filtered_sum via row` latency_p50_ms: 11.81, 11.84, 11.52
- `numeric_filtered_sum via row` latency_p95_ms: 11.98, 11.97, 11.58
- `numeric_filtered_sum via row` latency_p99_ms: 11.99, 11.98, 11.59
- `numeric_filtered_sum via row` throughput_per_second: 86.33, 87.41, 88.09
- `total_rows via columnar` latency_p50_ms: 1.814, 1.713, 1.768
- `total_rows via columnar` latency_p95_ms: 1.971, 1.875, 1.952
- `total_rows via columnar` latency_p99_ms: 1.985, 1.889, 1.969
- `total_rows via columnar` throughput_per_second: 565.7, 587.4, 572.1
- `sum_amount via columnar` latency_p50_ms: 3.65, 3.538, 3.629
- `sum_amount via columnar` latency_p95_ms: 3.754, 3.738, 3.699
- `sum_amount via columnar` latency_p99_ms: 3.763, 3.755, 3.705
- `sum_amount via columnar` throughput_per_second: 278, 284.7, 277.9
- `group_by_category via columnar` latency_p50_ms: 18.03, 20.84, 20.84
- `group_by_category via columnar` latency_p95_ms: 18.08, 20.98, 21.6
- `group_by_category via columnar` latency_p99_ms: 18.08, 20.99, 21.67
- `group_by_category via columnar` throughput_per_second: 55.71, 48.14, 48.24
- `filtered_sum via columnar` latency_p50_ms: 18.21, 21.06, 20.76
- `filtered_sum via columnar` latency_p95_ms: 18.29, 21.33, 20.86
- `filtered_sum via columnar` latency_p99_ms: 18.3, 21.35, 20.87
- `filtered_sum via columnar` throughput_per_second: 55.1, 48.22, 48.57
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.788, 5.697, 5.754
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.79, 5.987, 5.777
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.79, 6.012, 5.779
- `numeric_filtered_sum via columnar` throughput_per_second: 173.7, 175.5, 174.6
- `total_rows via parquet` latency_p50_ms: 496.7, 494.6, 501
- `total_rows via parquet` latency_p95_ms: 497.9, 503, 502.6
- `total_rows via parquet` latency_p99_ms: 498, 503.8, 502.7
- `total_rows via parquet` throughput_per_second: 2.041, 2.031, 2.027
- `sum_amount via parquet` latency_p50_ms: 555.8, 553.4, 563.8
- `sum_amount via parquet` latency_p95_ms: 555.8, 556.8, 564.7
- `sum_amount via parquet` latency_p99_ms: 555.8, 557.1, 564.8
- `sum_amount via parquet` throughput_per_second: 1.825, 1.811, 1.79
- `group_by_category via parquet` latency_p50_ms: 600.2, 590.3, 593.8
- `group_by_category via parquet` latency_p95_ms: 600.7, 597.9, 596.4
- `group_by_category via parquet` latency_p99_ms: 600.7, 598.6, 596.7
- `group_by_category via parquet` throughput_per_second: 1.676, 1.718, 1.691
- `filtered_sum via parquet` latency_p50_ms: 541.9, 543.8, 551.1
- `filtered_sum via parquet` latency_p95_ms: 544.6, 545, 553.7
- `filtered_sum via parquet` latency_p99_ms: 544.9, 545.1, 553.9
- `filtered_sum via parquet` throughput_per_second: 1.899, 1.888, 1.84
- `numeric_filtered_sum via parquet` latency_p50_ms: 553.2, 541.4, 538.3
- `numeric_filtered_sum via parquet` latency_p95_ms: 554.3, 545.4, 540.6
- `numeric_filtered_sum via parquet` latency_p99_ms: 554.4, 545.7, 540.8
- `numeric_filtered_sum via parquet` throughput_per_second: 1.814, 1.872, 1.858

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T092015Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4242f7e458c423578fa2e435f45a2779bb2dd507 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

