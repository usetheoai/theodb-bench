# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T092705Z-vector-sift-hnsw-theodb-a67f2ec3`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,687 | 0.8708 | 0.5386 | 0.6585 | 0.7782 | yes |
| hnsw m=16 ef_search=64 | 1,293 | 0.961 | 0.7001 | 0.8432 | 0.9915 | **no** |
| hnsw m=16 ef_search=256 | 608.1 | 0.9948 | 1.635 | 1.957 | 2.154 | yes |
| hnsw m=16 ef_search=512 | 369.4 | 0.9962 | 2.705 | 3.322 | 3.508 | yes |
| hnsw m=16 ef_search=1000 | 227.7 | 0.9954 | 4.434 | 5.419 | 5.755 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.082

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.836, 6.836, 6.836
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5357, 0.5473, 0.5386
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6406, 0.6653, 0.6585
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7302, 0.7868, 0.7782
- `hnsw m=16 ef_search=16` recall: 0.8708, 0.8708, 0.8708
- `hnsw m=16 ef_search=16` throughput_per_second: 1,704, 1,666, 1,687
- `hnsw m=16 ef_search=64` build_seconds: 6.768, 6.768, 6.768
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6851, 0.7001, 0.7267
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.794, 0.8432, 0.8716
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8741, 1.024, 0.9915
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,377, 1,290, 1,293
- `hnsw m=16 ef_search=256` build_seconds: 6.737, 6.737, 6.737
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.635, 1.657, 1.63
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.947, 1.981, 1.957
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.064, 2.161, 2.154
- `hnsw m=16 ef_search=256` recall: 0.9948, 0.9948, 0.9948
- `hnsw m=16 ef_search=256` throughput_per_second: 608.1, 594.6, 609
- `hnsw m=16 ef_search=512` build_seconds: 6.752, 6.752, 6.752
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.735, 2.705, 2.66
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.376, 3.322, 3.254
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.579, 3.508, 3.498
- `hnsw m=16 ef_search=512` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=512` throughput_per_second: 365.2, 369.4, 375.7
- `hnsw m=16 ef_search=1000` build_seconds: 6.753, 6.753, 6.753
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.434, 4.419, 4.516
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.404, 5.419, 5.521
- `hnsw m=16 ef_search=1000` latency_p99_ms: 5.723, 5.755, 5.878
- `hnsw m=16 ef_search=1000` recall: 0.9954, 0.9954, 0.9954
- `hnsw m=16 ef_search=1000` throughput_per_second: 227.7, 228, 221.4

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T092015Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4242f7e458c423578fa2e435f45a2779bb2dd507 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

