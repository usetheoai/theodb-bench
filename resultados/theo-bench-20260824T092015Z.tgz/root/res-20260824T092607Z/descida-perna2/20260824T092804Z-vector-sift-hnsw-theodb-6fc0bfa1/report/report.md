# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T092804Z-vector-sift-hnsw-theodb-6fc0bfa1`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,732 | 0.8702 | 0.5258 | 0.6435 | 0.7616 | **no** |
| hnsw m=16 ef_search=64 | 1,361 | 0.9612 | 0.6904 | 0.7995 | 0.9452 | **no** |
| hnsw m=16 ef_search=256 | 611 | 0.9944 | 1.622 | 1.931 | 2.101 | yes |
| hnsw m=16 ef_search=512 | 379.4 | 0.9966 | 2.624 | 3.229 | 3.434 | yes |
| hnsw m=16 ef_search=1000 | 221.3 | 0.9964 | 4.535 | 5.737 | 6.377 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.153
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.087
- `hnsw m=16 ef_search=1000`: latency_p99_ms cv=0.069

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.825, 6.825, 6.825
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5224, 0.5258, 0.527
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6181, 0.6435, 0.6648
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7046, 0.7616, 0.9399
- `hnsw m=16 ef_search=16` recall: 0.8702, 0.8702, 0.8702
- `hnsw m=16 ef_search=16` throughput_per_second: 1,752, 1,732, 1,697
- `hnsw m=16 ef_search=64` build_seconds: 6.762, 6.762, 6.762
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6603, 0.6915, 0.6904
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7603, 0.8183, 0.7995
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8109, 0.9467, 0.9452
- `hnsw m=16 ef_search=64` recall: 0.9612, 0.9612, 0.9612
- `hnsw m=16 ef_search=64` throughput_per_second: 1,420, 1,320, 1,361
- `hnsw m=16 ef_search=256` build_seconds: 6.843, 6.843, 6.843
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.627, 1.605, 1.622
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.945, 1.908, 1.931
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.108, 2.04, 2.101
- `hnsw m=16 ef_search=256` recall: 0.9944, 0.9944, 0.9944
- `hnsw m=16 ef_search=256` throughput_per_second: 608.8, 619, 611
- `hnsw m=16 ef_search=512` build_seconds: 6.783, 6.783, 6.783
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.619, 2.624, 2.746
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.175, 3.229, 3.322
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.37, 3.434, 3.527
- `hnsw m=16 ef_search=512` recall: 0.9966, 0.9966, 0.9966
- `hnsw m=16 ef_search=512` throughput_per_second: 383.3, 379.4, 362.6
- `hnsw m=16 ef_search=1000` build_seconds: 6.796, 6.796, 6.796
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.388, 4.535, 4.608
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.409, 5.779, 5.737
- `hnsw m=16 ef_search=1000` latency_p99_ms: 5.698, 6.489, 6.377
- `hnsw m=16 ef_search=1000` recall: 0.9964, 0.9964, 0.9964
- `hnsw m=16 ef_search=1000` throughput_per_second: 229.3, 221.3, 219.7

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T092015Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4242f7e458c423578fa2e435f45a2779bb2dd507 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

