# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T114419Z-vector-sift-hnsw-theodb-1e37ac9b`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,711 | 0.8704 | 0.5265 | 0.6564 | 0.7374 | **no** |
| hnsw m=16 ef_search=64 | 1,387 | 0.9614 | 0.6738 | 0.7929 | 0.9404 | **no** |
| hnsw m=16 ef_search=256 | 591.5 | 0.9962 | 1.677 | 1.998 | 2.12 | yes |
| hnsw m=16 ef_search=512 | 375.8 | 0.9984 | 2.664 | 3.217 | 3.4 | yes |
| hnsw m=16 ef_search=1000 | 214.4 | 0.998 | 4.67 | 5.731 | 6.189 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.050; latency_p95_ms cv=0.126; latency_p99_ms cv=0.100; throughput_per_second cv=0.065
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.079
- `hnsw m=16 ef_search=1000`: latency_p95_ms cv=0.065; latency_p99_ms cv=0.059

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.943, 6.943, 6.943
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5257, 0.5265, 0.5731
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6245, 0.6564, 0.7878
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7305, 0.7374, 0.8686
- `hnsw m=16 ef_search=16` recall: 0.8704, 0.8704, 0.8704
- `hnsw m=16 ef_search=16` throughput_per_second: 1,734, 1,711, 1,536
- `hnsw m=16 ef_search=64` build_seconds: 6.925, 6.925, 6.925
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6746, 0.6738, 0.6626
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7843, 0.7942, 0.7929
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8315, 0.9404, 0.9673
- `hnsw m=16 ef_search=64` recall: 0.9614, 0.9614, 0.9614
- `hnsw m=16 ef_search=64` throughput_per_second: 1,387, 1,335, 1,403
- `hnsw m=16 ef_search=256` build_seconds: 6.887, 6.887, 6.887
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.675, 1.718, 1.677
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.998, 2.074, 1.993
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.12, 2.204, 2.114
- `hnsw m=16 ef_search=256` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=256` throughput_per_second: 591.7, 577, 591.5
- `hnsw m=16 ef_search=512` build_seconds: 6.876, 6.876, 6.876
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.673, 2.664, 2.609
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.217, 3.367, 3.203
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.382, 3.547, 3.4
- `hnsw m=16 ef_search=512` recall: 0.9984, 0.9984, 0.9984
- `hnsw m=16 ef_search=512` throughput_per_second: 375.8, 373.8, 382.5
- `hnsw m=16 ef_search=1000` build_seconds: 7.006, 7.006, 7.006
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.798, 4.355, 4.67
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.186, 5.445, 5.731
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.722, 6, 6.189
- `hnsw m=16 ef_search=1000` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=1000` throughput_per_second: 207.1, 227.9, 214.4

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T113137Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424509952 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

