# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T114315Z-vector-sift-hnsw-theodb-0d782f3b`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,621 | 0.8692 | 0.566 | 0.6962 | 0.8186 | yes |
| hnsw m=16 ef_search=64 | 1,353 | 0.9612 | 0.6881 | 0.8087 | 1.006 | **no** |
| hnsw m=16 ef_search=256 | 567.5 | 0.9944 | 1.749 | 2.082 | 2.247 | yes |
| hnsw m=16 ef_search=512 | 350.6 | 0.997 | 2.866 | 3.487 | 3.733 | yes |
| hnsw m=16 ef_search=1000 | 207.9 | 0.9962 | 4.864 | 5.969 | 6.344 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.064

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.883, 6.883, 6.883
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.566, 0.5638, 0.5679
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6769, 0.6962, 0.7058
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.767, 0.8186, 0.8327
- `hnsw m=16 ef_search=16` recall: 0.8692, 0.8692, 0.8692
- `hnsw m=16 ef_search=16` throughput_per_second: 1,628, 1,621, 1,603
- `hnsw m=16 ef_search=64` build_seconds: 6.892, 6.892, 6.892
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6795, 0.7054, 0.6881
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7948, 0.845, 0.8087
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9098, 1.028, 1.006
- `hnsw m=16 ef_search=64` recall: 0.9612, 0.9612, 0.9612
- `hnsw m=16 ef_search=64` throughput_per_second: 1,376, 1,284, 1,353
- `hnsw m=16 ef_search=256` build_seconds: 6.854, 6.854, 6.854
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.716, 1.767, 1.749
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.048, 2.155, 2.082
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.168, 2.381, 2.247
- `hnsw m=16 ef_search=256` recall: 0.9944, 0.9944, 0.9944
- `hnsw m=16 ef_search=256` throughput_per_second: 575.7, 562.3, 567.5
- `hnsw m=16 ef_search=512` build_seconds: 6.897, 6.897, 6.897
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.866, 2.875, 2.863
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.481, 3.51, 3.487
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.671, 3.754, 3.733
- `hnsw m=16 ef_search=512` recall: 0.997, 0.997, 0.997
- `hnsw m=16 ef_search=512` throughput_per_second: 350.6, 348.7, 351.8
- `hnsw m=16 ef_search=1000` build_seconds: 6.886, 6.886, 6.886
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.987, 4.807, 4.864
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.197, 5.853, 5.969
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.549, 6.344, 6.325
- `hnsw m=16 ef_search=1000` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=1000` throughput_per_second: 202, 209.3, 207.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T113137Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424509952 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

