# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T114224Z-analytical-synthetic-paths-theodb-37fcf374`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 124.4 | _not measured_ | 8.059 | 8.351 | 8.377 | yes |
| sum_amount via row | 98.79 | _not measured_ | 10.31 | 10.55 | 10.57 | yes |
| group_by_category via row | 49 | _not measured_ | 20.82 | 21.6 | 21.67 | yes |
| filtered_sum via row | 77.4 | _not measured_ | 12.99 | 13.56 | 13.62 | **no** |
| numeric_filtered_sum via row | 80.86 | _not measured_ | 12.93 | 13.22 | 13.25 | **no** |
| total_rows via columnar | 556.3 | _not measured_ | 1.823 | 1.948 | 1.957 | yes |
| sum_amount via columnar | 271.5 | _not measured_ | 3.706 | 3.787 | 3.805 | yes |
| group_by_category via columnar | 48.77 | _not measured_ | 20.56 | 20.57 | 20.58 | **no** |
| filtered_sum via columnar | 48.81 | _not measured_ | 20.51 | 20.89 | 20.92 | **no** |
| numeric_filtered_sum via columnar | 173.7 | _not measured_ | 5.787 | 5.95 | 5.958 | yes |
| total_rows via parquet | 1.962 | _not measured_ | 511 | 512.5 | 512.5 | yes |
| sum_amount via parquet | 1.799 | _not measured_ | 562.6 | 564.6 | 564.8 | yes |
| group_by_category via parquet | 1.665 | _not measured_ | 601.5 | 603.1 | 603.6 | yes |
| filtered_sum via parquet | 1.809 | _not measured_ | 553.9 | 557.4 | 557.5 | yes |
| numeric_filtered_sum via parquet | 1.783 | _not measured_ | 561.2 | 562.7 | 562.9 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via row`: latency_p50_ms cv=0.076; latency_p95_ms cv=0.062; latency_p99_ms cv=0.062
- `numeric_filtered_sum via row`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.237; latency_p99_ms cv=0.252
- `group_by_category via columnar`: latency_p50_ms cv=0.071; latency_p95_ms cv=0.070; latency_p99_ms cv=0.070; throughput_per_second cv=0.071
- `filtered_sum via columnar`: latency_p50_ms cv=0.070; throughput_per_second cv=0.073

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 8.221, 8.059, 7.817
- `total_rows via row` latency_p95_ms: 8.412, 8.351, 8.239
- `total_rows via row` latency_p99_ms: 8.429, 8.377, 8.276
- `total_rows via row` throughput_per_second: 124, 124.4, 130.4
- `sum_amount via row` latency_p50_ms: 10.47, 10.31, 9.927
- `sum_amount via row` latency_p95_ms: 10.94, 10.55, 9.95
- `sum_amount via row` latency_p99_ms: 10.98, 10.57, 9.952
- `sum_amount via row` throughput_per_second: 96.21, 98.79, 100.8
- `group_by_category via row` latency_p50_ms: 22.17, 20.82, 20.6
- `group_by_category via row` latency_p95_ms: 22.24, 21.6, 20.61
- `group_by_category via row` latency_p99_ms: 22.24, 21.67, 20.61
- `group_by_category via row` throughput_per_second: 46.25, 49, 49.07
- `filtered_sum via row` latency_p50_ms: 14.71, 12.89, 12.99
- `filtered_sum via row` latency_p95_ms: 14.88, 13.56, 13.24
- `filtered_sum via row` latency_p99_ms: 14.89, 13.62, 13.26
- `filtered_sum via row` throughput_per_second: 73.36, 78.47, 77.4
- `numeric_filtered_sum via row` latency_p50_ms: 12.93, 11.88, 13.24
- `numeric_filtered_sum via row` latency_p95_ms: 13.22, 12.02, 18.53
- `numeric_filtered_sum via row` latency_p99_ms: 13.25, 12.03, 19
- `numeric_filtered_sum via row` throughput_per_second: 79.74, 86.32, 80.86
- `total_rows via columnar` latency_p50_ms: 1.849, 1.74, 1.823
- `total_rows via columnar` latency_p95_ms: 1.948, 1.889, 1.975
- `total_rows via columnar` latency_p99_ms: 1.957, 1.902, 1.989
- `total_rows via columnar` throughput_per_second: 556.3, 576.5, 556
- `sum_amount via columnar` latency_p50_ms: 3.725, 3.584, 3.706
- `sum_amount via columnar` latency_p95_ms: 3.802, 3.787, 3.764
- `sum_amount via columnar` latency_p99_ms: 3.808, 3.805, 3.77
- `sum_amount via columnar` throughput_per_second: 271.5, 283.2, 270.4
- `group_by_category via columnar` latency_p50_ms: 18.29, 20.86, 20.56
- `group_by_category via columnar` latency_p95_ms: 18.34, 20.92, 20.57
- `group_by_category via columnar` latency_p99_ms: 18.34, 20.93, 20.58
- `group_by_category via columnar` throughput_per_second: 54.74, 48.36, 48.77
- `filtered_sum via columnar` latency_p50_ms: 18.35, 20.93, 20.51
- `filtered_sum via columnar` latency_p95_ms: 19.7, 21, 20.89
- `filtered_sum via columnar` latency_p99_ms: 19.83, 21.01, 20.92
- `filtered_sum via columnar` throughput_per_second: 54.81, 48.06, 48.81
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.855, 5.68, 5.787
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.95, 5.952, 5.811
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.958, 5.976, 5.813
- `numeric_filtered_sum via columnar` throughput_per_second: 173.7, 177.4, 173.3
- `total_rows via parquet` latency_p50_ms: 511.7, 507.8, 511
- `total_rows via parquet` latency_p95_ms: 512.5, 510.2, 514
- `total_rows via parquet` latency_p99_ms: 512.5, 510.4, 514.3
- `total_rows via parquet` throughput_per_second: 1.962, 1.971, 1.959
- `sum_amount via parquet` latency_p50_ms: 563.4, 557.5, 562.6
- `sum_amount via parquet` latency_p95_ms: 569, 559.9, 564.6
- `sum_amount via parquet` latency_p99_ms: 569.5, 560.1, 564.8
- `sum_amount via parquet` throughput_per_second: 1.778, 1.804, 1.799
- `group_by_category via parquet` latency_p50_ms: 601.5, 597.9, 607.8
- `group_by_category via parquet` latency_p95_ms: 602.8, 603.1, 608.2
- `group_by_category via parquet` latency_p99_ms: 602.9, 603.6, 608.2
- `group_by_category via parquet` throughput_per_second: 1.665, 1.679, 1.649
- `filtered_sum via parquet` latency_p50_ms: 551.7, 553.9, 556
- `filtered_sum via parquet` latency_p95_ms: 553.8, 558.6, 557.4
- `filtered_sum via parquet` latency_p99_ms: 554, 559, 557.5
- `filtered_sum via parquet` throughput_per_second: 1.813, 1.809, 1.802
- `numeric_filtered_sum via parquet` latency_p50_ms: 559, 561.2, 565.9
- `numeric_filtered_sum via parquet` latency_p95_ms: 560.9, 562.7, 566.9
- `numeric_filtered_sum via parquet` latency_p99_ms: 561.1, 562.9, 566.9
- `numeric_filtered_sum via parquet` throughput_per_second: 1.793, 1.783, 1.769

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T113137Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424509952 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

