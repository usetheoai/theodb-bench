# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T130624Z-vector-sift-hnsw-theodb-f4634e72`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,401 | 0.8692 | 0.6513 | 0.795 | 0.8972 | yes |
| hnsw m=16 ef_search=64 | 1,213 | 0.9642 | 0.7636 | 0.9132 | 1.057 | **no** |
| hnsw m=16 ef_search=256 | 483.9 | 0.9978 | 2.032 | 2.431 | 2.555 | yes |
| hnsw m=16 ef_search=512 | 311.1 | 0.9998 | 3.18 | 3.922 | 4.345 | yes |
| hnsw m=16 ef_search=1000 | 186.8 | 1 | 5.352 | 6.695 | 7.274 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.072

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 29.87, 29.87, 29.87
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6513, 0.6452, 0.6567
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.795, 0.7954, 0.7884
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8508, 0.8972, 0.9243
- `hnsw m=16 ef_search=16` recall: 0.8692, 0.8692, 0.8692
- `hnsw m=16 ef_search=16` throughput_per_second: 1,401, 1,408, 1,397
- `hnsw m=16 ef_search=64` build_seconds: 29.59, 29.59, 29.59
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7636, 0.7486, 0.7749
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9125, 0.9436, 0.9132
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.057, 1.174, 1.025
- `hnsw m=16 ef_search=64` recall: 0.9642, 0.9642, 0.9642
- `hnsw m=16 ef_search=64` throughput_per_second: 1,227, 1,187, 1,213
- `hnsw m=16 ef_search=256` build_seconds: 29.67, 29.67, 29.67
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.047, 1.947, 2.032
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.431, 2.338, 2.497
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.555, 2.552, 2.698
- `hnsw m=16 ef_search=256` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=256` throughput_per_second: 483.9, 505.8, 483.1
- `hnsw m=16 ef_search=512` build_seconds: 30.49, 30.49, 30.49
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.201, 3.065, 3.18
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.999, 3.819, 3.922
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.345, 4.063, 4.412
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 309.4, 321.7, 311.1
- `hnsw m=16 ef_search=1000` build_seconds: 29.77, 29.77, 29.77
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.345, 5.354, 5.352
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.695, 6.755, 6.664
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.241, 7.274, 7.324
- `hnsw m=16 ef_search=1000` recall: 1, 1, 1
- `hnsw m=16 ef_search=1000` throughput_per_second: 186.8, 187.1, 186.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

