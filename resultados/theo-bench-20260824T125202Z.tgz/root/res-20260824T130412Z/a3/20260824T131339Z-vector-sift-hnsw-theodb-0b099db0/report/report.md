# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T131339Z-vector-sift-hnsw-theodb-0b099db0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,440 | 0.8698 | 0.6236 | 0.7952 | 0.8578 | **no** |
| hnsw m=16 ef_search=64 | 1,167 | 0.9618 | 0.7685 | 0.9236 | 1.114 | **no** |
| hnsw m=16 ef_search=256 | 500.6 | 0.9962 | 1.943 | 2.332 | 2.544 | **no** |
| hnsw m=16 ef_search=512 | 311.1 | 0.9984 | 3.189 | 3.898 | 4.243 | yes |
| hnsw m=16 ef_search=1000 | 191.8 | 0.9982 | 5.209 | 6.397 | 6.865 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.125
- `hnsw m=16 ef_search=64`: latency_p95_ms cv=0.079; latency_p99_ms cv=0.083
- `hnsw m=16 ef_search=256`: latency_p99_ms cv=0.057
- `hnsw m=16 ef_search=1000`: latency_p50_ms cv=0.059; latency_p95_ms cv=0.062; latency_p99_ms cv=0.080; throughput_per_second cv=0.056

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 8.525, 8.525, 8.525
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6194, 0.6338, 0.6236
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7608, 0.7952, 0.8029
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8419, 0.8578, 1.047
- `hnsw m=16 ef_search=16` recall: 0.8698, 0.8698, 0.8698
- `hnsw m=16 ef_search=16` throughput_per_second: 1,473, 1,440, 1,429
- `hnsw m=16 ef_search=64` build_seconds: 8.605, 8.605, 8.605
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7685, 0.7671, 0.8036
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8853, 0.9236, 1.029
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9621, 1.117, 1.114
- `hnsw m=16 ef_search=64` recall: 0.9618, 0.9618, 0.9618
- `hnsw m=16 ef_search=64` throughput_per_second: 1,227, 1,167, 1,154
- `hnsw m=16 ef_search=256` build_seconds: 8.611, 8.611, 8.611
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.922, 1.943, 1.958
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.263, 2.332, 2.376
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.405, 2.694, 2.544
- `hnsw m=16 ef_search=256` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=256` throughput_per_second: 509.5, 500.6, 499.4
- `hnsw m=16 ef_search=512` build_seconds: 8.578, 8.578, 8.578
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.198, 3.158, 3.189
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.991, 3.898, 3.895
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.465, 4.157, 4.243
- `hnsw m=16 ef_search=512` recall: 0.9984, 0.9984, 0.9984
- `hnsw m=16 ef_search=512` throughput_per_second: 309.4, 313.7, 311.1
- `hnsw m=16 ef_search=1000` build_seconds: 8.666, 8.666, 8.666
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.634, 5.027, 5.209
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.999, 6.221, 6.397
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.783, 6.737, 6.865
- `hnsw m=16 ef_search=1000` recall: 0.9982, 0.9982, 0.9982
- `hnsw m=16 ef_search=1000` throughput_per_second: 177.3, 197.9, 191.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

