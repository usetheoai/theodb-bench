# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T130508Z-vector-sift-hnsw-theodb-f0424403`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,441 | 0.8714 | 0.6373 | 0.7747 | 0.8885 | yes |
| hnsw m=16 ef_search=64 | 1,186 | 0.9614 | 0.7863 | 0.9253 | 1.089 | **no** |
| hnsw m=16 ef_search=256 | 490.8 | 0.9962 | 1.992 | 2.461 | 2.667 | **no** |
| hnsw m=16 ef_search=512 | 286.9 | 0.998 | 3.431 | 4.329 | 4.797 | yes |
| hnsw m=16 ef_search=1000 | 181.8 | 0.9978 | 5.512 | 6.891 | 7.264 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.082
- `hnsw m=16 ef_search=256`: latency_p95_ms cv=0.053; latency_p99_ms cv=0.097

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 8.668, 8.668, 8.668
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6462, 0.6192, 0.6373
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7952, 0.7747, 0.7746
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.9359, 0.8885, 0.8818
- `hnsw m=16 ef_search=16` recall: 0.8714, 0.8714, 0.8714
- `hnsw m=16 ef_search=16` throughput_per_second: 1,406, 1,471, 1,441
- `hnsw m=16 ef_search=64` build_seconds: 8.681, 8.681, 8.681
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.774, 0.7981, 0.7863
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9052, 0.9615, 0.9253
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9611, 1.126, 1.089
- `hnsw m=16 ef_search=64` recall: 0.9614, 0.9614, 0.9614
- `hnsw m=16 ef_search=64` throughput_per_second: 1,208, 1,126, 1,186
- `hnsw m=16 ef_search=256` build_seconds: 8.557, 8.557, 8.557
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.922, 1.992, 2.049
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.352, 2.461, 2.615
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.52, 2.667, 3.035
- `hnsw m=16 ef_search=256` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=256` throughput_per_second: 511.5, 490.8, 476.8
- `hnsw m=16 ef_search=512` build_seconds: 8.671, 8.671, 8.671
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.298, 3.431, 3.477
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.149, 4.329, 4.41
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.522, 4.797, 4.836
- `hnsw m=16 ef_search=512` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=512` throughput_per_second: 300.3, 286.9, 284.9
- `hnsw m=16 ef_search=1000` build_seconds: 8.885, 8.885, 8.885
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.697, 5.428, 5.512
- `hnsw m=16 ef_search=1000` latency_p95_ms: 7.022, 6.77, 6.891
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.523, 7.26, 7.264
- `hnsw m=16 ef_search=1000` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=1000` throughput_per_second: 176.2, 183.4, 181.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

