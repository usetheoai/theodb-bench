# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T131453Z-vector-sift-hnsw-theodb-f4e3a642`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,200 | 0.8718 | 0.7413 | 0.8885 | 0.9673 | **no** |
| hnsw m=16 ef_search=64 | 1,114 | 0.9642 | 0.7939 | 1.051 | 1.139 | **no** |
| hnsw m=16 ef_search=256 | 482.6 | 0.9976 | 2.025 | 2.506 | 2.72 | yes |
| hnsw m=16 ef_search=512 | 297.9 | 0.9998 | 3.354 | 4.148 | 4.406 | **no** |
| hnsw m=16 ef_search=1000 | 189.4 | 1 | 5.27 | 6.652 | 7.412 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.097; latency_p95_ms cv=0.077; latency_p99_ms cv=0.062; throughput_per_second cv=0.115
- `hnsw m=16 ef_search=64`: latency_p95_ms cv=0.058; latency_p99_ms cv=0.059
- `hnsw m=16 ef_search=512`: latency_p99_ms cv=0.053

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 29.29, 29.29, 29.29
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.7413, 0.6247, 0.7433
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.9051, 0.7834, 0.8885
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.9673, 0.9087, 1.028
- `hnsw m=16 ef_search=16` recall: 0.8718, 0.8718, 0.8718
- `hnsw m=16 ef_search=16` throughput_per_second: 1,200, 1,454, 1,196
- `hnsw m=16 ef_search=64` build_seconds: 29.34, 29.34, 29.34
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.8167, 0.785, 0.7939
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.051, 1.058, 0.9516
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.139, 1.257, 1.135
- `hnsw m=16 ef_search=64` recall: 0.9642, 0.9642, 0.9642
- `hnsw m=16 ef_search=64` throughput_per_second: 1,114, 1,105, 1,176
- `hnsw m=16 ef_search=256` build_seconds: 29.67, 29.67, 29.67
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.025, 2.052, 2.022
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.477, 2.508, 2.506
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.887, 2.69, 2.72
- `hnsw m=16 ef_search=256` recall: 0.9976, 0.9976, 0.9976
- `hnsw m=16 ef_search=256` throughput_per_second: 482.6, 478.1, 483.7
- `hnsw m=16 ef_search=512` build_seconds: 30.33, 30.33, 30.33
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.354, 3.373, 3.147
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.148, 4.311, 3.919
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.406, 4.751, 4.297
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 297.9, 291.4, 314
- `hnsw m=16 ef_search=1000` build_seconds: 29.55, 29.55, 29.55
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.237, 5.339, 5.27
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.627, 6.652, 6.671
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.554, 7.29, 7.412
- `hnsw m=16 ef_search=1000` recall: 1, 1, 1
- `hnsw m=16 ef_search=1000` throughput_per_second: 189.4, 188.9, 190.1

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

