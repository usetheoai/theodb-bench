# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T131040Z-vector-sift-hnsw-theodb-b494d921`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,455 | 0.8736 | 0.6231 | 0.7743 | 0.8487 | yes |
| hnsw m=16 ef_search=64 | 1,220 | 0.965 | 0.765 | 0.9128 | 1.047 | **no** |
| hnsw m=16 ef_search=256 | 504.4 | 0.9978 | 1.931 | 2.335 | 2.522 | yes |
| hnsw m=16 ef_search=512 | 319.2 | 0.9998 | 3.12 | 3.811 | 4.093 | yes |
| hnsw m=16 ef_search=1000 | 193.3 | 0.9998 | 5.14 | 6.549 | 7.272 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.084

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 29.97, 29.97, 29.97
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6347, 0.6231, 0.586
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7743, 0.7987, 0.7269
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8487, 0.887, 0.8303
- `hnsw m=16 ef_search=16` recall: 0.8736, 0.8736, 0.8736
- `hnsw m=16 ef_search=16` throughput_per_second: 1,439, 1,455, 1,537
- `hnsw m=16 ef_search=64` build_seconds: 29.95, 29.95, 29.95
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7587, 0.7719, 0.765
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9122, 0.9531, 0.9128
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9987, 1.174, 1.047
- `hnsw m=16 ef_search=64` recall: 0.965, 0.965, 0.965
- `hnsw m=16 ef_search=64` throughput_per_second: 1,236, 1,158, 1,220
- `hnsw m=16 ef_search=256` build_seconds: 29.62, 29.62, 29.62
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.918, 1.931, 2.004
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.316, 2.335, 2.392
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.494, 2.522, 2.542
- `hnsw m=16 ef_search=256` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=256` throughput_per_second: 510.7, 504.4, 488.6
- `hnsw m=16 ef_search=512` build_seconds: 29.77, 29.77, 29.77
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.12, 3.135, 3.085
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.81, 3.961, 3.811
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.093, 4.331, 4.014
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 319.2, 317.2, 321.1
- `hnsw m=16 ef_search=1000` build_seconds: 29.44, 29.44, 29.44
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.17, 5.112, 5.14
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.57, 6.529, 6.549
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.33, 7.188, 7.272
- `hnsw m=16 ef_search=1000` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=1000` throughput_per_second: 191.9, 194.6, 193.3

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

