# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T130416Z-analytical-synthetic-paths-theodb-08549db2`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 111.6 | _not measured_ | 9.17 | 9.968 | 10.04 | yes |
| sum_amount via row | 90.9 | _not measured_ | 11.19 | 11.28 | 11.29 | yes |
| group_by_category via row | 46.05 | _not measured_ | 21.86 | 22.29 | 22.33 | yes |
| filtered_sum via row | 68.89 | _not measured_ | 14.6 | 14.65 | 14.67 | yes |
| numeric_filtered_sum via row | 73.84 | _not measured_ | 13.65 | 13.84 | 13.86 | yes |
| total_rows via columnar | 583.2 | _not measured_ | 1.841 | 1.992 | 2.006 | yes |
| sum_amount via columnar | 280.1 | _not measured_ | 3.604 | 3.813 | 3.825 | yes |
| group_by_category via columnar | 43.33 | _not measured_ | 23.09 | 23.62 | 23.67 | yes |
| filtered_sum via columnar | 43.15 | _not measured_ | 23.2 | 23.24 | 23.24 | **no** |
| numeric_filtered_sum via columnar | 167.1 | _not measured_ | 6.321 | 6.366 | 6.37 | **no** |
| total_rows via parquet | 1.909 | _not measured_ | 533.3 | 536.8 | 537.1 | yes |
| sum_amount via parquet | 1.697 | _not measured_ | 590.5 | 595.9 | 596.5 | yes |
| group_by_category via parquet | 1.616 | _not measured_ | 621.6 | 628 | 628.6 | yes |
| filtered_sum via parquet | 1.752 | _not measured_ | 573.5 | 578.5 | 579.1 | yes |
| numeric_filtered_sum via parquet | 1.728 | _not measured_ | 580.8 | 590.8 | 591.5 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via columnar`: latency_p50_ms cv=0.065; latency_p95_ms cv=0.051; latency_p99_ms cv=0.050; throughput_per_second cv=0.056
- `numeric_filtered_sum via columnar`: latency_p50_ms cv=0.087; latency_p95_ms cv=0.068; latency_p99_ms cv=0.067; throughput_per_second cv=0.064

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.751, 9.17, 9.108
- `total_rows via row` latency_p95_ms: 10.06, 9.833, 9.968
- `total_rows via row` latency_p99_ms: 10.08, 9.892, 10.04
- `total_rows via row` throughput_per_second: 110.4, 114.6, 111.6
- `sum_amount via row` latency_p50_ms: 11.19, 11.07, 11.34
- `sum_amount via row` latency_p95_ms: 11.28, 11.09, 11.38
- `sum_amount via row` latency_p99_ms: 11.29, 11.09, 11.38
- `sum_amount via row` throughput_per_second: 91.08, 90.9, 90.04
- `group_by_category via row` latency_p50_ms: 21.84, 21.86, 23.48
- `group_by_category via row` latency_p95_ms: 22.07, 22.29, 23.48
- `group_by_category via row` latency_p99_ms: 22.09, 22.33, 23.48
- `group_by_category via row` throughput_per_second: 46.19, 46.05, 43.72
- `filtered_sum via row` latency_p50_ms: 14.39, 14.6, 14.91
- `filtered_sum via row` latency_p95_ms: 14.65, 14.6, 15.53
- `filtered_sum via row` latency_p99_ms: 14.67, 14.6, 15.59
- `filtered_sum via row` throughput_per_second: 72.22, 68.89, 67.61
- `numeric_filtered_sum via row` latency_p50_ms: 13.96, 13.65, 13.51
- `numeric_filtered_sum via row` latency_p95_ms: 14.29, 13.84, 13.56
- `numeric_filtered_sum via row` latency_p99_ms: 14.32, 13.86, 13.57
- `numeric_filtered_sum via row` throughput_per_second: 71.91, 73.84, 75.63
- `total_rows via columnar` latency_p50_ms: 1.863, 1.725, 1.841
- `total_rows via columnar` latency_p95_ms: 2.031, 1.872, 1.992
- `total_rows via columnar` latency_p99_ms: 2.046, 1.885, 2.006
- `total_rows via columnar` throughput_per_second: 559, 583.2, 586.4
- `sum_amount via columnar` latency_p50_ms: 3.673, 3.604, 3.573
- `sum_amount via columnar` latency_p95_ms: 3.813, 3.927, 3.648
- `sum_amount via columnar` latency_p99_ms: 3.825, 3.956, 3.654
- `sum_amount via columnar` throughput_per_second: 275, 280.1, 282.3
- `group_by_category via columnar` latency_p50_ms: 23.03, 23.46, 23.09
- `group_by_category via columnar` latency_p95_ms: 23.08, 24.95, 23.62
- `group_by_category via columnar` latency_p99_ms: 23.09, 25.09, 23.67
- `group_by_category via columnar` throughput_per_second: 45.46, 42.9, 43.33
- `filtered_sum via columnar` latency_p50_ms: 21.79, 23.2, 24.81
- `filtered_sum via columnar` latency_p95_ms: 22.69, 23.24, 25.01
- `filtered_sum via columnar` latency_p99_ms: 22.77, 23.24, 25.03
- `filtered_sum via columnar` throughput_per_second: 46.1, 43.15, 41.22
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.321, 5.662, 6.733
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.366, 5.952, 6.82
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.37, 5.977, 6.828
- `numeric_filtered_sum via columnar` throughput_per_second: 167.1, 178.1, 156.8
- `total_rows via parquet` latency_p50_ms: 527.2, 535.9, 533.3
- `total_rows via parquet` latency_p95_ms: 527.3, 544.7, 536.8
- `total_rows via parquet` latency_p99_ms: 527.3, 545.5, 537.1
- `total_rows via parquet` throughput_per_second: 1.909, 1.914, 1.895
- `sum_amount via parquet` latency_p50_ms: 585.1, 590.5, 596.6
- `sum_amount via parquet` latency_p95_ms: 595.6, 595.9, 597.1
- `sum_amount via parquet` latency_p99_ms: 596.5, 596.3, 597.1
- `sum_amount via parquet` throughput_per_second: 1.714, 1.697, 1.687
- `group_by_category via parquet` latency_p50_ms: 625.8, 616.8, 621.6
- `group_by_category via parquet` latency_p95_ms: 634.8, 617.4, 628
- `group_by_category via parquet` latency_p99_ms: 635.6, 617.4, 628.6
- `group_by_category via parquet` throughput_per_second: 1.616, 1.635, 1.616
- `filtered_sum via parquet` latency_p50_ms: 571, 576, 573.5
- `filtered_sum via parquet` latency_p95_ms: 578.5, 577.7, 582.9
- `filtered_sum via parquet` latency_p99_ms: 579.1, 577.8, 583.7
- `filtered_sum via parquet` throughput_per_second: 1.758, 1.752, 1.749
- `numeric_filtered_sum via parquet` latency_p50_ms: 580.8, 579, 583.6
- `numeric_filtered_sum via parquet` latency_p95_ms: 592.9, 579, 590.8
- `numeric_filtered_sum via parquet` latency_p99_ms: 594, 579, 591.5
- `numeric_filtered_sum via parquet` throughput_per_second: 1.723, 1.728, 1.732

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

