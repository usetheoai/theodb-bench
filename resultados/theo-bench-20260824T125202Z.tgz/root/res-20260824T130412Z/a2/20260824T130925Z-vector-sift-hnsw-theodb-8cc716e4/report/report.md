# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T130925Z-vector-sift-hnsw-theodb-8cc716e4`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,511 | 0.8706 | 0.6022 | 0.7276 | 0.8362 | **no** |
| hnsw m=16 ef_search=64 | 1,196 | 0.962 | 0.7736 | 0.9319 | 1.118 | **no** |
| hnsw m=16 ef_search=256 | 494.9 | 0.9954 | 1.97 | 2.456 | 2.684 | **no** |
| hnsw m=16 ef_search=512 | 308.9 | 0.9984 | 3.198 | 4.032 | 4.36 | yes |
| hnsw m=16 ef_search=1000 | 188 | 0.998 | 5.254 | 6.711 | 7.43 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.089
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.096
- `hnsw m=16 ef_search=256`: latency_p50_ms cv=0.053

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 8.55, 8.55, 8.55
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6004, 0.6022, 0.6127
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7098, 0.7276, 0.7799
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7777, 0.8362, 0.927
- `hnsw m=16 ef_search=16` recall: 0.8706, 0.8706, 0.8706
- `hnsw m=16 ef_search=16` throughput_per_second: 1,527, 1,511, 1,474
- `hnsw m=16 ef_search=64` build_seconds: 8.608, 8.608, 8.608
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7558, 0.7787, 0.7736
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9031, 0.9319, 0.9593
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9495, 1.118, 1.135
- `hnsw m=16 ef_search=64` recall: 0.962, 0.962, 0.962
- `hnsw m=16 ef_search=64` throughput_per_second: 1,236, 1,159, 1,196
- `hnsw m=16 ef_search=256` build_seconds: 8.642, 8.642, 8.642
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.925, 1.97, 2.129
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.394, 2.456, 2.569
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.511, 2.684, 2.707
- `hnsw m=16 ef_search=256` recall: 0.9954, 0.9954, 0.9954
- `hnsw m=16 ef_search=256` throughput_per_second: 510, 494.9, 462.3
- `hnsw m=16 ef_search=512` build_seconds: 8.781, 8.781, 8.781
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.198, 3.197, 3.223
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.89, 4.032, 4.065
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.137, 4.36, 4.378
- `hnsw m=16 ef_search=512` recall: 0.9984, 0.9984, 0.9984
- `hnsw m=16 ef_search=512` throughput_per_second: 313.3, 308.9, 307.6
- `hnsw m=16 ef_search=1000` build_seconds: 8.769, 8.769, 8.769
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.254, 5.127, 5.297
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.711, 6.455, 6.784
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.43, 6.91, 7.592
- `hnsw m=16 ef_search=1000` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=1000` throughput_per_second: 188, 194.3, 186.4

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T125202Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

