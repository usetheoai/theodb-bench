# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T151204Z-analytical-synthetic-paths-theodb-e98bcbc9`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 113 | _not measured_ | 9.141 | 9.556 | 9.593 | yes |
| sum_amount via row | 93.42 | _not measured_ | 10.76 | 11.12 | 11.15 | yes |
| group_by_category via row | 46.32 | _not measured_ | 21.86 | 22.39 | 22.43 | yes |
| filtered_sum via row | 70.17 | _not measured_ | 14.47 | 15.03 | 15.07 | **no** |
| numeric_filtered_sum via row | 77.02 | _not measured_ | 13.03 | 13.76 | 13.8 | **no** |
| total_rows via columnar | 577.9 | _not measured_ | 1.788 | 2 | 2.019 | yes |
| sum_amount via columnar | 282.8 | _not measured_ | 3.759 | 3.834 | 3.841 | yes |
| group_by_category via columnar | 42.53 | _not measured_ | 23.52 | 23.8 | 23.83 | **no** |
| filtered_sum via columnar | 42.38 | _not measured_ | 23.95 | 24.13 | 24.15 | **no** |
| numeric_filtered_sum via columnar | 168.1 | _not measured_ | 6 | 6.254 | 6.274 | yes |
| total_rows via parquet | 1.895 | _not measured_ | 528.7 | 530.8 | 531.1 | yes |
| sum_amount via parquet | 1.704 | _not measured_ | 588.9 | 596.5 | 596.9 | yes |
| group_by_category via parquet | 1.612 | _not measured_ | 624 | 626.5 | 626.7 | yes |
| filtered_sum via parquet | 1.772 | _not measured_ | 565.6 | 568.3 | 568.6 | yes |
| numeric_filtered_sum via parquet | 1.725 | _not measured_ | 583.6 | 587.5 | 587.5 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `filtered_sum via row`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.056
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.059; latency_p99_ms cv=0.061
- `group_by_category via columnar`: throughput_per_second cv=0.063
- `filtered_sum via columnar`: latency_p50_ms cv=0.065; throughput_per_second cv=0.071

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.366, 9.121, 9.141
- `total_rows via row` latency_p95_ms: 9.812, 9.465, 9.556
- `total_rows via row` latency_p99_ms: 9.852, 9.496, 9.593
- `total_rows via row` throughput_per_second: 113, 112.6, 113.9
- `sum_amount via row` latency_p50_ms: 10.78, 10.76, 10.7
- `sum_amount via row` latency_p95_ms: 11.13, 11.12, 10.84
- `sum_amount via row` latency_p99_ms: 11.16, 11.15, 10.85
- `sum_amount via row` throughput_per_second: 93.42, 93.24, 93.51
- `group_by_category via row` latency_p50_ms: 21.86, 22.12, 21.45
- `group_by_category via row` latency_p95_ms: 22.39, 22.52, 21.48
- `group_by_category via row` latency_p99_ms: 22.43, 22.56, 21.49
- `group_by_category via row` throughput_per_second: 46.32, 45.65, 47.98
- `filtered_sum via row` latency_p50_ms: 14.57, 14.47, 13.63
- `filtered_sum via row` latency_p95_ms: 15.03, 15.07, 13.68
- `filtered_sum via row` latency_p99_ms: 15.07, 15.13, 13.69
- `filtered_sum via row` throughput_per_second: 69.95, 70.17, 73.49
- `numeric_filtered_sum via row` latency_p50_ms: 13.3, 13.03, 12.33
- `numeric_filtered_sum via row` latency_p95_ms: 13.76, 13.8, 12.41
- `numeric_filtered_sum via row` latency_p99_ms: 13.8, 13.87, 12.42
- `numeric_filtered_sum via row` throughput_per_second: 75.33, 77.02, 81.75
- `total_rows via columnar` latency_p50_ms: 1.789, 1.788, 1.752
- `total_rows via columnar` latency_p95_ms: 2, 1.96, 2
- `total_rows via columnar` latency_p99_ms: 2.019, 1.976, 2.021
- `total_rows via columnar` throughput_per_second: 577.9, 559.7, 597.5
- `sum_amount via columnar` latency_p50_ms: 3.832, 3.759, 3.518
- `sum_amount via columnar` latency_p95_ms: 3.857, 3.834, 3.666
- `sum_amount via columnar` latency_p99_ms: 3.859, 3.841, 3.679
- `sum_amount via columnar` throughput_per_second: 272.4, 282.8, 287.3
- `group_by_category via columnar` latency_p50_ms: 21.69, 23.81, 23.52
- `group_by_category via columnar` latency_p95_ms: 22.47, 23.87, 23.8
- `group_by_category via columnar` latency_p99_ms: 22.54, 23.87, 23.83
- `group_by_category via columnar` throughput_per_second: 47.31, 42.52, 42.53
- `filtered_sum via columnar` latency_p50_ms: 21.86, 24.83, 23.95
- `filtered_sum via columnar` latency_p95_ms: 23.01, 24.94, 24.13
- `filtered_sum via columnar` latency_p99_ms: 23.11, 24.95, 24.15
- `filtered_sum via columnar` throughput_per_second: 46.72, 40.8, 42.38
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.031, 5.913, 6
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.254, 6.29, 6.192
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.274, 6.324, 6.209
- `numeric_filtered_sum via columnar` throughput_per_second: 168.1, 173.7, 166.9
- `total_rows via parquet` latency_p50_ms: 525.9, 528.7, 541.3
- `total_rows via parquet` latency_p95_ms: 530.7, 530.8, 553.2
- `total_rows via parquet` latency_p99_ms: 531.1, 531, 554.2
- `total_rows via parquet` throughput_per_second: 1.91, 1.895, 1.85
- `sum_amount via parquet` latency_p50_ms: 583.7, 588.9, 592
- `sum_amount via parquet` latency_p95_ms: 588.4, 607.2, 596.5
- `sum_amount via parquet` latency_p99_ms: 588.9, 608.8, 596.9
- `sum_amount via parquet` throughput_per_second: 1.73, 1.704, 1.691
- `group_by_category via parquet` latency_p50_ms: 621.7, 624, 625.9
- `group_by_category via parquet` latency_p95_ms: 624.4, 626.5, 627.2
- `group_by_category via parquet` latency_p99_ms: 624.6, 626.7, 627.3
- `group_by_category via parquet` throughput_per_second: 1.614, 1.612, 1.601
- `filtered_sum via parquet` latency_p50_ms: 565.6, 564.4, 579.7
- `filtered_sum via parquet` latency_p95_ms: 566.8, 568.3, 582.4
- `filtered_sum via parquet` latency_p99_ms: 566.9, 568.6, 582.7
- `filtered_sum via parquet` throughput_per_second: 1.777, 1.772, 1.729
- `numeric_filtered_sum via parquet` latency_p50_ms: 575.3, 587, 583.6
- `numeric_filtered_sum via parquet` latency_p95_ms: 579.7, 587.5, 605.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 580.1, 587.5, 607.4
- `numeric_filtered_sum via parquet` throughput_per_second: 1.745, 1.724, 1.725

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T150530Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

