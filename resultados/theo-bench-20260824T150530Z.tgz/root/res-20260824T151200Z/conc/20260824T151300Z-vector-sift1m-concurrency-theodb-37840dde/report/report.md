# vector/sift1m/concurrency on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T151300Z-vector-sift1m-concurrency-theodb-37840dde`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 [c=16] | 2,206 | 0.9097 | 6.06 | 13.91 | 19.31 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64 [c=16]`: latency_p95_ms cv=0.076; latency_p99_ms cv=0.108

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64 [c=16]` build_seconds: 202, 202, 202
- `hnsw m=16 ef_search=64 [c=16]` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64 [c=16]` latency_p50_ms: 6.159, 5.608, 6.06
- `hnsw m=16 ef_search=64 [c=16]` latency_p95_ms: 14.87, 12.77, 13.91
- `hnsw m=16 ef_search=64 [c=16]` latency_p99_ms: 22.03, 17.82, 19.31
- `hnsw m=16 ef_search=64 [c=16]` recall: 0.9097, 0.9097, 0.9097
- `hnsw m=16 ef_search=64 [c=16]` throughput_per_second: 2,145, 2,350, 2,206

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T150530Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

