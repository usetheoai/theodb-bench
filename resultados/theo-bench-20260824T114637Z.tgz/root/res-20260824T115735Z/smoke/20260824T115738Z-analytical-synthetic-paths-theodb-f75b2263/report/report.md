# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T115738Z-analytical-synthetic-paths-theodb-f75b2263`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 129.8 | _not measured_ | 7.778 | 8.259 | 8.282 | yes |
| sum_amount via row | 99.3 | _not measured_ | 10.11 | 10.32 | 10.34 | yes |
| group_by_category via row | 50.39 | _not measured_ | 20.23 | 20.5 | 20.53 | yes |
| filtered_sum via row | 77.43 | _not measured_ | 12.93 | 12.98 | 12.98 | yes |
| numeric_filtered_sum via row | 86.31 | _not measured_ | 12.08 | 12.29 | 12.31 | yes |
| total_rows via columnar | 558.1 | _not measured_ | 1.816 | 1.98 | 2 | yes |
| sum_amount via columnar | 274 | _not measured_ | 3.667 | 3.776 | 3.785 | yes |
| group_by_category via columnar | 49.03 | _not measured_ | 20.4 | 20.56 | 20.57 | **no** |
| filtered_sum via columnar | 48.66 | _not measured_ | 20.64 | 20.85 | 20.87 | **no** |
| numeric_filtered_sum via columnar | 173.3 | _not measured_ | 5.943 | 5.959 | 5.962 | yes |
| total_rows via parquet | 2.001 | _not measured_ | 501.8 | 504.6 | 504.9 | yes |
| sum_amount via parquet | 1.808 | _not measured_ | 558.9 | 559.4 | 559.4 | yes |
| group_by_category via parquet | 1.691 | _not measured_ | 594.8 | 597.8 | 598 | yes |
| filtered_sum via parquet | 1.819 | _not measured_ | 551.7 | 553.2 | 553.3 | yes |
| numeric_filtered_sum via parquet | 1.827 | _not measured_ | 551.5 | 553.4 | 553.6 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via columnar`: latency_p50_ms cv=0.057; latency_p95_ms cv=0.059; latency_p99_ms cv=0.060; throughput_per_second cv=0.057
- `filtered_sum via columnar`: latency_p50_ms cv=0.072; latency_p95_ms cv=0.071; latency_p99_ms cv=0.071; throughput_per_second cv=0.074

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 8.002, 7.735, 7.778
- `total_rows via row` latency_p95_ms: 8.259, 8.266, 8.233
- `total_rows via row` latency_p99_ms: 8.282, 8.314, 8.274
- `total_rows via row` throughput_per_second: 127.9, 129.8, 130.2
- `sum_amount via row` latency_p50_ms: 10.33, 10.11, 10.04
- `sum_amount via row` latency_p95_ms: 10.46, 10.32, 10.2
- `sum_amount via row` latency_p99_ms: 10.47, 10.34, 10.21
- `sum_amount via row` throughput_per_second: 96.82, 99.3, 99.95
- `group_by_category via row` latency_p50_ms: 20.78, 20.23, 19.6
- `group_by_category via row` latency_p95_ms: 21.02, 20.5, 19.71
- `group_by_category via row` latency_p99_ms: 21.04, 20.53, 19.72
- `group_by_category via row` throughput_per_second: 48.43, 50.39, 51.51
- `filtered_sum via row` latency_p50_ms: 12.93, 13.18, 12.28
- `filtered_sum via row` latency_p95_ms: 12.98, 13.31, 12.41
- `filtered_sum via row` latency_p99_ms: 12.98, 13.32, 12.42
- `filtered_sum via row` throughput_per_second: 77.43, 76.13, 82.48
- `numeric_filtered_sum via row` latency_p50_ms: 12.19, 12.08, 11.18
- `numeric_filtered_sum via row` latency_p95_ms: 12.36, 12.29, 11.4
- `numeric_filtered_sum via row` latency_p99_ms: 12.38, 12.31, 11.42
- `numeric_filtered_sum via row` throughput_per_second: 82.27, 86.31, 90.43
- `total_rows via columnar` latency_p50_ms: 1.856, 1.816, 1.755
- `total_rows via columnar` latency_p95_ms: 2.05, 1.929, 1.98
- `total_rows via columnar` latency_p99_ms: 2.068, 1.939, 2
- `total_rows via columnar` throughput_per_second: 551.5, 558.1, 579.9
- `sum_amount via columnar` latency_p50_ms: 3.667, 3.698, 3.656
- `sum_amount via columnar` latency_p95_ms: 3.776, 3.889, 3.7
- `sum_amount via columnar` latency_p99_ms: 3.785, 3.906, 3.704
- `sum_amount via columnar` throughput_per_second: 273.8, 274, 276.1
- `group_by_category via columnar` latency_p50_ms: 18.72, 20.4, 20.86
- `group_by_category via columnar` latency_p95_ms: 18.73, 20.56, 20.98
- `group_by_category via columnar` latency_p99_ms: 18.73, 20.57, 20.99
- `group_by_category via columnar` throughput_per_second: 53.56, 49.03, 48.24
- `filtered_sum via columnar` latency_p50_ms: 18.32, 20.64, 20.99
- `filtered_sum via columnar` latency_p95_ms: 18.47, 20.85, 21.02
- `filtered_sum via columnar` latency_p99_ms: 18.48, 20.87, 21.03
- `filtered_sum via columnar` throughput_per_second: 55.03, 48.66, 48.34
- `numeric_filtered_sum via columnar` latency_p50_ms: 5.943, 5.966, 5.776
- `numeric_filtered_sum via columnar` latency_p95_ms: 5.959, 6.046, 5.947
- `numeric_filtered_sum via columnar` latency_p99_ms: 5.96, 6.053, 5.962
- `numeric_filtered_sum via columnar` throughput_per_second: 170.4, 173.3, 176.4
- `total_rows via parquet` latency_p50_ms: 500.1, 501.8, 508.1
- `total_rows via parquet` latency_p95_ms: 504.5, 504.6, 511.2
- `total_rows via parquet` latency_p99_ms: 504.9, 504.8, 511.4
- `total_rows via parquet` throughput_per_second: 2.008, 2.001, 1.981
- `sum_amount via parquet` latency_p50_ms: 550.4, 560.3, 558.9
- `sum_amount via parquet` latency_p95_ms: 553.1, 562.5, 559.4
- `sum_amount via parquet` latency_p99_ms: 553.3, 562.7, 559.4
- `sum_amount via parquet` throughput_per_second: 1.821, 1.808, 1.79
- `group_by_category via parquet` latency_p50_ms: 594.8, 593.9, 596.6
- `group_by_category via parquet` latency_p95_ms: 597.8, 596.7, 598.6
- `group_by_category via parquet` latency_p99_ms: 598, 597, 598.8
- `group_by_category via parquet` throughput_per_second: 1.682, 1.691, 1.691
- `filtered_sum via parquet` latency_p50_ms: 541.8, 551.7, 552.2
- `filtered_sum via parquet` latency_p95_ms: 542.2, 578.5, 553.2
- `filtered_sum via parquet` latency_p99_ms: 542.3, 580.8, 553.3
- `filtered_sum via parquet` throughput_per_second: 1.859, 1.819, 1.812
- `numeric_filtered_sum via parquet` latency_p50_ms: 549, 553.4, 551.5
- `numeric_filtered_sum via parquet` latency_p95_ms: 552.6, 557, 553.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 552.9, 557.3, 553.6
- `numeric_filtered_sum via parquet` throughput_per_second: 1.831, 1.827, 1.815

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

