# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T120033Z-vector-sift-hnsw-theodb-6421631c`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,672 | 0.8692 | 0.5425 | 0.6757 | 0.7763 | **no** |
| hnsw m=16 ef_search=64 | 1,357 | 0.961 | 0.6719 | 0.8011 | 0.9569 | **no** |
| hnsw m=16 ef_search=256 | 588.8 | 0.9944 | 1.681 | 2.014 | 2.227 | yes |
| hnsw m=16 ef_search=512 | 358 | 0.9962 | 2.771 | 3.452 | 3.721 | yes |
| hnsw m=16 ef_search=1000 | 213.4 | 0.997 | 4.713 | 5.83 | 6.451 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.129; latency_p95_ms cv=0.107; latency_p99_ms cv=0.101; throughput_per_second cv=0.130
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.056

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.781, 6.781, 6.781
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5399, 0.6719, 0.5425
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6424, 0.7858, 0.6757
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7425, 0.8977, 0.7763
- `hnsw m=16 ef_search=16` recall: 0.8692, 0.8692, 0.8692
- `hnsw m=16 ef_search=16` throughput_per_second: 1,693, 1,330, 1,672
- `hnsw m=16 ef_search=64` build_seconds: 6.804, 6.804, 6.804
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6854, 0.6714, 0.6719
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8463, 0.8011, 0.7884
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.006, 0.9569, 0.8989
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,357, 1,337, 1,395
- `hnsw m=16 ef_search=256` build_seconds: 6.801, 6.801, 6.801
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.676, 1.689, 1.681
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.011, 2.027, 2.014
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.132, 2.227, 2.234
- `hnsw m=16 ef_search=256` recall: 0.9944, 0.9944, 0.9944
- `hnsw m=16 ef_search=256` throughput_per_second: 593.2, 588.8, 587.2
- `hnsw m=16 ef_search=512` build_seconds: 6.841, 6.841, 6.841
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.77, 2.907, 2.771
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.452, 3.539, 3.402
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.739, 3.721, 3.686
- `hnsw m=16 ef_search=512` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=512` throughput_per_second: 358, 343.2, 361.3
- `hnsw m=16 ef_search=1000` build_seconds: 6.785, 6.785, 6.785
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.666, 4.713, 4.744
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.754, 5.956, 5.83
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.493, 6.451, 6.351
- `hnsw m=16 ef_search=1000` recall: 0.997, 0.997, 0.997
- `hnsw m=16 ef_search=1000` throughput_per_second: 214.7, 213.4, 212

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

