# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T120340Z-vector-sift-hnsw-theodb-30063eb2`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,555 | 0.8714 | 0.5904 | 0.728 | 0.8388 | yes |
| hnsw m=16 ef_search=64 | 1,380 | 0.962 | 0.6785 | 0.7963 | 0.9255 | yes |
| hnsw m=16 ef_search=256 | 582.9 | 0.9964 | 1.7 | 2.022 | 2.193 | yes |
| hnsw m=16 ef_search=512 | 377.6 | 0.998 | 2.651 | 3.22 | 3.432 | yes |
| hnsw m=16 ef_search=1000 | 218.3 | 0.9984 | 4.6 | 5.642 | 6.143 | yes |

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.869, 6.869, 6.869
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5972, 0.5855, 0.5904
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.728, 0.7341, 0.725
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8388, 0.842, 0.8293
- `hnsw m=16 ef_search=16` recall: 0.8714, 0.8714, 0.8714
- `hnsw m=16 ef_search=16` throughput_per_second: 1,539, 1,563, 1,555
- `hnsw m=16 ef_search=64` build_seconds: 6.857, 6.857, 6.857
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6669, 0.6785, 0.6788
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7689, 0.7983, 0.7963
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8716, 0.9545, 0.9255
- `hnsw m=16 ef_search=64` recall: 0.962, 0.962, 0.962
- `hnsw m=16 ef_search=64` throughput_per_second: 1,405, 1,330, 1,380
- `hnsw m=16 ef_search=256` build_seconds: 6.854, 6.854, 6.854
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.689, 1.714, 1.7
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.006, 2.043, 2.022
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.121, 2.193, 2.236
- `hnsw m=16 ef_search=256` recall: 0.9964, 0.9964, 0.9964
- `hnsw m=16 ef_search=256` throughput_per_second: 589.3, 580.3, 582.9
- `hnsw m=16 ef_search=512` build_seconds: 6.8, 6.8, 6.8
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.651, 2.751, 2.622
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.219, 3.36, 3.22
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.388, 3.612, 3.432
- `hnsw m=16 ef_search=512` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=512` throughput_per_second: 377.6, 361.1, 380.2
- `hnsw m=16 ef_search=1000` build_seconds: 6.844, 6.844, 6.844
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.6, 4.708, 4.477
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.642, 5.794, 5.598
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.172, 6.143, 5.961
- `hnsw m=16 ef_search=1000` recall: 0.9984, 0.9984, 0.9984
- `hnsw m=16 ef_search=1000` throughput_per_second: 218.3, 213.9, 223.2

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

