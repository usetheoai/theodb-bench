# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T115827Z-vector-sift-hnsw-theodb-57ec375d`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,724 | 0.8708 | 0.5285 | 0.635 | 0.7354 | yes |
| hnsw m=16 ef_search=64 | 1,378 | 0.9604 | 0.6794 | 0.7872 | 0.9297 | **no** |
| hnsw m=16 ef_search=256 | 595.6 | 0.995 | 1.662 | 1.985 | 2.161 | yes |
| hnsw m=16 ef_search=512 | 367.6 | 0.9966 | 2.724 | 3.291 | 3.539 | yes |
| hnsw m=16 ef_search=1000 | 211.2 | 0.997 | 4.754 | 5.888 | 6.293 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.063

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.885, 6.885, 6.885
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5311, 0.5248, 0.5285
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6205, 0.635, 0.6525
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.6957, 0.7354, 0.7423
- `hnsw m=16 ef_search=16` recall: 0.8708, 0.8708, 0.8708
- `hnsw m=16 ef_search=16` throughput_per_second: 1,724, 1,727, 1,704
- `hnsw m=16 ef_search=64` build_seconds: 6.832, 6.832, 6.832
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6794, 0.675, 0.68
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7872, 0.8003, 0.7856
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8532, 0.9655, 0.9297
- `hnsw m=16 ef_search=64` recall: 0.9604, 0.9604, 0.9604
- `hnsw m=16 ef_search=64` throughput_per_second: 1,378, 1,338, 1,378
- `hnsw m=16 ef_search=256` build_seconds: 6.807, 6.807, 6.807
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.665, 1.662, 1.657
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.965, 2.006, 1.985
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.088, 2.161, 2.191
- `hnsw m=16 ef_search=256` recall: 0.995, 0.995, 0.995
- `hnsw m=16 ef_search=256` throughput_per_second: 596.2, 595.6, 594.6
- `hnsw m=16 ef_search=512` build_seconds: 6.814, 6.814, 6.814
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.721, 2.725, 2.724
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.289, 3.291, 3.317
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.508, 3.556, 3.539
- `hnsw m=16 ef_search=512` recall: 0.9966, 0.9966, 0.9966
- `hnsw m=16 ef_search=512` throughput_per_second: 367.6, 368.6, 366.8
- `hnsw m=16 ef_search=1000` build_seconds: 6.873, 6.873, 6.873
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.694, 4.764, 4.754
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.794, 5.888, 5.917
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.263, 6.294, 6.293
- `hnsw m=16 ef_search=1000` recall: 0.997, 0.997, 0.997
- `hnsw m=16 ef_search=1000` throughput_per_second: 214.1, 211.2, 210.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

