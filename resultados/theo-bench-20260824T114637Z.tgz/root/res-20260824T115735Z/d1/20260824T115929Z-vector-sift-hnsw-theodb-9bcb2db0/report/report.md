# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T115929Z-vector-sift-hnsw-theodb-9bcb2db0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,497 | 0.8704 | 0.6103 | 0.7707 | 0.97 | **no** |
| hnsw m=16 ef_search=64 | 1,174 | 0.961 | 0.7856 | 0.8816 | 0.934 | **no** |
| hnsw m=16 ef_search=256 | 588.6 | 0.9958 | 1.67 | 2.057 | 2.183 | **no** |
| hnsw m=16 ef_search=512 | 356.8 | 0.998 | 2.808 | 3.461 | 3.657 | yes |
| hnsw m=16 ef_search=1000 | 221.7 | 0.9984 | 4.548 | 5.693 | 6.272 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p95_ms cv=0.101; latency_p99_ms cv=0.130; throughput_per_second cv=0.054
- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.086; latency_p95_ms cv=0.095; latency_p99_ms cv=0.109; throughput_per_second cv=0.115
- `hnsw m=16 ef_search=256`: latency_p99_ms cv=0.117

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.963, 6.963, 6.963
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5813, 0.6103, 0.6184
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6937, 0.7707, 0.8497
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7948, 1.028, 0.97
- `hnsw m=16 ef_search=16` recall: 0.8704, 0.8704, 0.8704
- `hnsw m=16 ef_search=16` throughput_per_second: 1,584, 1,497, 1,423
- `hnsw m=16 ef_search=64` build_seconds: 6.915, 6.915, 6.915
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7856, 0.8217, 0.6937
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8816, 0.9742, 0.8062
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9204, 1.113, 0.934
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,174, 1,084, 1,355
- `hnsw m=16 ef_search=256` build_seconds: 6.865, 6.865, 6.865
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.67, 1.664, 1.681
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.971, 2.103, 2.057
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.082, 2.585, 2.183
- `hnsw m=16 ef_search=256` recall: 0.9958, 0.9958, 0.9958
- `hnsw m=16 ef_search=256` throughput_per_second: 596.1, 587.4, 588.6
- `hnsw m=16 ef_search=512` build_seconds: 6.896, 6.896, 6.896
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.961, 2.808, 2.771
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.574, 3.461, 3.384
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.767, 3.657, 3.602
- `hnsw m=16 ef_search=512` recall: 0.998, 0.998, 0.998
- `hnsw m=16 ef_search=512` throughput_per_second: 337.1, 356.8, 360.4
- `hnsw m=16 ef_search=1000` build_seconds: 6.882, 6.882, 6.882
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.548, 4.536, 4.669
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.693, 5.596, 5.851
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.347, 6.101, 6.272
- `hnsw m=16 ef_search=1000` recall: 0.9984, 0.9984, 0.9984
- `hnsw m=16 ef_search=1000` throughput_per_second: 221.7, 222, 213.2

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

