# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T120238Z-vector-sift-hnsw-theodb-2f169d24`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,319 | 0.87 | 0.6863 | 0.7912 | 0.8571 | **no** |
| hnsw m=16 ef_search=64 | 1,412 | 0.961 | 0.6615 | 0.7725 | 0.893 | yes |
| hnsw m=16 ef_search=256 | 588.7 | 0.9958 | 1.686 | 2.019 | 2.225 | yes |
| hnsw m=16 ef_search=512 | 372.7 | 0.9962 | 2.695 | 3.28 | 3.486 | yes |
| hnsw m=16 ef_search=1000 | 218.2 | 0.9964 | 4.594 | 5.7 | 6.149 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.097; latency_p95_ms cv=0.051; latency_p99_ms cv=0.073; throughput_per_second cv=0.096

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.751, 6.751, 6.751
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6863, 0.6951, 0.5806
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7912, 0.8229, 0.7434
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8571, 0.9482, 0.8241
- `hnsw m=16 ef_search=16` recall: 0.87, 0.87, 0.87
- `hnsw m=16 ef_search=16` throughput_per_second: 1,319, 1,315, 1,548
- `hnsw m=16 ef_search=64` build_seconds: 6.764, 6.764, 6.764
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6615, 0.6705, 0.6612
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.77, 0.791, 0.7725
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8346, 0.9208, 0.893
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,420, 1,350, 1,412
- `hnsw m=16 ef_search=256` build_seconds: 6.794, 6.794, 6.794
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.659, 1.711, 1.686
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.973, 2.093, 2.019
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.149, 2.305, 2.225
- `hnsw m=16 ef_search=256` recall: 0.9958, 0.9958, 0.9958
- `hnsw m=16 ef_search=256` throughput_per_second: 597.3, 570.8, 588.7
- `hnsw m=16 ef_search=512` build_seconds: 6.769, 6.769, 6.769
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.669, 2.718, 2.695
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.238, 3.404, 3.28
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.404, 3.69, 3.486
- `hnsw m=16 ef_search=512` recall: 0.9962, 0.9962, 0.9962
- `hnsw m=16 ef_search=512` throughput_per_second: 374.9, 365.6, 372.7
- `hnsw m=16 ef_search=1000` build_seconds: 6.787, 6.787, 6.787
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.594, 4.491, 4.603
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.764, 5.554, 5.7
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.238, 6.149, 6.115
- `hnsw m=16 ef_search=1000` recall: 0.9964, 0.9964, 0.9964
- `hnsw m=16 ef_search=1000` throughput_per_second: 217.8, 222.5, 218.2

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

