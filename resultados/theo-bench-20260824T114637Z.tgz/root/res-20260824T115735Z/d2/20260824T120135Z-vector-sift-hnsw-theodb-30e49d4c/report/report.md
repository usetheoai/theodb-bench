# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T120135Z-vector-sift-hnsw-theodb-30e49d4c`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,588 | 0.8706 | 0.579 | 0.7033 | 0.7937 | **no** |
| hnsw m=16 ef_search=64 | 1,371 | 0.9612 | 0.6775 | 0.7931 | 0.8998 | yes |
| hnsw m=16 ef_search=256 | 600 | 0.997 | 1.66 | 1.966 | 2.133 | yes |
| hnsw m=16 ef_search=512 | 374.5 | 0.9976 | 2.686 | 3.27 | 3.49 | yes |
| hnsw m=16 ef_search=1000 | 216.9 | 0.9978 | 4.617 | 5.85 | 6.547 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.063
- `hnsw m=16 ef_search=1000`: latency_p99_ms cv=0.051

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 6.926, 6.926, 6.926
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.579, 0.5696, 0.5939
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.6892, 0.7033, 0.7294
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.7916, 0.7937, 0.8825
- `hnsw m=16 ef_search=16` recall: 0.8706, 0.8706, 0.8706
- `hnsw m=16 ef_search=16` throughput_per_second: 1,588, 1,600, 1,537
- `hnsw m=16 ef_search=64` build_seconds: 6.866, 6.866, 6.866
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.6828, 0.6775, 0.6647
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.7931, 0.7971, 0.7849
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.8803, 0.9581, 0.8998
- `hnsw m=16 ef_search=64` recall: 0.9612, 0.9612, 0.9612
- `hnsw m=16 ef_search=64` throughput_per_second: 1,371, 1,336, 1,406
- `hnsw m=16 ef_search=256` build_seconds: 6.863, 6.863, 6.863
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.654, 1.673, 1.66
- `hnsw m=16 ef_search=256` latency_p95_ms: 1.959, 1.998, 1.966
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.083, 2.245, 2.133
- `hnsw m=16 ef_search=256` recall: 0.997, 0.997, 0.997
- `hnsw m=16 ef_search=256` throughput_per_second: 601.3, 591.3, 600
- `hnsw m=16 ef_search=512` build_seconds: 6.877, 6.877, 6.877
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 2.686, 2.777, 2.677
- `hnsw m=16 ef_search=512` latency_p95_ms: 3.27, 3.395, 3.223
- `hnsw m=16 ef_search=512` latency_p99_ms: 3.447, 3.625, 3.49
- `hnsw m=16 ef_search=512` recall: 0.9976, 0.9976, 0.9976
- `hnsw m=16 ef_search=512` throughput_per_second: 374.5, 360.7, 375.4
- `hnsw m=16 ef_search=1000` build_seconds: 6.868, 6.868, 6.868
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 4.71, 4.617, 4.558
- `hnsw m=16 ef_search=1000` latency_p95_ms: 5.9, 5.72, 5.85
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.605, 6.012, 6.547
- `hnsw m=16 ef_search=1000` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=1000` throughput_per_second: 213.4, 217.3, 216.9

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T114637Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

