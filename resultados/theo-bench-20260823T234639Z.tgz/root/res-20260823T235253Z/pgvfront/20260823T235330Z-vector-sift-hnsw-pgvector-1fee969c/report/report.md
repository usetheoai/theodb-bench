# vector/sift/hnsw on pgvector

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T235330Z-vector-sift-hnsw-pgvector-1fee969c`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,717 | 0.8844 | 0.5235 | 0.6583 | 0.792 | **no** |
| hnsw m=16 ef_search=64 | 875.7 | 0.9888 | 1.091 | 1.321 | 1.453 | **no** |
| hnsw m=16 ef_search=256 | 362.9 | 1 | 2.734 | 3.42 | 3.651 | yes |
| hnsw m=16 ef_search=512 | 219.4 | 0.999 | 4.568 | 5.595 | 6.063 | yes |
| hnsw m=16 ef_search=1000 | 134.3 | 0.9996 | 7.449 | 9.238 | 9.872 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.068; latency_p95_ms cv=0.069; latency_p99_ms cv=0.065; throughput_per_second cv=0.063
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.077

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 23.92, 23.92, 23.92
- `hnsw m=16 ef_search=16` index_size_bytes: 8.317e+07, 8.317e+07, 8.317e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.5864, 0.5235, 0.5212
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7286, 0.6583, 0.6397
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.792, 0.7994, 0.7099
- `hnsw m=16 ef_search=16` recall: 0.8844, 0.8844, 0.8844
- `hnsw m=16 ef_search=16` throughput_per_second: 1,546, 1,717, 1,738
- `hnsw m=16 ef_search=64` build_seconds: 23.92, 23.92, 23.92
- `hnsw m=16 ef_search=64` index_size_bytes: 8.315e+07, 8.315e+07, 8.315e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.099, 1.091, 1.091
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.329, 1.321, 1.296
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.406, 1.625, 1.453
- `hnsw m=16 ef_search=64` recall: 0.9888, 0.9888, 0.9888
- `hnsw m=16 ef_search=64` throughput_per_second: 875.7, 856.3, 881.6
- `hnsw m=16 ef_search=256` build_seconds: 23.6, 23.6, 23.6
- `hnsw m=16 ef_search=256` index_size_bytes: 8.317e+07, 8.317e+07, 8.317e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.74, 2.734, 2.724
- `hnsw m=16 ef_search=256` latency_p95_ms: 3.42, 3.45, 3.322
- `hnsw m=16 ef_search=256` latency_p99_ms: 3.713, 3.651, 3.599
- `hnsw m=16 ef_search=256` recall: 1, 1, 1
- `hnsw m=16 ef_search=256` throughput_per_second: 362.4, 362.9, 367.5
- `hnsw m=16 ef_search=512` build_seconds: 24.16, 24.16, 24.16
- `hnsw m=16 ef_search=512` index_size_bytes: 8.315e+07, 8.315e+07, 8.315e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 4.499, 4.6, 4.568
- `hnsw m=16 ef_search=512` latency_p95_ms: 5.593, 5.655, 5.595
- `hnsw m=16 ef_search=512` latency_p99_ms: 5.978, 6.1, 6.063
- `hnsw m=16 ef_search=512` recall: 0.999, 0.999, 0.999
- `hnsw m=16 ef_search=512` throughput_per_second: 221.5, 219, 219.4
- `hnsw m=16 ef_search=1000` build_seconds: 23.87, 23.87, 23.87
- `hnsw m=16 ef_search=1000` index_size_bytes: 8.306e+07, 8.306e+07, 8.306e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 7.455, 7.449, 7.433
- `hnsw m=16 ef_search=1000` latency_p95_ms: 9.326, 9.238, 9.103
- `hnsw m=16 ef_search=1000` latency_p99_ms: 9.872, 9.988, 9.614
- `hnsw m=16 ef_search=1000` recall: 0.9996, 0.9996, 0.9996
- `hnsw m=16 ef_search=1000` throughput_per_second: 133.6, 134.3, 134.6

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T234639Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: e3a2d470d700437bfb74fb5b685bb4f7dd5a0304 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

