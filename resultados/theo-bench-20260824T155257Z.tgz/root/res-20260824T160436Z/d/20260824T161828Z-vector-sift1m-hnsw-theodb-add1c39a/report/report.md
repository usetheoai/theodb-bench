# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T161828Z-vector-sift1m-hnsw-theodb-add1c39a`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 736.7 | 0.901 | 1.296 | 1.588 | 1.735 | yes |
| hnsw m=16 ef_search=256 | 279.9 | 0.9902 | 3.576 | 4.191 | 4.472 | yes |
| hnsw m=16 ef_search=512 | 156 | 0.9978 | 6.516 | 7.766 | 8.202 | yes |
| hnsw m=16 ef_search=1000 | 94.8 | 0.9994 | 10.74 | 13.29 | 14.12 | yes |

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 204.4, 204.4, 204.4
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.303, 1.216, 1.296
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.604, 1.565, 1.588
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.744, 1.717, 1.735
- `hnsw m=16 ef_search=64` recall: 0.901, 0.901, 0.901
- `hnsw m=16 ef_search=64` throughput_per_second: 736.7, 762.2, 732.2
- `hnsw m=16 ef_search=256` build_seconds: 203.4, 203.4, 203.4
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.632, 3.576, 3.524
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.194, 4.167, 4.191
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.472, 4.451, 4.498
- `hnsw m=16 ef_search=256` recall: 0.9902, 0.9902, 0.9902
- `hnsw m=16 ef_search=256` throughput_per_second: 279.7, 279.9, 283
- `hnsw m=16 ef_search=512` build_seconds: 202.2, 202.2, 202.2
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.549, 6.226, 6.516
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.807, 7.664, 7.766
- `hnsw m=16 ef_search=512` latency_p99_ms: 8.202, 8.683, 8.131
- `hnsw m=16 ef_search=512` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=512` throughput_per_second: 156, 162.2, 156
- `hnsw m=16 ef_search=1000` build_seconds: 203.1, 203.1, 203.1
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 10.74, 10.82, 10.59
- `hnsw m=16 ef_search=1000` latency_p95_ms: 13.29, 13.3, 13.06
- `hnsw m=16 ef_search=1000` latency_p99_ms: 14.12, 14.01, 14.26
- `hnsw m=16 ef_search=1000` recall: 0.9994, 0.9994, 0.9994
- `hnsw m=16 ef_search=1000` throughput_per_second: 94.66, 94.8, 96.78

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T155257Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

