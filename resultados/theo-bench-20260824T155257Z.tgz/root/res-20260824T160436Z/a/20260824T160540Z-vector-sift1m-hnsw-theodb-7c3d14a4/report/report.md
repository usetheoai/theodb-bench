# vector/sift1m/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T160540Z-vector-sift1m-hnsw-theodb-7c3d14a4`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=64 | 743.5 | 0.9002 | 1.285 | 1.562 | 1.779 | **no** |
| hnsw m=16 ef_search=256 | 273.4 | 0.9898 | 3.647 | 4.322 | 4.689 | yes |
| hnsw m=16 ef_search=512 | 158.5 | 0.9966 | 6.387 | 7.74 | 8.351 | yes |
| hnsw m=16 ef_search=1000 | 94.5 | 0.9996 | 10.78 | 13.52 | 15.03 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.055
- `hnsw m=16 ef_search=1000`: latency_p50_ms cv=0.069; latency_p95_ms cv=0.063; throughput_per_second cv=0.067

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=64` build_seconds: 158.4, 158.4, 158.4
- `hnsw m=16 ef_search=64` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=64` latency_p50_ms: 1.224, 1.342, 1.285
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.54, 1.626, 1.562
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.662, 1.853, 1.779
- `hnsw m=16 ef_search=64` recall: 0.9002, 0.9002, 0.9002
- `hnsw m=16 ef_search=64` throughput_per_second: 765.7, 720.8, 743.5
- `hnsw m=16 ef_search=256` build_seconds: 157.6, 157.6, 157.6
- `hnsw m=16 ef_search=256` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=256` latency_p50_ms: 3.647, 3.474, 3.744
- `hnsw m=16 ef_search=256` latency_p95_ms: 4.322, 4.205, 4.395
- `hnsw m=16 ef_search=256` latency_p99_ms: 4.693, 4.689, 4.612
- `hnsw m=16 ef_search=256` recall: 0.9898, 0.9898, 0.9898
- `hnsw m=16 ef_search=256` throughput_per_second: 273.4, 283.2, 269.7
- `hnsw m=16 ef_search=512` build_seconds: 156.5, 156.5, 156.5
- `hnsw m=16 ef_search=512` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=512` latency_p50_ms: 6.471, 6.387, 6.363
- `hnsw m=16 ef_search=512` latency_p95_ms: 7.739, 7.74, 7.93
- `hnsw m=16 ef_search=512` latency_p99_ms: 8.351, 8.327, 8.716
- `hnsw m=16 ef_search=512` recall: 0.9966, 0.9966, 0.9966
- `hnsw m=16 ef_search=512` throughput_per_second: 156.9, 158.5, 159
- `hnsw m=16 ef_search=1000` build_seconds: 157.3, 157.3, 157.3
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.593e+08, 7.593e+08, 7.593e+08
- `hnsw m=16 ef_search=1000` latency_p50_ms: 12.04, 10.78, 10.63
- `hnsw m=16 ef_search=1000` latency_p95_ms: 14.8, 13.52, 13.13
- `hnsw m=16 ef_search=1000` latency_p99_ms: 15.98, 15.03, 14.59
- `hnsw m=16 ef_search=1000` recall: 0.9996, 0.9996, 0.9996
- `hnsw m=16 ef_search=1000` throughput_per_second: 84.62, 94.5, 95.76

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T155257Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

