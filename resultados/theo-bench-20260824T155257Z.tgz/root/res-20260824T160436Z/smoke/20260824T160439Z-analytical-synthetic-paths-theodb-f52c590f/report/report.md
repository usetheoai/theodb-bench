# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T160439Z-analytical-synthetic-paths-theodb-f52c590f`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 103.5 | _not measured_ | 9.768 | 9.877 | 9.887 | yes |
| sum_amount via row | 88.71 | _not measured_ | 11.44 | 11.92 | 12.01 | **no** |
| group_by_category via row | 45.45 | _not measured_ | 22.42 | 23.03 | 23.08 | yes |
| filtered_sum via row | 69.69 | _not measured_ | 14.59 | 15.12 | 15.17 | yes |
| numeric_filtered_sum via row | 75.02 | _not measured_ | 13.35 | 14.19 | 14.26 | yes |
| total_rows via columnar | 561.5 | _not measured_ | 1.877 | 1.984 | 1.993 | **no** |
| sum_amount via columnar | 274.6 | _not measured_ | 3.731 | 4.027 | 4.056 | **no** |
| group_by_category via columnar | 43.84 | _not measured_ | 22.88 | 23.78 | 23.89 | yes |
| filtered_sum via columnar | 45.28 | _not measured_ | 22.34 | 22.65 | 22.68 | **no** |
| numeric_filtered_sum via columnar | 167.5 | _not measured_ | 6.126 | 6.284 | 6.297 | yes |
| total_rows via parquet | 1.902 | _not measured_ | 531.7 | 532.7 | 532.7 | yes |
| sum_amount via parquet | 1.708 | _not measured_ | 586.3 | 590.9 | 591 | yes |
| group_by_category via parquet | 1.603 | _not measured_ | 626.9 | 635.4 | 635.8 | yes |
| filtered_sum via parquet | 1.766 | _not measured_ | 572.3 | 575.6 | 575.9 | yes |
| numeric_filtered_sum via parquet | 1.741 | _not measured_ | 576.4 | 586.8 | 587.3 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `sum_amount via row`: latency_p50_ms cv=0.061; throughput_per_second cv=0.058
- `total_rows via columnar`: latency_p50_ms cv=0.083; latency_p95_ms cv=0.117; latency_p99_ms cv=0.120; throughput_per_second cv=0.098
- `sum_amount via columnar`: latency_p50_ms cv=0.106; latency_p95_ms cv=0.067; latency_p99_ms cv=0.064; throughput_per_second cv=0.102
- `filtered_sum via columnar`: latency_p50_ms cv=0.062; latency_p95_ms cv=0.072; latency_p99_ms cv=0.073; throughput_per_second cv=0.063

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.768, 9.535, 9.857
- `total_rows via row` latency_p95_ms: 9.877, 9.586, 10.1
- `total_rows via row` latency_p99_ms: 9.887, 9.59, 10.13
- `total_rows via row` throughput_per_second: 103.5, 106.4, 101.7
- `sum_amount via row` latency_p50_ms: 10.93, 11.44, 12.33
- `sum_amount via row` latency_p95_ms: 11.92, 11.63, 12.35
- `sum_amount via row` latency_p99_ms: 12.01, 11.64, 12.35
- `sum_amount via row` throughput_per_second: 92, 88.71, 81.97
- `group_by_category via row` latency_p50_ms: 22.2, 22.58, 22.42
- `group_by_category via row` latency_p95_ms: 22.3, 23.16, 23.03
- `group_by_category via row` latency_p99_ms: 22.31, 23.21, 23.08
- `group_by_category via row` throughput_per_second: 45.45, 45.89, 45.39
- `filtered_sum via row` latency_p50_ms: 14.18, 14.65, 14.59
- `filtered_sum via row` latency_p95_ms: 14.32, 15.46, 15.12
- `filtered_sum via row` latency_p99_ms: 14.33, 15.53, 15.17
- `filtered_sum via row` throughput_per_second: 71.16, 69.69, 69.3
- `numeric_filtered_sum via row` latency_p50_ms: 13.27, 13.77, 13.35
- `numeric_filtered_sum via row` latency_p95_ms: 13.36, 14.49, 14.19
- `numeric_filtered_sum via row` latency_p99_ms: 13.37, 14.55, 14.26
- `numeric_filtered_sum via row` throughput_per_second: 75.99, 74.71, 75.02
- `total_rows via columnar` latency_p50_ms: 1.805, 1.877, 2.112
- `total_rows via columnar` latency_p95_ms: 1.972, 1.984, 2.406
- `total_rows via columnar` latency_p99_ms: 1.986, 1.993, 2.432
- `total_rows via columnar` throughput_per_second: 569.8, 561.5, 474.8
- `sum_amount via columnar` latency_p50_ms: 3.707, 3.731, 4.448
- `sum_amount via columnar` latency_p95_ms: 4.027, 3.949, 4.462
- `sum_amount via columnar` latency_p99_ms: 4.056, 3.968, 4.464
- `sum_amount via columnar` throughput_per_second: 281.4, 274.6, 231.9
- `group_by_category via columnar` latency_p50_ms: 22.54, 22.88, 23.77
- `group_by_category via columnar` latency_p95_ms: 23.78, 22.88, 24.6
- `group_by_category via columnar` latency_p99_ms: 23.89, 22.88, 24.68
- `group_by_category via columnar` throughput_per_second: 44.44, 43.84, 42.18
- `filtered_sum via columnar` latency_p50_ms: 21.46, 22.34, 24.19
- `filtered_sum via columnar` latency_p95_ms: 21.71, 22.65, 24.93
- `filtered_sum via columnar` latency_p99_ms: 21.74, 22.68, 25
- `filtered_sum via columnar` throughput_per_second: 47.07, 45.28, 41.56
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.148, 5.828, 6.126
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.284, 6.087, 6.558
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.297, 6.11, 6.597
- `numeric_filtered_sum via columnar` throughput_per_second: 167.5, 173.5, 163.5
- `total_rows via parquet` latency_p50_ms: 527.7, 531.7, 538.4
- `total_rows via parquet` latency_p95_ms: 530.1, 532.7, 539.5
- `total_rows via parquet` latency_p99_ms: 530.3, 532.7, 539.6
- `total_rows via parquet` throughput_per_second: 1.931, 1.902, 1.859
- `sum_amount via parquet` latency_p50_ms: 582.2, 586.3, 589.9
- `sum_amount via parquet` latency_p95_ms: 587.5, 594.6, 590.9
- `sum_amount via parquet` latency_p99_ms: 588, 595.4, 591
- `sum_amount via parquet` throughput_per_second: 1.729, 1.708, 1.696
- `group_by_category via parquet` latency_p50_ms: 615.5, 626.9, 631.2
- `group_by_category via parquet` latency_p95_ms: 620.1, 635.9, 635.4
- `group_by_category via parquet` latency_p99_ms: 620.5, 636.7, 635.8
- `group_by_category via parquet` throughput_per_second: 1.625, 1.603, 1.591
- `filtered_sum via parquet` latency_p50_ms: 572.3, 597.9, 568.7
- `filtered_sum via parquet` latency_p95_ms: 575.6, 605.8, 570
- `filtered_sum via parquet` latency_p99_ms: 575.9, 606.5, 570.1
- `filtered_sum via parquet` throughput_per_second: 1.766, 1.738, 1.767
- `numeric_filtered_sum via parquet` latency_p50_ms: 575.2, 581, 576.4
- `numeric_filtered_sum via parquet` latency_p95_ms: 589.2, 586.8, 580.3
- `numeric_filtered_sum via parquet` latency_p99_ms: 590.4, 587.3, 580.6
- `numeric_filtered_sum via parquet` throughput_per_second: 1.743, 1.741, 1.735

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T155257Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 364377d9568bd48e27301fc12272dde26e4ecfd3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

