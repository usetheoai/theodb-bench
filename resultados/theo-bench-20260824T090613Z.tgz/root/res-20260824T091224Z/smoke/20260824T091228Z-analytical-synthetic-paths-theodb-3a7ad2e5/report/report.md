# analytical/synthetic/paths on theodb

**Status:** INVALID · **Profile:** research · **Run:** `20260824T091228Z-analytical-synthetic-paths-theodb-3a7ad2e5`

> This run is **INVALID**. It failed protocol validation, which says nothing about whether the numbers were favourable -- invalidation is never based on the measured outcome.

## Results

No configuration produced a measurement.

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | FAIL | yes | system under test crashed or became unreachable during the run |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | UNAVAILABLE | no | benchmark declared no expected operation count |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | FAIL | no | a declared collector produced no data |
| quality_reported | FAIL | yes | approximate retrieval reported without a quality axis |
| clean_source_tree | PASS | no |  |

Invalidated by: `sut_alive`, `quality_reported`

Invalidation is based on protocol criteria, never on whether the numbers looked good.

## Environment

- Host: theo-bench-20260824T090613Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 428f33d22d2d7d4c428f916edd6fa55142a723f3 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

