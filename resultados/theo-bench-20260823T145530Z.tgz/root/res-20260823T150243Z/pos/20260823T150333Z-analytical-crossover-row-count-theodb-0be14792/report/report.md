# analytical/crossover/row-count on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T150333Z-analytical-crossover-row-count-theodb-0be14792`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row @ 10000 linhas | 1,680 | _not measured_ | 0.6421 | 0.6809 | 0.6843 | **no** |
| sum_amount via row @ 10000 linhas | 1,362 | _not measured_ | 0.752 | 0.8253 | 0.8264 | **no** |
| group_by_category via row @ 10000 linhas | 566.7 | _not measured_ | 1.773 | 1.99 | 2.009 | **no** |
| filtered_sum via row @ 10000 linhas | 1,131 | _not measured_ | 0.9341 | 1.015 | 1.016 | **no** |
| numeric_filtered_sum via row @ 10000 linhas | 1,275 | _not measured_ | 0.8149 | 0.9061 | 0.9065 | **no** |
| total_rows via columnar @ 10000 linhas | 1,111 | _not measured_ | 0.9485 | 1.138 | 1.154 | **no** |
| sum_amount via columnar @ 10000 linhas | 963.2 | _not measured_ | 1.046 | 1.323 | 1.347 | **no** |
| group_by_category via columnar @ 10000 linhas | 451.3 | _not measured_ | 2.344 | 2.569 | 2.572 | **no** |
| filtered_sum via columnar @ 10000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 10000 linhas | 641.4 | _not measured_ | 1.572 | 1.798 | 1.818 | **no** |
| total_rows via parquet @ 10000 linhas | 37.39 | _not measured_ | 29.46 | 30.95 | 31.01 | yes |
| sum_amount via parquet @ 10000 linhas | 34.22 | _not measured_ | 30.61 | 32.81 | 33 | yes |
| group_by_category via parquet @ 10000 linhas | 30.78 | _not measured_ | 34.51 | 34.98 | 35.01 | yes |
| filtered_sum via parquet @ 10000 linhas | 34.66 | _not measured_ | 28.96 | 30.93 | 31.12 | **no** |
| numeric_filtered_sum via parquet @ 10000 linhas | 34.03 | _not measured_ | 32.07 | 32.21 | 32.26 | yes |
| total_rows via row @ 50000 linhas | 386.8 | _not measured_ | 2.635 | 2.793 | 2.807 | yes |
| sum_amount via row @ 50000 linhas | 315.9 | _not measured_ | 3.281 | 3.315 | 3.318 | yes |
| group_by_category via row @ 50000 linhas | 120.5 | _not measured_ | 8.359 | 8.544 | 8.56 | yes |
| filtered_sum via row @ 50000 linhas | 248.8 | _not measured_ | 4.089 | 4.151 | 4.159 | yes |
| numeric_filtered_sum via row @ 50000 linhas | 270.8 | _not measured_ | 3.698 | 3.729 | 3.73 | yes |
| total_rows via columnar @ 50000 linhas | 834.9 | _not measured_ | 1.241 | 1.302 | 1.311 | **no** |
| sum_amount via columnar @ 50000 linhas | 571.8 | _not measured_ | 1.847 | 1.881 | 1.884 | yes |
| group_by_category via columnar @ 50000 linhas | 132.9 | _not measured_ | 7.706 | 7.732 | 7.734 | yes |
| filtered_sum via columnar @ 50000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 50000 linhas | 363 | _not measured_ | 2.799 | 3.006 | 3.025 | **no** |
| total_rows via parquet @ 50000 linhas | 6.579 | _not measured_ | 152.8 | 153.6 | 153.7 | **no** |
| sum_amount via parquet @ 50000 linhas | 5.968 | _not measured_ | 169.2 | 169.8 | 169.8 | yes |
| group_by_category via parquet @ 50000 linhas | 5.678 | _not measured_ | 176.4 | 176.6 | 176.7 | yes |
| filtered_sum via parquet @ 50000 linhas | 6.197 | _not measured_ | 161.6 | 161.7 | 161.7 | yes |
| numeric_filtered_sum via parquet @ 50000 linhas | 6.115 | _not measured_ | 163.6 | 164.8 | 164.8 | yes |
| total_rows via row @ 100000 linhas | 184.5 | _not measured_ | 5.507 | 5.675 | 5.69 | yes |
| sum_amount via row @ 100000 linhas | 146.4 | _not measured_ | 6.833 | 6.897 | 6.903 | yes |
| group_by_category via row @ 100000 linhas | 58.58 | _not measured_ | 17.47 | 17.57 | 17.58 | yes |
| filtered_sum via row @ 100000 linhas | 116.8 | _not measured_ | 8.598 | 8.665 | 8.674 | yes |
| numeric_filtered_sum via row @ 100000 linhas | 129.5 | _not measured_ | 7.9 | 8.008 | 8.016 | yes |
| total_rows via columnar @ 100000 linhas | 602.7 | _not measured_ | 1.736 | 2.286 | 2.335 | **no** |
| sum_amount via columnar @ 100000 linhas | 368.9 | _not measured_ | 2.871 | 2.887 | 2.887 | **no** |
| group_by_category via columnar @ 100000 linhas | 69.45 | _not measured_ | 14.54 | 14.64 | 14.64 | yes |
| filtered_sum via columnar @ 100000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 100000 linhas | 227.9 | _not measured_ | 4.448 | 4.616 | 4.631 | yes |
| total_rows via parquet @ 100000 linhas | 3.3 | _not measured_ | 304.4 | 304.7 | 304.7 | yes |
| sum_amount via parquet @ 100000 linhas | 3.008 | _not measured_ | 334.2 | 342.1 | 342.2 | yes |
| group_by_category via parquet @ 100000 linhas | 2.882 | _not measured_ | 353.8 | 355.9 | 356.1 | yes |
| filtered_sum via parquet @ 100000 linhas | 3.089 | _not measured_ | 325.3 | 325.6 | 325.6 | yes |
| numeric_filtered_sum via parquet @ 100000 linhas | 3.035 | _not measured_ | 330.4 | 331.3 | 331.3 | yes |
| total_rows via row @ 500000 linhas | 55.3 | _not measured_ | 18.56 | 21.23 | 21.23 | **no** |
| sum_amount via row @ 500000 linhas | 46.19 | _not measured_ | 21.99 | 22.2 | 22.22 | **no** |
| group_by_category via row @ 500000 linhas | 24.8 | _not measured_ | 41.41 | 41.87 | 41.91 | **no** |
| filtered_sum via row @ 500000 linhas | 39.24 | _not measured_ | 25.83 | 25.95 | 25.96 | yes |
| numeric_filtered_sum via row @ 500000 linhas | 41.59 | _not measured_ | 25.23 | 25.69 | 25.73 | **no** |
| total_rows via columnar @ 500000 linhas | 176.4 | _not measured_ | 5.887 | 5.91 | 5.913 | **no** |
| sum_amount via columnar @ 500000 linhas | 93.91 | _not measured_ | 10.98 | 11.59 | 11.65 | **no** |
| group_by_category via columnar @ 500000 linhas | 15.15 | _not measured_ | 66.56 | 66.69 | 66.7 | yes |
| filtered_sum via columnar @ 500000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 500000 linhas | 58.27 | _not measured_ | 17.21 | 17.22 | 17.22 | **no** |
| total_rows via parquet @ 500000 linhas | 0.6583 | _not measured_ | 1,526 | 1,527 | 1,527 | yes |
| sum_amount via parquet @ 500000 linhas | 0.5958 | _not measured_ | 1,696 | 1,706 | 1,707 | yes |
| group_by_category via parquet @ 500000 linhas | 0.5549 | _not measured_ | 1,808 | 1,819 | 1,819 | yes |
| filtered_sum via parquet @ 500000 linhas | 0.618 | _not measured_ | 1,620 | 1,636 | 1,638 | yes |
| numeric_filtered_sum via parquet @ 500000 linhas | 0.6116 | _not measured_ | 1,645 | 1,654 | 1,654 | yes |
| total_rows via row @ 1000000 linhas | 35.75 | _not measured_ | 33.77 | 33.97 | 33.99 | **no** |
| sum_amount via row @ 1000000 linhas | 26.39 | _not measured_ | 38.81 | 38.86 | 38.87 | **no** |
| group_by_category via row @ 1000000 linhas | 14.51 | _not measured_ | 69.04 | 69.59 | 69.66 | yes |
| filtered_sum via row @ 1000000 linhas | 24.05 | _not measured_ | 41.63 | 42.82 | 42.94 | yes |
| numeric_filtered_sum via row @ 1000000 linhas | 26.28 | _not measured_ | 38.44 | 38.55 | 38.55 | yes |
| total_rows via columnar @ 1000000 linhas | 110.6 | _not measured_ | 9.129 | 9.226 | 9.234 | yes |
| sum_amount via columnar @ 1000000 linhas | 50.03 | _not measured_ | 20.12 | 20.14 | 20.14 | yes |
| group_by_category via columnar @ 1000000 linhas | 7.66 | _not measured_ | 133.1 | 133.4 | 133.4 | yes |
| filtered_sum via columnar @ 1000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 1000000 linhas | 30.48 | _not measured_ | 33.01 | 33.09 | 33.1 | yes |
| total_rows via parquet @ 1000000 linhas | 0.3328 | _not measured_ | 3,064 | 3,102 | 3,105 | yes |
| sum_amount via parquet @ 1000000 linhas | 0.3005 | _not measured_ | 3,332 | 3,349 | 3,351 | yes |
| group_by_category via parquet @ 1000000 linhas | 0.2827 | _not measured_ | 3,563 | 3,574 | 3,575 | yes |
| filtered_sum via parquet @ 1000000 linhas | 0.3035 | _not measured_ | 3,296 | 3,321 | 3,321 | yes |
| numeric_filtered_sum via parquet @ 1000000 linhas | 0.3031 | _not measured_ | 3,338 | 3,350 | 3,351 | yes |
| total_rows via row @ 2000000 linhas | 23.15 | _not measured_ | 43.29 | 43.83 | 43.88 | **no** |
| sum_amount via row @ 2000000 linhas | 17.83 | _not measured_ | 56.16 | 56.45 | 56.48 | **no** |
| group_by_category via row @ 2000000 linhas | 8.148 | _not measured_ | 123.4 | 123.8 | 123.8 | yes |
| filtered_sum via row @ 2000000 linhas | 14.57 | _not measured_ | 69.07 | 69.14 | 69.19 | **no** |
| numeric_filtered_sum via row @ 2000000 linhas | 15.94 | _not measured_ | 63.45 | 71.28 | 71.41 | **no** |
| total_rows via columnar @ 2000000 linhas | 57.03 | _not measured_ | 17.75 | 17.89 | 17.9 | **no** |
| sum_amount via columnar @ 2000000 linhas | 26.71 | _not measured_ | 38.03 | 49.7 | 50.74 | **no** |
| group_by_category via columnar @ 2000000 linhas | 3.835 | _not measured_ | 266 | 266.7 | 266.7 | **no** |
| filtered_sum via columnar @ 2000000 linhas | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar @ 2000000 linhas | 15.96 | _not measured_ | 63.41 | 64.66 | 64.77 | yes |
| total_rows via parquet @ 2000000 linhas | 0.1597 | _not measured_ | 6,326 | 6,374 | 6,379 | yes |
| sum_amount via parquet @ 2000000 linhas | 0.145 | _not measured_ | 7,019 | 7,031 | 7,032 | yes |
| group_by_category via parquet @ 2000000 linhas | 0.1375 | _not measured_ | 7,319 | 7,332 | 7,333 | yes |
| filtered_sum via parquet @ 2000000 linhas | 0.1483 | _not measured_ | 6,819 | 6,859 | 6,863 | yes |
| numeric_filtered_sum via parquet @ 2000000 linhas | 0.1479 | _not measured_ | 6,796 | 6,904 | 6,911 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `total_rows via row @ 10000 linhas`: latency_p50_ms cv=0.054; latency_p95_ms cv=0.087; latency_p99_ms cv=0.090
- `sum_amount via row @ 10000 linhas`: latency_p50_ms cv=0.053; latency_p95_ms cv=0.075; latency_p99_ms cv=0.080
- `group_by_category via row @ 10000 linhas`: latency_p50_ms cv=0.116; latency_p95_ms cv=0.102; latency_p99_ms cv=0.102; throughput_per_second cv=0.081
- `filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.076; latency_p95_ms cv=0.077; latency_p99_ms cv=0.079; throughput_per_second cv=0.081
- `numeric_filtered_sum via row @ 10000 linhas`: latency_p50_ms cv=0.070; latency_p95_ms cv=0.119; latency_p99_ms cv=0.127; throughput_per_second cv=0.057
- `total_rows via columnar @ 10000 linhas`: latency_p50_ms cv=0.132; latency_p95_ms cv=0.153; latency_p99_ms cv=0.154; throughput_per_second cv=0.138
- `sum_amount via columnar @ 10000 linhas`: latency_p50_ms cv=0.164; latency_p95_ms cv=0.150; latency_p99_ms cv=0.153; throughput_per_second cv=0.157
- `group_by_category via columnar @ 10000 linhas`: latency_p50_ms cv=0.077; latency_p95_ms cv=0.080; latency_p99_ms cv=0.081; throughput_per_second cv=0.071
- `numeric_filtered_sum via columnar @ 10000 linhas`: latency_p50_ms cv=0.084; latency_p95_ms cv=0.112; latency_p99_ms cv=0.116; throughput_per_second cv=0.106
- `filtered_sum via parquet @ 10000 linhas`: latency_p50_ms cv=0.055; throughput_per_second cv=0.054
- `total_rows via columnar @ 50000 linhas`: latency_p50_ms cv=0.092; latency_p95_ms cv=0.278; latency_p99_ms cv=0.292
- `numeric_filtered_sum via columnar @ 50000 linhas`: latency_p50_ms cv=0.070; latency_p95_ms cv=0.129; latency_p99_ms cv=0.134; throughput_per_second cv=0.061
- `total_rows via parquet @ 50000 linhas`: latency_p95_ms cv=0.069; latency_p99_ms cv=0.073
- `total_rows via columnar @ 100000 linhas`: latency_p50_ms cv=0.115; latency_p95_ms cv=0.173; latency_p99_ms cv=0.177; throughput_per_second cv=0.061
- `sum_amount via columnar @ 100000 linhas`: latency_p50_ms cv=0.056
- `total_rows via row @ 500000 linhas`: latency_p50_ms cv=0.089; latency_p95_ms cv=0.112; latency_p99_ms cv=0.119; throughput_per_second cv=0.091
- `sum_amount via row @ 500000 linhas`: latency_p50_ms cv=0.052; latency_p95_ms cv=0.051; latency_p99_ms cv=0.051; throughput_per_second cv=0.056
- `group_by_category via row @ 500000 linhas`: latency_p95_ms cv=0.131; latency_p99_ms cv=0.139
- `numeric_filtered_sum via row @ 500000 linhas`: latency_p95_ms cv=0.127; latency_p99_ms cv=0.135
- `total_rows via columnar @ 500000 linhas`: latency_p50_ms cv=0.194; latency_p95_ms cv=0.182; latency_p99_ms cv=0.181; throughput_per_second cv=0.179
- `sum_amount via columnar @ 500000 linhas`: latency_p50_ms cv=0.221; latency_p95_ms cv=0.210; latency_p99_ms cv=0.209; throughput_per_second cv=0.205
- `numeric_filtered_sum via columnar @ 500000 linhas`: latency_p50_ms cv=0.067; latency_p95_ms cv=0.078; latency_p99_ms cv=0.079
- `total_rows via row @ 1000000 linhas`: latency_p50_ms cv=0.110; latency_p95_ms cv=0.111; latency_p99_ms cv=0.111; throughput_per_second cv=0.111
- `sum_amount via row @ 1000000 linhas`: latency_p50_ms cv=0.128; latency_p95_ms cv=0.130; latency_p99_ms cv=0.130; throughput_per_second cv=0.129
- `total_rows via row @ 2000000 linhas`: latency_p50_ms cv=0.140; latency_p95_ms cv=0.259; latency_p99_ms cv=0.268; throughput_per_second cv=0.128
- `sum_amount via row @ 2000000 linhas`: latency_p50_ms cv=0.078; latency_p95_ms cv=0.077; latency_p99_ms cv=0.077; throughput_per_second cv=0.075
- `filtered_sum via row @ 2000000 linhas`: latency_p95_ms cv=0.053; latency_p99_ms cv=0.053
- `numeric_filtered_sum via row @ 2000000 linhas`: latency_p50_ms cv=0.064; latency_p95_ms cv=0.124; latency_p99_ms cv=0.133; throughput_per_second cv=0.062
- `total_rows via columnar @ 2000000 linhas`: latency_p50_ms cv=0.226; latency_p95_ms cv=0.225; latency_p99_ms cv=0.225; throughput_per_second cv=0.202
- `sum_amount via columnar @ 2000000 linhas`: latency_p95_ms cv=0.155; latency_p99_ms cv=0.165
- `group_by_category via columnar @ 2000000 linhas`: latency_p95_ms cv=0.053; latency_p99_ms cv=0.054

### Repetitions

Every repetition is retained:

- `total_rows via row @ 10000 linhas` latency_p50_ms: 0.6967, 0.6305, 0.6421
- `total_rows via row @ 10000 linhas` latency_p95_ms: 0.7571, 0.6381, 0.6809
- `total_rows via row @ 10000 linhas` latency_p99_ms: 0.7624, 0.6388, 0.6843
- `total_rows via row @ 10000 linhas` throughput_per_second: 1,570, 1,712, 1,680
- `sum_amount via row @ 10000 linhas` latency_p50_ms: 0.8126, 0.752, 0.7362
- `sum_amount via row @ 10000 linhas` latency_p95_ms: 0.8253, 0.8834, 0.7605
- `sum_amount via row @ 10000 linhas` latency_p99_ms: 0.8264, 0.8951, 0.7626
- `sum_amount via row @ 10000 linhas` throughput_per_second: 1,288, 1,407, 1,362
- `group_by_category via row @ 10000 linhas` latency_p50_ms: 2.144, 1.773, 1.754
- `group_by_category via row @ 10000 linhas` latency_p95_ms: 2.181, 1.99, 1.778
- `group_by_category via row @ 10000 linhas` latency_p99_ms: 2.184, 2.009, 1.78
- `group_by_category via row @ 10000 linhas` throughput_per_second: 499.3, 566.7, 583.5
- `filtered_sum via row @ 10000 linhas` latency_p50_ms: 1.002, 0.9341, 0.8599
- `filtered_sum via row @ 10000 linhas` latency_p95_ms: 1.015, 1.032, 0.8931
- `filtered_sum via row @ 10000 linhas` latency_p99_ms: 1.016, 1.041, 0.8961
- `filtered_sum via row @ 10000 linhas` throughput_per_second: 1,017, 1,131, 1,196
- `numeric_filtered_sum via row @ 10000 linhas` latency_p50_ms: 0.9008, 0.8149, 0.7883
- `numeric_filtered_sum via row @ 10000 linhas` latency_p95_ms: 0.9061, 1.001, 0.7885
- `numeric_filtered_sum via row @ 10000 linhas` latency_p99_ms: 0.9065, 1.018, 0.7885
- `numeric_filtered_sum via row @ 10000 linhas` throughput_per_second: 1,161, 1,293, 1,275
- `total_rows via columnar @ 10000 linhas` latency_p50_ms: 1.131, 0.9485, 0.8794
- `total_rows via columnar @ 10000 linhas` latency_p95_ms: 1.382, 1.138, 1.029
- `total_rows via columnar @ 10000 linhas` latency_p99_ms: 1.404, 1.154, 1.042
- `total_rows via columnar @ 10000 linhas` throughput_per_second: 886.9, 1,111, 1,158
- `sum_amount via columnar @ 10000 linhas` latency_p50_ms: 1.367, 1.046, 1.034
- `sum_amount via columnar @ 10000 linhas` latency_p95_ms: 1.392, 1.323, 1.039
- `sum_amount via columnar @ 10000 linhas` latency_p99_ms: 1.394, 1.347, 1.039
- `sum_amount via columnar @ 10000 linhas` throughput_per_second: 733.4, 963.2, 989.6
- `group_by_category via columnar @ 10000 linhas` latency_p50_ms: 2.542, 2.344, 2.18
- `group_by_category via columnar @ 10000 linhas` latency_p95_ms: 2.569, 2.604, 2.247
- `group_by_category via columnar @ 10000 linhas` latency_p99_ms: 2.572, 2.628, 2.253
- `group_by_category via columnar @ 10000 linhas` throughput_per_second: 401.6, 451.3, 458.8
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p50_ms: 1.805, 1.572, 1.557
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p95_ms: 1.983, 1.798, 1.581
- `numeric_filtered_sum via columnar @ 10000 linhas` latency_p99_ms: 1.999, 1.818, 1.583
- `numeric_filtered_sum via columnar @ 10000 linhas` throughput_per_second: 566, 641.4, 699.8
- `total_rows via parquet @ 10000 linhas` latency_p50_ms: 27.59, 30.22, 29.46
- `total_rows via parquet @ 10000 linhas` latency_p95_ms: 29.47, 30.95, 32.43
- `total_rows via parquet @ 10000 linhas` latency_p99_ms: 29.64, 31.01, 32.69
- `total_rows via parquet @ 10000 linhas` throughput_per_second: 37.56, 37.39, 37.03
- `sum_amount via parquet @ 10000 linhas` latency_p50_ms: 30.61, 32.27, 29.66
- `sum_amount via parquet @ 10000 linhas` latency_p95_ms: 32.81, 32.96, 31.83
- `sum_amount via parquet @ 10000 linhas` latency_p99_ms: 33, 33.02, 32.02
- `sum_amount via parquet @ 10000 linhas` throughput_per_second: 32.8, 34.69, 34.22
- `group_by_category via parquet @ 10000 linhas` latency_p50_ms: 33.05, 34.55, 34.51
- `group_by_category via parquet @ 10000 linhas` latency_p95_ms: 35.32, 34.98, 34.71
- `group_by_category via parquet @ 10000 linhas` latency_p99_ms: 35.52, 35.01, 34.72
- `group_by_category via parquet @ 10000 linhas` throughput_per_second: 30.78, 28.96, 31.32
- `filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 28.96, 31.78, 28.87
- `filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 29.85, 32.14, 30.93
- `filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 29.93, 32.17, 31.12
- `filtered_sum via parquet @ 10000 linhas` throughput_per_second: 34.66, 31.59, 34.86
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p50_ms: 32.23, 32.07, 31.64
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p95_ms: 32.39, 32.14, 32.21
- `numeric_filtered_sum via parquet @ 10000 linhas` latency_p99_ms: 32.4, 32.15, 32.26
- `numeric_filtered_sum via parquet @ 10000 linhas` throughput_per_second: 31.35, 34.03, 34.18
- `total_rows via row @ 50000 linhas` latency_p50_ms: 2.635, 2.681, 2.633
- `total_rows via row @ 50000 linhas` latency_p95_ms: 2.706, 2.882, 2.793
- `total_rows via row @ 50000 linhas` latency_p99_ms: 2.712, 2.9, 2.807
- `total_rows via row @ 50000 linhas` throughput_per_second: 390.3, 386.1, 386.8
- `sum_amount via row @ 50000 linhas` latency_p50_ms: 3.281, 3.337, 3.188
- `sum_amount via row @ 50000 linhas` latency_p95_ms: 3.315, 3.342, 3.199
- `sum_amount via row @ 50000 linhas` latency_p99_ms: 3.318, 3.343, 3.2
- `sum_amount via row @ 50000 linhas` throughput_per_second: 320.1, 302.3, 315.9
- `group_by_category via row @ 50000 linhas` latency_p50_ms: 8.334, 8.637, 8.359
- `group_by_category via row @ 50000 linhas` latency_p95_ms: 8.504, 8.814, 8.544
- `group_by_category via row @ 50000 linhas` latency_p99_ms: 8.519, 8.829, 8.56
- `group_by_category via row @ 50000 linhas` throughput_per_second: 121.2, 117, 120.5
- `filtered_sum via row @ 50000 linhas` latency_p50_ms: 4.089, 4.218, 4.059
- `filtered_sum via row @ 50000 linhas` latency_p95_ms: 4.109, 4.224, 4.151
- `filtered_sum via row @ 50000 linhas` latency_p99_ms: 4.111, 4.225, 4.159
- `filtered_sum via row @ 50000 linhas` throughput_per_second: 249.2, 237.5, 248.8
- `numeric_filtered_sum via row @ 50000 linhas` latency_p50_ms: 3.698, 3.728, 3.595
- `numeric_filtered_sum via row @ 50000 linhas` latency_p95_ms: 3.727, 3.729, 3.738
- `numeric_filtered_sum via row @ 50000 linhas` latency_p99_ms: 3.73, 3.73, 3.751
- `numeric_filtered_sum via row @ 50000 linhas` throughput_per_second: 270.8, 268.4, 279.1
- `total_rows via columnar @ 50000 linhas` latency_p50_ms: 1.201, 1.424, 1.241
- `total_rows via columnar @ 50000 linhas` latency_p95_ms: 1.302, 2.043, 1.293
- `total_rows via columnar @ 50000 linhas` latency_p99_ms: 1.311, 2.098, 1.297
- `total_rows via columnar @ 50000 linhas` throughput_per_second: 863.3, 796, 834.9
- `sum_amount via columnar @ 50000 linhas` latency_p50_ms: 1.847, 1.954, 1.779
- `sum_amount via columnar @ 50000 linhas` latency_p95_ms: 1.881, 1.978, 1.805
- `sum_amount via columnar @ 50000 linhas` latency_p99_ms: 1.884, 1.98, 1.807
- `sum_amount via columnar @ 50000 linhas` throughput_per_second: 575.4, 527, 571.8
- `group_by_category via columnar @ 50000 linhas` latency_p50_ms: 7.706, 7.872, 7.609
- `group_by_category via columnar @ 50000 linhas` latency_p95_ms: 7.732, 7.954, 7.679
- `group_by_category via columnar @ 50000 linhas` latency_p99_ms: 7.734, 7.961, 7.685
- `group_by_category via columnar @ 50000 linhas` throughput_per_second: 133.1, 128.8, 132.9
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p50_ms: 2.738, 3.113, 2.799
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p95_ms: 2.793, 3.572, 3.006
- `numeric_filtered_sum via columnar @ 50000 linhas` latency_p99_ms: 2.797, 3.613, 3.025
- `numeric_filtered_sum via columnar @ 50000 linhas` throughput_per_second: 371.8, 330.5, 363
- `total_rows via parquet @ 50000 linhas` latency_p50_ms: 149.7, 155.4, 152.8
- `total_rows via parquet @ 50000 linhas` latency_p95_ms: 150.5, 170.7, 153.6
- `total_rows via parquet @ 50000 linhas` latency_p99_ms: 150.6, 172, 153.7
- `total_rows via parquet @ 50000 linhas` throughput_per_second: 6.685, 6.466, 6.579
- `sum_amount via parquet @ 50000 linhas` latency_p50_ms: 165.4, 169.2, 170.3
- `sum_amount via parquet @ 50000 linhas` latency_p95_ms: 165.5, 169.8, 170.3
- `sum_amount via parquet @ 50000 linhas` latency_p99_ms: 165.5, 169.8, 170.3
- `sum_amount via parquet @ 50000 linhas` throughput_per_second: 6.046, 5.917, 5.968
- `group_by_category via parquet @ 50000 linhas` latency_p50_ms: 174.8, 176.4, 180.2
- `group_by_category via parquet @ 50000 linhas` latency_p95_ms: 176.5, 176.6, 180.5
- `group_by_category via parquet @ 50000 linhas` latency_p99_ms: 176.7, 176.6, 180.5
- `group_by_category via parquet @ 50000 linhas` throughput_per_second: 5.731, 5.678, 5.551
- `filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 160.9, 161.6, 163
- `filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 161.5, 161.7, 164
- `filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 161.5, 161.7, 164
- `filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.219, 6.197, 6.156
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p50_ms: 163.3, 163.6, 164.8
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p95_ms: 166.9, 163.8, 164.8
- `numeric_filtered_sum via parquet @ 50000 linhas` latency_p99_ms: 167.2, 163.8, 164.8
- `numeric_filtered_sum via parquet @ 50000 linhas` throughput_per_second: 6.128, 6.115, 6.093
- `total_rows via row @ 100000 linhas` latency_p50_ms: 5.405, 5.507, 5.715
- `total_rows via row @ 100000 linhas` latency_p95_ms: 5.552, 5.675, 5.812
- `total_rows via row @ 100000 linhas` latency_p99_ms: 5.565, 5.69, 5.821
- `total_rows via row @ 100000 linhas` throughput_per_second: 187.7, 184.5, 177.8
- `sum_amount via row @ 100000 linhas` latency_p50_ms: 6.673, 6.833, 7.058
- `sum_amount via row @ 100000 linhas` latency_p95_ms: 6.697, 6.897, 7.067
- `sum_amount via row @ 100000 linhas` latency_p99_ms: 6.7, 6.903, 7.068
- `sum_amount via row @ 100000 linhas` throughput_per_second: 150.4, 146.4, 141.9
- `group_by_category via row @ 100000 linhas` latency_p50_ms: 17.06, 17.47, 17.73
- `group_by_category via row @ 100000 linhas` latency_p95_ms: 17.25, 17.57, 17.75
- `group_by_category via row @ 100000 linhas` latency_p99_ms: 17.26, 17.58, 17.75
- `group_by_category via row @ 100000 linhas` throughput_per_second: 58.85, 58.58, 56.44
- `filtered_sum via row @ 100000 linhas` latency_p50_ms: 8.562, 8.598, 9.02
- `filtered_sum via row @ 100000 linhas` latency_p95_ms: 8.665, 8.606, 9.05
- `filtered_sum via row @ 100000 linhas` latency_p99_ms: 8.674, 8.607, 9.052
- `filtered_sum via row @ 100000 linhas` throughput_per_second: 116.8, 118.6, 113.4
- `numeric_filtered_sum via row @ 100000 linhas` latency_p50_ms: 7.645, 7.9, 7.913
- `numeric_filtered_sum via row @ 100000 linhas` latency_p95_ms: 7.664, 8.03, 8.008
- `numeric_filtered_sum via row @ 100000 linhas` latency_p99_ms: 7.665, 8.042, 8.016
- `numeric_filtered_sum via row @ 100000 linhas` throughput_per_second: 131.6, 128.7, 129.5
- `total_rows via columnar @ 100000 linhas` latency_p50_ms: 1.539, 1.938, 1.736
- `total_rows via columnar @ 100000 linhas` latency_p95_ms: 1.746, 2.466, 2.286
- `total_rows via columnar @ 100000 linhas` latency_p99_ms: 1.764, 2.513, 2.335
- `total_rows via columnar @ 100000 linhas` throughput_per_second: 658.5, 586.3, 602.7
- `sum_amount via columnar @ 100000 linhas` latency_p50_ms: 2.606, 2.879, 2.871
- `sum_amount via columnar @ 100000 linhas` latency_p95_ms: 2.749, 2.887, 2.897
- `sum_amount via columnar @ 100000 linhas` latency_p99_ms: 2.762, 2.887, 2.899
- `sum_amount via columnar @ 100000 linhas` throughput_per_second: 386.7, 368.9, 356.1
- `group_by_category via columnar @ 100000 linhas` latency_p50_ms: 14.18, 14.58, 14.54
- `group_by_category via columnar @ 100000 linhas` latency_p95_ms: 14.21, 14.64, 14.65
- `group_by_category via columnar @ 100000 linhas` latency_p99_ms: 14.21, 14.64, 14.66
- `group_by_category via columnar @ 100000 linhas` throughput_per_second: 70.59, 69.45, 68.95
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p50_ms: 4.397, 4.448, 4.533
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p95_ms: 4.449, 4.616, 4.629
- `numeric_filtered_sum via columnar @ 100000 linhas` latency_p99_ms: 4.454, 4.631, 4.638
- `numeric_filtered_sum via columnar @ 100000 linhas` throughput_per_second: 227.9, 228.9, 222.7
- `total_rows via parquet @ 100000 linhas` latency_p50_ms: 305.4, 299.1, 304.4
- `total_rows via parquet @ 100000 linhas` latency_p95_ms: 306.3, 301.4, 304.7
- `total_rows via parquet @ 100000 linhas` latency_p99_ms: 306.4, 301.6, 304.7
- `total_rows via parquet @ 100000 linhas` throughput_per_second: 3.276, 3.362, 3.3
- `sum_amount via parquet @ 100000 linhas` latency_p50_ms: 334.2, 340.6, 331.8
- `sum_amount via parquet @ 100000 linhas` latency_p95_ms: 350.7, 342.1, 337.7
- `sum_amount via parquet @ 100000 linhas` latency_p99_ms: 352.2, 342.2, 338.2
- `sum_amount via parquet @ 100000 linhas` throughput_per_second: 3.008, 3.006, 3.029
- `group_by_category via parquet @ 100000 linhas` latency_p50_ms: 347.7, 353.8, 359.5
- `group_by_category via parquet @ 100000 linhas` latency_p95_ms: 349.8, 355.9, 362.9
- `group_by_category via parquet @ 100000 linhas` latency_p99_ms: 350, 356.1, 363.2
- `group_by_category via parquet @ 100000 linhas` throughput_per_second: 2.882, 2.827, 2.884
- `filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 322, 325.3, 326.3
- `filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 323.6, 325.6, 326.6
- `filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 323.8, 325.6, 326.6
- `filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.114, 3.084, 3.089
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p50_ms: 328.9, 334.2, 330.4
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p95_ms: 330, 336.4, 331.3
- `numeric_filtered_sum via parquet @ 100000 linhas` latency_p99_ms: 330.1, 336.6, 331.3
- `numeric_filtered_sum via parquet @ 100000 linhas` throughput_per_second: 3.053, 3.004, 3.035
- `total_rows via row @ 500000 linhas` latency_p50_ms: 21.19, 17.98, 18.56
- `total_rows via row @ 500000 linhas` latency_p95_ms: 21.23, 18.05, 22.55
- `total_rows via row @ 500000 linhas` latency_p99_ms: 21.23, 18.05, 22.91
- `total_rows via row @ 500000 linhas` throughput_per_second: 47.3, 56.01, 55.3
- `sum_amount via row @ 500000 linhas` latency_p50_ms: 23.9, 21.99, 21.79
- `sum_amount via row @ 500000 linhas` latency_p95_ms: 24.02, 22.2, 21.88
- `sum_amount via row @ 500000 linhas` latency_p99_ms: 24.03, 22.22, 21.89
- `sum_amount via row @ 500000 linhas` throughput_per_second: 42.26, 47, 46.19
- `group_by_category via row @ 500000 linhas` latency_p50_ms: 41.41, 39.67, 43.25
- `group_by_category via row @ 500000 linhas` latency_p95_ms: 41.87, 39.79, 50.69
- `group_by_category via row @ 500000 linhas` latency_p99_ms: 41.91, 39.8, 51.35
- `group_by_category via row @ 500000 linhas` throughput_per_second: 24.22, 25.46, 24.8
- `filtered_sum via row @ 500000 linhas` latency_p50_ms: 26.98, 25.17, 25.83
- `filtered_sum via row @ 500000 linhas` latency_p95_ms: 27.15, 25.22, 25.95
- `filtered_sum via row @ 500000 linhas` latency_p99_ms: 27.16, 25.22, 25.96
- `filtered_sum via row @ 500000 linhas` throughput_per_second: 37.13, 39.75, 39.24
- `numeric_filtered_sum via row @ 500000 linhas` latency_p50_ms: 25.24, 25.23, 23.32
- `numeric_filtered_sum via row @ 500000 linhas` latency_p95_ms: 29.93, 25.69, 23.34
- `numeric_filtered_sum via row @ 500000 linhas` latency_p99_ms: 30.34, 25.73, 23.34
- `numeric_filtered_sum via row @ 500000 linhas` throughput_per_second: 39.91, 41.59, 43.24
- `total_rows via columnar @ 500000 linhas` latency_p50_ms: 5.887, 7.071, 4.781
- `total_rows via columnar @ 500000 linhas` latency_p95_ms: 5.91, 7.116, 4.941
- `total_rows via columnar @ 500000 linhas` latency_p99_ms: 5.913, 7.119, 4.955
- `total_rows via columnar @ 500000 linhas` throughput_per_second: 176.4, 146.6, 210.3
- `sum_amount via columnar @ 500000 linhas` latency_p50_ms: 10.98, 15.17, 10.17
- `sum_amount via columnar @ 500000 linhas` latency_p95_ms: 11.59, 15.2, 10.19
- `sum_amount via columnar @ 500000 linhas` latency_p99_ms: 11.65, 15.21, 10.19
- `sum_amount via columnar @ 500000 linhas` throughput_per_second: 93.91, 66.15, 99.16
- `group_by_category via columnar @ 500000 linhas` latency_p50_ms: 65.83, 69.47, 66.56
- `group_by_category via columnar @ 500000 linhas` latency_p95_ms: 66, 70.32, 66.69
- `group_by_category via columnar @ 500000 linhas` latency_p99_ms: 66.02, 70.39, 66.7
- `group_by_category via columnar @ 500000 linhas` throughput_per_second: 15.19, 15.11, 15.15
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p50_ms: 16.86, 17.21, 19.07
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p95_ms: 16.98, 17.22, 19.52
- `numeric_filtered_sum via columnar @ 500000 linhas` latency_p99_ms: 17, 17.22, 19.56
- `numeric_filtered_sum via columnar @ 500000 linhas` throughput_per_second: 59.96, 58.27, 57.86
- `total_rows via parquet @ 500000 linhas` latency_p50_ms: 1,506, 1,526, 1,531
- `total_rows via parquet @ 500000 linhas` latency_p95_ms: 1,517, 1,527, 1,537
- `total_rows via parquet @ 500000 linhas` latency_p99_ms: 1,518, 1,527, 1,538
- `total_rows via parquet @ 500000 linhas` throughput_per_second: 0.6743, 0.6583, 0.6552
- `sum_amount via parquet @ 500000 linhas` latency_p50_ms: 1,696, 1,691, 1,710
- `sum_amount via parquet @ 500000 linhas` latency_p95_ms: 1,704, 1,706, 1,716
- `sum_amount via parquet @ 500000 linhas` latency_p99_ms: 1,705, 1,707, 1,717
- `sum_amount via parquet @ 500000 linhas` throughput_per_second: 0.5958, 0.5972, 0.5934
- `group_by_category via parquet @ 500000 linhas` latency_p50_ms: 1,773, 1,808, 1,817
- `group_by_category via parquet @ 500000 linhas` latency_p95_ms: 1,776, 1,827, 1,819
- `group_by_category via parquet @ 500000 linhas` latency_p99_ms: 1,777, 1,829, 1,819
- `group_by_category via parquet @ 500000 linhas` throughput_per_second: 0.5689, 0.5536, 0.5549
- `filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,620, 1,607, 1,663
- `filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,626, 1,636, 1,680
- `filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,627, 1,638, 1,681
- `filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.618, 0.6233, 0.6117
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p50_ms: 1,639, 1,665, 1,645
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p95_ms: 1,640, 1,676, 1,654
- `numeric_filtered_sum via parquet @ 500000 linhas` latency_p99_ms: 1,640, 1,677, 1,654
- `numeric_filtered_sum via parquet @ 500000 linhas` throughput_per_second: 0.6103, 0.6116, 0.6181
- `total_rows via row @ 1000000 linhas` latency_p50_ms: 33.77, 28, 34.38
- `total_rows via row @ 1000000 linhas` latency_p95_ms: 33.97, 28.06, 34.51
- `total_rows via row @ 1000000 linhas` latency_p99_ms: 33.99, 28.06, 34.52
- `total_rows via row @ 1000000 linhas` throughput_per_second: 29.85, 35.75, 36.89
- `sum_amount via row @ 1000000 linhas` latency_p50_ms: 38.81, 34.72, 44.77
- `sum_amount via row @ 1000000 linhas` latency_p95_ms: 38.86, 34.73, 44.94
- `sum_amount via row @ 1000000 linhas` latency_p99_ms: 38.87, 34.73, 44.95
- `sum_amount via row @ 1000000 linhas` throughput_per_second: 26.39, 29.11, 22.43
- `group_by_category via row @ 1000000 linhas` latency_p50_ms: 72.45, 68.83, 69.04
- `group_by_category via row @ 1000000 linhas` latency_p95_ms: 72.62, 69.59, 69.12
- `group_by_category via row @ 1000000 linhas` latency_p99_ms: 72.64, 69.66, 69.12
- `group_by_category via row @ 1000000 linhas` throughput_per_second: 13.82, 14.53, 14.51
- `filtered_sum via row @ 1000000 linhas` latency_p50_ms: 44.65, 41.63, 41.57
- `filtered_sum via row @ 1000000 linhas` latency_p95_ms: 44.79, 41.71, 42.82
- `filtered_sum via row @ 1000000 linhas` latency_p99_ms: 44.8, 41.72, 42.94
- `filtered_sum via row @ 1000000 linhas` throughput_per_second: 22.56, 24.05, 24.45
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p50_ms: 41.59, 38.44, 37.99
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p95_ms: 41.6, 38.55, 38.02
- `numeric_filtered_sum via row @ 1000000 linhas` latency_p99_ms: 41.6, 38.55, 38.02
- `numeric_filtered_sum via row @ 1000000 linhas` throughput_per_second: 24.22, 26.28, 26.51
- `total_rows via columnar @ 1000000 linhas` latency_p50_ms: 9.044, 9.267, 9.129
- `total_rows via columnar @ 1000000 linhas` latency_p95_ms: 9.128, 9.341, 9.226
- `total_rows via columnar @ 1000000 linhas` latency_p99_ms: 9.136, 9.348, 9.234
- `total_rows via columnar @ 1000000 linhas` throughput_per_second: 110.6, 109.3, 110.7
- `sum_amount via columnar @ 1000000 linhas` latency_p50_ms: 20.12, 20.48, 19.98
- `sum_amount via columnar @ 1000000 linhas` latency_p95_ms: 20.14, 20.74, 19.99
- `sum_amount via columnar @ 1000000 linhas` latency_p99_ms: 20.14, 20.76, 19.99
- `sum_amount via columnar @ 1000000 linhas` throughput_per_second: 50.03, 48.85, 51.13
- `group_by_category via columnar @ 1000000 linhas` latency_p50_ms: 133.1, 136.4, 129.8
- `group_by_category via columnar @ 1000000 linhas` latency_p95_ms: 133.4, 141.8, 132.3
- `group_by_category via columnar @ 1000000 linhas` latency_p99_ms: 133.4, 142.3, 132.5
- `group_by_category via columnar @ 1000000 linhas` throughput_per_second: 7.511, 7.66, 7.707
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p50_ms: 32.06, 33.07, 33.01
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p95_ms: 32.23, 33.15, 33.09
- `numeric_filtered_sum via columnar @ 1000000 linhas` latency_p99_ms: 32.25, 33.16, 33.1
- `numeric_filtered_sum via columnar @ 1000000 linhas` throughput_per_second: 31.21, 30.41, 30.48
- `total_rows via parquet @ 1000000 linhas` latency_p50_ms: 3,064, 3,031, 3,071
- `total_rows via parquet @ 1000000 linhas` latency_p95_ms: 3,066, 3,116, 3,102
- `total_rows via parquet @ 1000000 linhas` latency_p99_ms: 3,066, 3,124, 3,105
- `total_rows via parquet @ 1000000 linhas` throughput_per_second: 0.3328, 0.3329, 0.3257
- `sum_amount via parquet @ 1000000 linhas` latency_p50_ms: 3,320, 3,332, 3,381
- `sum_amount via parquet @ 1000000 linhas` latency_p95_ms: 3,349, 3,340, 3,412
- `sum_amount via parquet @ 1000000 linhas` latency_p99_ms: 3,351, 3,341, 3,415
- `sum_amount via parquet @ 1000000 linhas` throughput_per_second: 0.3012, 0.3005, 0.2978
- `group_by_category via parquet @ 1000000 linhas` latency_p50_ms: 3,563, 3,529, 3,565
- `group_by_category via parquet @ 1000000 linhas` latency_p95_ms: 3,599, 3,533, 3,574
- `group_by_category via parquet @ 1000000 linhas` latency_p99_ms: 3,603, 3,533, 3,575
- `group_by_category via parquet @ 1000000 linhas` throughput_per_second: 0.2827, 0.2838, 0.2825
- `filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,282, 3,296, 3,316
- `filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,324, 3,304, 3,321
- `filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,328, 3,305, 3,321
- `filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.3047, 0.3035, 0.303
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p50_ms: 3,331, 3,373, 3,338
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p95_ms: 3,340, 3,387, 3,350
- `numeric_filtered_sum via parquet @ 1000000 linhas` latency_p99_ms: 3,341, 3,388, 3,351
- `numeric_filtered_sum via parquet @ 1000000 linhas` throughput_per_second: 0.3031, 0.2973, 0.3048
- `total_rows via row @ 2000000 linhas` latency_p50_ms: 54.6, 43.29, 43.11
- `total_rows via row @ 2000000 linhas` latency_p95_ms: 66.76, 43.83, 43.61
- `total_rows via row @ 2000000 linhas` latency_p99_ms: 67.84, 43.88, 43.65
- `total_rows via row @ 2000000 linhas` throughput_per_second: 18.49, 23.15, 23.48
- `sum_amount via row @ 2000000 linhas` latency_p50_ms: 64.04, 56.16, 55.95
- `sum_amount via row @ 2000000 linhas` latency_p95_ms: 64.11, 56.45, 56.03
- `sum_amount via row @ 2000000 linhas` latency_p99_ms: 64.11, 56.48, 56.03
- `sum_amount via row @ 2000000 linhas` throughput_per_second: 15.65, 17.83, 17.89
- `group_by_category via row @ 2000000 linhas` latency_p50_ms: 130.7, 123.4, 122.7
- `group_by_category via row @ 2000000 linhas` latency_p95_ms: 130.7, 123.8, 122.9
- `group_by_category via row @ 2000000 linhas` latency_p99_ms: 130.8, 123.8, 122.9
- `group_by_category via row @ 2000000 linhas` throughput_per_second: 7.704, 8.148, 8.159
- `filtered_sum via row @ 2000000 linhas` latency_p50_ms: 74.62, 68.67, 69.07
- `filtered_sum via row @ 2000000 linhas` latency_p95_ms: 75.66, 69.14, 69.13
- `filtered_sum via row @ 2000000 linhas` latency_p99_ms: 75.75, 69.19, 69.14
- `filtered_sum via row @ 2000000 linhas` throughput_per_second: 13.41, 14.57, 14.6
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p50_ms: 69.83, 61.98, 63.45
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p95_ms: 71.28, 62.51, 80.23
- `numeric_filtered_sum via row @ 2000000 linhas` latency_p99_ms: 71.41, 62.56, 81.72
- `numeric_filtered_sum via row @ 2000000 linhas` throughput_per_second: 14.39, 16.17, 15.94
- `total_rows via columnar @ 2000000 linhas` latency_p50_ms: 16.8, 24.98, 17.75
- `total_rows via columnar @ 2000000 linhas` latency_p95_ms: 16.92, 25.15, 17.89
- `total_rows via columnar @ 2000000 linhas` latency_p99_ms: 16.93, 25.17, 17.9
- `total_rows via columnar @ 2000000 linhas` throughput_per_second: 59.57, 40.14, 57.03
- `sum_amount via columnar @ 2000000 linhas` latency_p50_ms: 37.4, 38.03, 39.71
- `sum_amount via columnar @ 2000000 linhas` latency_p95_ms: 37.72, 49.7, 50.38
- `sum_amount via columnar @ 2000000 linhas` latency_p99_ms: 37.74, 50.74, 51.33
- `sum_amount via columnar @ 2000000 linhas` throughput_per_second: 26.78, 26.71, 25.29
- `group_by_category via columnar @ 2000000 linhas` latency_p50_ms: 256.5, 277.3, 266
- `group_by_category via columnar @ 2000000 linhas` latency_p95_ms: 257.3, 285.3, 266.7
- `group_by_category via columnar @ 2000000 linhas` latency_p99_ms: 257.3, 286, 266.7
- `group_by_category via columnar @ 2000000 linhas` throughput_per_second: 3.905, 3.835, 3.774
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p50_ms: 62.78, 63.41, 67.42
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p95_ms: 62.89, 64.66, 67.44
- `numeric_filtered_sum via columnar @ 2000000 linhas` latency_p99_ms: 62.9, 64.77, 67.44
- `numeric_filtered_sum via columnar @ 2000000 linhas` throughput_per_second: 15.96, 16.08, 15.16
- `total_rows via parquet @ 2000000 linhas` latency_p50_ms: 6,326, 6,335, 6,269
- `total_rows via parquet @ 2000000 linhas` latency_p95_ms: 6,374, 6,449, 6,357
- `total_rows via parquet @ 2000000 linhas` latency_p99_ms: 6,379, 6,459, 6,365
- `total_rows via parquet @ 2000000 linhas` throughput_per_second: 0.1589, 0.1597, 0.1603
- `sum_amount via parquet @ 2000000 linhas` latency_p50_ms: 6,870, 7,062, 7,019
- `sum_amount via parquet @ 2000000 linhas` latency_p95_ms: 6,921, 7,093, 7,031
- `sum_amount via parquet @ 2000000 linhas` latency_p99_ms: 6,925, 7,095, 7,032
- `sum_amount via parquet @ 2000000 linhas` throughput_per_second: 0.1466, 0.1443, 0.145
- `group_by_category via parquet @ 2000000 linhas` latency_p50_ms: 7,333, 7,268, 7,319
- `group_by_category via parquet @ 2000000 linhas` latency_p95_ms: 7,390, 7,289, 7,332
- `group_by_category via parquet @ 2000000 linhas` latency_p99_ms: 7,395, 7,291, 7,333
- `group_by_category via parquet @ 2000000 linhas` throughput_per_second: 0.1369, 0.1381, 0.1375
- `filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 6,819, 6,852, 6,750
- `filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 6,859, 6,866, 6,804
- `filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 6,863, 6,868, 6,809
- `filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1483, 0.1465, 0.1492
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p50_ms: 6,760, 6,796, 6,822
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p95_ms: 6,871, 6,986, 6,904
- `numeric_filtered_sum via parquet @ 2000000 linhas` latency_p99_ms: 6,881, 7,003, 6,911
- `numeric_filtered_sum via parquet @ 2000000 linhas` throughput_per_second: 0.1483, 0.1479, 0.1471

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T145530Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

