# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T150247Z-analytical-synthetic-paths-theodb-52f3588c`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 92.04 | _not measured_ | 10.97 | 10.99 | 11 | yes |
| sum_amount via row | 73.53 | _not measured_ | 13.7 | 13.91 | 13.93 | yes |
| group_by_category via row | 37.95 | _not measured_ | 26.53 | 26.78 | 26.8 | yes |
| filtered_sum via row | 59.48 | _not measured_ | 16.93 | 17.3 | 17.34 | yes |
| numeric_filtered_sum via row | 62.66 | _not measured_ | 16.01 | 16.66 | 16.71 | **no** |
| total_rows via columnar | 430.6 | _not measured_ | 2.414 | 2.571 | 2.585 | **no** |
| sum_amount via columnar | 221.5 | _not measured_ | 4.563 | 4.737 | 4.742 | yes |
| group_by_category via columnar | 37.19 | _not measured_ | 26.94 | 27.33 | 27.36 | **no** |
| filtered_sum via columnar | _not measured_ | _not measured_ | _not measured_ | _not measured_ | _not measured_ | yes |
| numeric_filtered_sum via columnar | 132 | _not measured_ | 7.674 | 7.793 | 7.797 | yes |
| total_rows via parquet | 1.709 | _not measured_ | 585.8 | 591.1 | 591.5 | yes |
| sum_amount via parquet | 1.539 | _not measured_ | 654.4 | 659.1 | 659.5 | yes |
| group_by_category via parquet | 1.452 | _not measured_ | 695.1 | 701.4 | 702 | yes |
| filtered_sum via parquet | 1.593 | _not measured_ | 629.2 | 638 | 639.1 | yes |
| numeric_filtered_sum via parquet | 1.558 | _not measured_ | 643.4 | 649.7 | 650 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `numeric_filtered_sum via row`: latency_p95_ms cv=0.173; latency_p99_ms cv=0.187
- `total_rows via columnar`: latency_p99_ms cv=0.050
- `group_by_category via columnar`: latency_p50_ms cv=0.062; latency_p95_ms cv=0.066; latency_p99_ms cv=0.066; throughput_per_second cv=0.058

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 10.8, 10.97, 10.97
- `total_rows via row` latency_p95_ms: 10.88, 11.04, 10.99
- `total_rows via row` latency_p99_ms: 10.89, 11.04, 11
- `total_rows via row` throughput_per_second: 92.84, 91.84, 92.04
- `sum_amount via row` latency_p50_ms: 13.47, 13.84, 13.7
- `sum_amount via row` latency_p95_ms: 14.09, 13.91, 13.91
- `sum_amount via row` latency_p99_ms: 14.15, 13.92, 13.93
- `sum_amount via row` throughput_per_second: 74.5, 72.83, 73.53
- `group_by_category via row` latency_p50_ms: 26.62, 26.53, 25.78
- `group_by_category via row` latency_p95_ms: 26.78, 26.84, 26.54
- `group_by_category via row` latency_p99_ms: 26.8, 26.86, 26.61
- `group_by_category via row` throughput_per_second: 37.95, 37.71, 38.79
- `filtered_sum via row` latency_p50_ms: 17.3, 16.93, 16.89
- `filtered_sum via row` latency_p95_ms: 17.37, 17.3, 17.02
- `filtered_sum via row` latency_p99_ms: 17.38, 17.34, 17.03
- `filtered_sum via row` throughput_per_second: 57.96, 59.48, 60.61
- `numeric_filtered_sum via row` latency_p50_ms: 16.05, 16.01, 15.85
- `numeric_filtered_sum via row` latency_p95_ms: 16.18, 16.66, 21.88
- `numeric_filtered_sum via row` latency_p99_ms: 16.2, 16.71, 22.41
- `numeric_filtered_sum via row` throughput_per_second: 62.66, 62.49, 64.09
- `total_rows via columnar` latency_p50_ms: 2.429, 2.414, 2.327
- `total_rows via columnar` latency_p95_ms: 2.656, 2.571, 2.414
- `total_rows via columnar` latency_p99_ms: 2.676, 2.585, 2.422
- `total_rows via columnar` throughput_per_second: 425.1, 430.6, 446
- `sum_amount via columnar` latency_p50_ms: 4.68, 4.563, 4.404
- `sum_amount via columnar` latency_p95_ms: 4.737, 4.8, 4.509
- `sum_amount via columnar` latency_p99_ms: 4.742, 4.821, 4.519
- `sum_amount via columnar` throughput_per_second: 214, 221.5, 231.4
- `group_by_category via columnar` latency_p50_ms: 24.47, 26.94, 27.53
- `group_by_category via columnar` latency_p95_ms: 24.48, 27.33, 27.64
- `group_by_category via columnar` latency_p99_ms: 24.48, 27.36, 27.65
- `group_by_category via columnar` throughput_per_second: 40.97, 37.19, 37.01
- `numeric_filtered_sum via columnar` latency_p50_ms: 7.642, 7.674, 7.744
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.742, 7.881, 7.793
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.751, 7.9, 7.797
- `numeric_filtered_sum via columnar` throughput_per_second: 133, 132, 130.6
- `total_rows via parquet` latency_p50_ms: 585.8, 585.6, 594.6
- `total_rows via parquet` latency_p95_ms: 591.1, 587.9, 595.3
- `total_rows via parquet` latency_p99_ms: 591.5, 588.1, 595.4
- `total_rows via parquet` throughput_per_second: 1.711, 1.709, 1.686
- `sum_amount via parquet` latency_p50_ms: 654.4, 647.5, 662.9
- `sum_amount via parquet` latency_p95_ms: 659.1, 650.8, 664.6
- `sum_amount via parquet` latency_p99_ms: 659.5, 651.1, 664.8
- `sum_amount via parquet` throughput_per_second: 1.539, 1.545, 1.519
- `group_by_category via parquet` latency_p50_ms: 697.7, 688.7, 695.1
- `group_by_category via parquet` latency_p95_ms: 708.3, 691.4, 701.4
- `group_by_category via parquet` latency_p99_ms: 709.2, 691.6, 702
- `group_by_category via parquet` throughput_per_second: 1.452, 1.457, 1.447
- `filtered_sum via parquet` latency_p50_ms: 625.5, 629.2, 654.5
- `filtered_sum via parquet` latency_p95_ms: 638, 636, 655.4
- `filtered_sum via parquet` latency_p99_ms: 639.1, 636.6, 655.5
- `filtered_sum via parquet` throughput_per_second: 1.607, 1.593, 1.531
- `numeric_filtered_sum via parquet` latency_p50_ms: 646.4, 641.7, 643.4
- `numeric_filtered_sum via parquet` latency_p95_ms: 649.7, 644.9, 652.4
- `numeric_filtered_sum via parquet` latency_p99_ms: 650, 645.2, 653.2
- `numeric_filtered_sum via parquet` throughput_per_second: 1.557, 1.569, 1.558

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T145530Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424526336 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 4eb304bf1db2fc70aca1ecf3552788debc8a7ed7 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

