# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T201520Z-retrieval-synthetic-hybrid-theodb-a7ca24cf`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,283 | _not measured_ | 0.6922 | 0.7863 | 0.9087 | **no** |
| pipeline=vector | 207.4 | _not measured_ | 4.491 | 4.982 | 6.891 | **no** |
| pipeline=hybrid_rrf | 30.95 | _not measured_ | 32.36 | 38.72 | 39.74 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=lexical`: latency_p99_ms cv=0.058
- `pipeline=vector`: latency_p95_ms cv=0.204; latency_p99_ms cv=0.136; stage_vector_seconds cv=0.078; throughput_per_second cv=0.069
- `pipeline=hybrid_rrf`: latency_p99_ms cv=0.085

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.6859, 0.6712, 0.6922, 0.7254, 0.7127
- `pipeline=lexical` latency_p95_ms: 0.7863, 0.7579, 0.7697, 0.8116, 0.7972
- `pipeline=lexical` latency_p99_ms: 0.9189, 0.8014, 0.924, 0.865, 0.9087
- `pipeline=lexical` mrr: 0.8839, 0.8839, 0.8839, 0.8839, 0.8839
- `pipeline=lexical` ndcg_at_10: 0.7555, 0.7555, 0.7555, 0.7555, 0.7555
- `pipeline=lexical` recall_at_k: 0.505, 0.505, 0.505, 0.505, 0.505
- `pipeline=lexical` throughput_per_second: 1,283, 1,316, 1,284, 1,224, 1,252
- `pipeline=vector` latency_p50_ms: 4.356, 4.651, 4.521, 4.491, 4.476
- `pipeline=vector` latency_p95_ms: 4.796, 7.406, 5.898, 4.982, 4.712
- `pipeline=vector` latency_p99_ms: 6.404, 7.529, 6.891, 7.012, 5.165
- `pipeline=vector` mrr: 1, 1, 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.328, 1.599, 1.391, 1.369, 1.345
- `pipeline=vector` throughput_per_second: 214, 179, 204.2, 207.4, 211.2
- `pipeline=hybrid_rrf` latency_p50_ms: 32.36, 32.96, 32.58, 32.22, 32.14
- `pipeline=hybrid_rrf` latency_p95_ms: 38.72, 40.46, 39.24, 38.39, 38.28
- `pipeline=hybrid_rrf` latency_p99_ms: 39.74, 47.31, 43.57, 39.41, 39.21
- `pipeline=hybrid_rrf` mrr: 0.9883, 0.9883, 0.9883, 0.9883, 0.9883
- `pipeline=hybrid_rrf` ndcg_at_10: 0.8195, 0.8195, 0.8195, 0.8195, 0.8195
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 30.95, 30.07, 30.66, 31.18, 31.25

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T200751Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 471bf5ee4702aebbc48b8feffaa251ba91d7d5be (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

