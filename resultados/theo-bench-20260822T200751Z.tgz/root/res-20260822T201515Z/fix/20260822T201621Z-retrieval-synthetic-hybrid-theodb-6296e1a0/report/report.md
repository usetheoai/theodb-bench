# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T201621Z-retrieval-synthetic-hybrid-theodb-6296e1a0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,307 | _not measured_ | 0.6821 | 0.764 | 0.8082 | **no** |
| pipeline=vector | 233.5 | _not measured_ | 4.042 | 4.406 | 4.511 | yes |
| pipeline=hybrid_rrf | 31.98 | _not measured_ | 31.43 | 37.46 | 38.5 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=lexical`: latency_p95_ms cv=0.084; latency_p99_ms cv=0.154

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.699, 0.6821, 0.6692, 0.6729, 0.7367
- `pipeline=lexical` latency_p95_ms: 0.7923, 0.7598, 0.764, 0.756, 0.9138
- `pipeline=lexical` latency_p99_ms: 0.8532, 0.8082, 0.8075, 0.781, 1.107
- `pipeline=lexical` mrr: 0.8839, 0.8839, 0.8839, 0.8839, 0.8839
- `pipeline=lexical` ndcg_at_10: 0.7555, 0.7555, 0.7555, 0.7555, 0.7555
- `pipeline=lexical` recall_at_k: 0.505, 0.505, 0.505, 0.505, 0.505
- `pipeline=lexical` throughput_per_second: 1,277, 1,307, 1,323, 1,317, 1,170
- `pipeline=vector` latency_p50_ms: 4.181, 4.073, 4.042, 4.041, 4.023
- `pipeline=vector` latency_p95_ms: 4.503, 4.426, 4.406, 4.31, 4.221
- `pipeline=vector` latency_p99_ms: 4.722, 4.624, 4.511, 4.415, 4.352
- `pipeline=vector` mrr: 1, 1, 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.262, 1.231, 1.222, 1.217, 1.207
- `pipeline=vector` throughput_per_second: 225.9, 231.7, 233.5, 234.3, 236.4
- `pipeline=hybrid_rrf` latency_p50_ms: 31.38, 31.47, 31.43, 31.41, 31.45
- `pipeline=hybrid_rrf` latency_p95_ms: 37.39, 37.45, 37.46, 37.55, 37.47
- `pipeline=hybrid_rrf` latency_p99_ms: 37.94, 38.94, 38.61, 38.38, 38.5
- `pipeline=hybrid_rrf` mrr: 0.9883, 0.9883, 0.9883, 0.9883, 0.9883
- `pipeline=hybrid_rrf` ndcg_at_10: 0.8195, 0.8195, 0.8195, 0.8195, 0.8195
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 32.15, 31.98, 31.97, 31.99, 31.92

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T200751Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 471bf5ee4702aebbc48b8feffaa251ba91d7d5be (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

