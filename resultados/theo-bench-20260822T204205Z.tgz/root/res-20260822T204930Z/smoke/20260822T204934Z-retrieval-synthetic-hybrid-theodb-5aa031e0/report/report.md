# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T204934Z-retrieval-synthetic-hybrid-theodb-5aa031e0`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,287 | _not measured_ | 0.6948 | 0.7656 | 0.8072 | yes |
| pipeline=vector | 226.1 | _not measured_ | 4.182 | 4.465 | 4.549 | **no** |
| pipeline=hybrid_rrf | 31.76 | _not measured_ | 31.7 | 37.79 | 38.81 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=vector`: latency_p99_ms cv=0.058

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.6948, 0.6955, 0.6761
- `pipeline=lexical` latency_p95_ms: 0.7774, 0.7656, 0.7398
- `pipeline=lexical` latency_p99_ms: 0.8428, 0.8072, 0.7725
- `pipeline=lexical` mrr: 0.8839, 0.8839, 0.8839
- `pipeline=lexical` ndcg_at_10: 0.7555, 0.7555, 0.7555
- `pipeline=lexical` recall_at_k: 0.505, 0.505, 0.505
- `pipeline=lexical` throughput_per_second: 1,272, 1,287, 1,326
- `pipeline=vector` latency_p50_ms: 4.182, 4.202, 4.075
- `pipeline=vector` latency_p95_ms: 4.503, 4.465, 4.328
- `pipeline=vector` latency_p99_ms: 4.965, 4.549, 4.464
- `pipeline=vector` mrr: 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.261, 1.263, 1.225
- `pipeline=vector` throughput_per_second: 226.1, 225.9, 233
- `pipeline=hybrid_rrf` latency_p50_ms: 31.7, 31.65, 31.8
- `pipeline=hybrid_rrf` latency_p95_ms: 37.79, 37.68, 37.87
- `pipeline=hybrid_rrf` latency_p99_ms: 38.64, 39.13, 38.81
- `pipeline=hybrid_rrf` mrr: 0.9883, 0.9883, 0.9883
- `pipeline=hybrid_rrf` ndcg_at_10: 0.8195, 0.8195, 0.8195
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 31.81, 31.71, 31.76

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T204205Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: bd3e82140bb00b5d31254a1908dc61f4a798d6af (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

