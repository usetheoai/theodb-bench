# retrieval/synthetic/hybrid on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260822T205011Z-retrieval-synthetic-hybrid-theodb-08d961a2`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| pipeline=lexical | 1,301 | _not measured_ | 0.6804 | 0.7756 | 0.8116 | yes |
| pipeline=vector | 232.9 | _not measured_ | 4.066 | 4.376 | 4.511 | **no** |
| pipeline=hybrid_rrf | 31.33 | _not measured_ | 32.01 | 38.27 | 39.35 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `pipeline=vector`: latency_p99_ms cv=0.268

### Repetitions

Every repetition is retained:

- `pipeline=lexical` latency_p50_ms: 0.6804, 0.6859, 0.6638
- `pipeline=lexical` latency_p95_ms: 0.7767, 0.7756, 0.749
- `pipeline=lexical` latency_p99_ms: 0.8385, 0.8116, 0.7684
- `pipeline=lexical` mrr: 0.8839, 0.8839, 0.8839
- `pipeline=lexical` ndcg_at_10: 0.7555, 0.7555, 0.7555
- `pipeline=lexical` recall_at_k: 0.505, 0.505, 0.505
- `pipeline=lexical` throughput_per_second: 1,297, 1,301, 1,344
- `pipeline=vector` latency_p50_ms: 4.053, 4.066, 4.075
- `pipeline=vector` latency_p95_ms: 4.526, 4.376, 4.293
- `pipeline=vector` latency_p99_ms: 6.952, 4.511, 4.459
- `pipeline=vector` mrr: 1, 1, 1
- `pipeline=vector` ndcg_at_10: 0.8266, 0.8266, 0.8266
- `pipeline=vector` recall_at_k: 0.5017, 0.5017, 0.5017
- `pipeline=vector` stage_vector_seconds: 1.249, 1.229, 1.225
- `pipeline=vector` throughput_per_second: 229.2, 232.9, 233.3
- `pipeline=hybrid_rrf` latency_p50_ms: 32.22, 31.94, 32.01
- `pipeline=hybrid_rrf` latency_p95_ms: 38.57, 38.27, 38.2
- `pipeline=hybrid_rrf` latency_p99_ms: 39.51, 39.35, 38.87
- `pipeline=hybrid_rrf` mrr: 0.9883, 0.9883, 0.9883
- `pipeline=hybrid_rrf` ndcg_at_10: 0.8195, 0.8195, 0.8195
- `pipeline=hybrid_rrf` recall_at_k: 0.5017, 0.5017, 0.5017
- `pipeline=hybrid_rrf` throughput_per_second: 31.31, 31.33, 31.38

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260822T204205Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: bd3e82140bb00b5d31254a1908dc61f4a798d6af (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

