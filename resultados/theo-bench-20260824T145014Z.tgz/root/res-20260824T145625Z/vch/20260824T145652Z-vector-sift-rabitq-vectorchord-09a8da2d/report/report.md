# vector/sift/rabitq on vectorchord

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T145652Z-vector-sift-rabitq-vectorchord-09a8da2d`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| rabitq lists=256 rq_probes=1 | 3,314 | 0.388 | 0.2482 | 0.297 | 0.3416 | **no** |
| rabitq lists=256 rq_probes=8 | 2,076 | 0.8812 | 0.4162 | 0.4966 | 0.5664 | **no** |
| rabitq lists=256 rq_probes=32 | 1,203 | 0.99 | 0.7702 | 0.8986 | 1.038 | **no** |
| rabitq lists=256 rq_probes=128 | 495.2 | 0.9962 | 1.94 | 2.142 | 2.266 | yes |
| rabitq lists=256 rq_probes=512 | 282 | 0.9946 | 3.469 | 3.626 | 3.735 | yes |
| rabitq lists=1024 rq_probes=1 | 3,309 | 0.2918 | 0.2483 | 0.2862 | 0.3347 | **no** |
| rabitq lists=1024 rq_probes=8 | 2,389 | 0.747 | 0.3577 | 0.4177 | 0.4754 | **no** |
| rabitq lists=1024 rq_probes=32 | 1,713 | 0.9496 | 0.5245 | 0.6192 | 0.7195 | **no** |
| rabitq lists=1024 rq_probes=128 | 895 | 0.9926 | 1.047 | 1.177 | 1.313 | **no** |
| rabitq lists=1024 rq_probes=512 | 349.4 | 0.9936 | 2.777 | 2.947 | 3.25 | **no** |
| rabitq lists=4096 rq_probes=1 | 2,374 | 0.00186 | 0.3655 | 0.4276 | 0.4816 | **no** |
| rabitq lists=4096 rq_probes=8 | 1,692 | 0.6294 | 0.5354 | 0.6175 | 0.7137 | **no** |
| rabitq lists=4096 rq_probes=32 | 1,150 | 0.881 | 0.7939 | 0.962 | 1.077 | **no** |
| rabitq lists=4096 rq_probes=128 | 697 | 0.9856 | 1.335 | 1.733 | 2.155 | **no** |
| rabitq lists=4096 rq_probes=512 | 338.1 | 0.9958 | 2.805 | 3.57 | 4.316 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `rabitq lists=256 rq_probes=1`: latency_p50_ms cv=0.121; latency_p95_ms cv=0.180; latency_p99_ms cv=0.199; throughput_per_second cv=0.105
- `rabitq lists=256 rq_probes=8`: latency_p99_ms cv=0.090
- `rabitq lists=256 rq_probes=32`: latency_p99_ms cv=0.054
- `rabitq lists=1024 rq_probes=1`: latency_p99_ms cv=0.055
- `rabitq lists=1024 rq_probes=8`: latency_p99_ms cv=0.056
- `rabitq lists=1024 rq_probes=32`: latency_p99_ms cv=0.059
- `rabitq lists=1024 rq_probes=128`: latency_p99_ms cv=0.051
- `rabitq lists=1024 rq_probes=512`: latency_p99_ms cv=0.064
- `rabitq lists=4096 rq_probes=1`: latency_p50_ms cv=0.175; latency_p95_ms cv=0.172; latency_p99_ms cv=0.158; throughput_per_second cv=0.129
- `rabitq lists=4096 rq_probes=8`: latency_p50_ms cv=0.084; latency_p95_ms cv=0.128; latency_p99_ms cv=0.095; throughput_per_second cv=0.074
- `rabitq lists=4096 rq_probes=32`: latency_p95_ms cv=0.091; latency_p99_ms cv=0.096
- `rabitq lists=4096 rq_probes=128`: latency_p99_ms cv=0.067

### Repetitions

Every repetition is retained:

- `rabitq lists=256 rq_probes=1` build_seconds: 5.17, 5.17, 5.17
- `rabitq lists=256 rq_probes=1` index_size_bytes: 6.891e+07, 6.891e+07, 6.891e+07
- `rabitq lists=256 rq_probes=1` latency_p50_ms: 0.3011, 0.2482, 0.2438
- `rabitq lists=256 rq_probes=1` latency_p95_ms: 0.3962, 0.2912, 0.297
- `rabitq lists=256 rq_probes=1` latency_p99_ms: 0.4715, 0.3374, 0.3416
- `rabitq lists=256 rq_probes=1` recall: 0.388, 0.388, 0.388
- `rabitq lists=256 rq_probes=1` throughput_per_second: 2,756, 3,314, 3,342
- `rabitq lists=256 rq_probes=8` build_seconds: 4.264, 4.264, 4.264
- `rabitq lists=256 rq_probes=8` index_size_bytes: 6.907e+07, 6.907e+07, 6.907e+07
- `rabitq lists=256 rq_probes=8` latency_p50_ms: 0.4284, 0.4162, 0.4126
- `rabitq lists=256 rq_probes=8` latency_p95_ms: 0.4865, 0.4966, 0.5221
- `rabitq lists=256 rq_probes=8` latency_p99_ms: 0.5267, 0.5664, 0.6296
- `rabitq lists=256 rq_probes=8` recall: 0.8812, 0.8812, 0.8812
- `rabitq lists=256 rq_probes=8` throughput_per_second: 2,076, 2,017, 2,110
- `rabitq lists=256 rq_probes=32` build_seconds: 4.299, 4.299, 4.299
- `rabitq lists=256 rq_probes=32` index_size_bytes: 6.899e+07, 6.899e+07, 6.899e+07
- `rabitq lists=256 rq_probes=32` latency_p50_ms: 0.7584, 0.7702, 0.7704
- `rabitq lists=256 rq_probes=32` latency_p95_ms: 0.8771, 0.8986, 0.9054
- `rabitq lists=256 rq_probes=32` latency_p99_ms: 0.9488, 1.038, 1.047
- `rabitq lists=256 rq_probes=32` recall: 0.99, 0.99, 0.99
- `rabitq lists=256 rq_probes=32` throughput_per_second: 1,220, 1,203, 1,200
- `rabitq lists=256 rq_probes=128` build_seconds: 4.328, 4.328, 4.328
- `rabitq lists=256 rq_probes=128` index_size_bytes: 6.89e+07, 6.89e+07, 6.89e+07
- `rabitq lists=256 rq_probes=128` latency_p50_ms: 1.94, 1.954, 1.894
- `rabitq lists=256 rq_probes=128` latency_p95_ms: 2.142, 2.198, 2.107
- `rabitq lists=256 rq_probes=128` latency_p99_ms: 2.228, 2.353, 2.266
- `rabitq lists=256 rq_probes=128` recall: 0.9962, 0.9962, 0.9962
- `rabitq lists=256 rq_probes=128` throughput_per_second: 495.2, 492.5, 507.1
- `rabitq lists=256 rq_probes=512` build_seconds: 4.295, 4.295, 4.295
- `rabitq lists=256 rq_probes=512` index_size_bytes: 6.898e+07, 6.898e+07, 6.898e+07
- `rabitq lists=256 rq_probes=512` latency_p50_ms: 3.469, 3.475, 3.419
- `rabitq lists=256 rq_probes=512` latency_p95_ms: 3.622, 3.628, 3.626
- `rabitq lists=256 rq_probes=512` latency_p99_ms: 3.724, 3.764, 3.735
- `rabitq lists=256 rq_probes=512` recall: 0.9946, 0.9946, 0.9946
- `rabitq lists=256 rq_probes=512` throughput_per_second: 282, 280.9, 285.1
- `rabitq lists=1024 rq_probes=1` build_seconds: 10.06, 10.06, 10.06
- `rabitq lists=1024 rq_probes=1` index_size_bytes: 9.062e+07, 9.062e+07, 9.062e+07
- `rabitq lists=1024 rq_probes=1` latency_p50_ms: 0.26, 0.2483, 0.2472
- `rabitq lists=1024 rq_probes=1` latency_p95_ms: 0.299, 0.2845, 0.2862
- `rabitq lists=1024 rq_probes=1` latency_p99_ms: 0.3185, 0.3557, 0.3347
- `rabitq lists=1024 rq_probes=1` recall: 0.2918, 0.2918, 0.2918
- `rabitq lists=1024 rq_probes=1` throughput_per_second: 3,196, 3,317, 3,309
- `rabitq lists=1024 rq_probes=8` build_seconds: 10.01, 10.01, 10.01
- `rabitq lists=1024 rq_probes=8` index_size_bytes: 9.062e+07, 9.062e+07, 9.062e+07
- `rabitq lists=1024 rq_probes=8` latency_p50_ms: 0.3545, 0.3577, 0.367
- `rabitq lists=1024 rq_probes=8` latency_p95_ms: 0.4007, 0.4177, 0.4375
- `rabitq lists=1024 rq_probes=8` latency_p99_ms: 0.4382, 0.4754, 0.4887
- `rabitq lists=1024 rq_probes=8` recall: 0.747, 0.747, 0.747
- `rabitq lists=1024 rq_probes=8` throughput_per_second: 2,464, 2,389, 2,254
- `rabitq lists=1024 rq_probes=32` build_seconds: 10.06, 10.06, 10.06
- `rabitq lists=1024 rq_probes=32` index_size_bytes: 9.062e+07, 9.062e+07, 9.062e+07
- `rabitq lists=1024 rq_probes=32` latency_p50_ms: 0.5234, 0.5264, 0.5245
- `rabitq lists=1024 rq_probes=32` latency_p95_ms: 0.6003, 0.6192, 0.6237
- `rabitq lists=1024 rq_probes=32` latency_p99_ms: 0.6505, 0.7235, 0.7195
- `rabitq lists=1024 rq_probes=32` recall: 0.9496, 0.9496, 0.9496
- `rabitq lists=1024 rq_probes=32` throughput_per_second: 1,730, 1,707, 1,713
- `rabitq lists=1024 rq_probes=128` build_seconds: 10.11, 10.11, 10.11
- `rabitq lists=1024 rq_probes=128` index_size_bytes: 9.062e+07, 9.062e+07, 9.062e+07
- `rabitq lists=1024 rq_probes=128` latency_p50_ms: 1.045, 1.047, 1.051
- `rabitq lists=1024 rq_probes=128` latency_p95_ms: 1.15, 1.177, 1.185
- `rabitq lists=1024 rq_probes=128` latency_p99_ms: 1.207, 1.327, 1.313
- `rabitq lists=1024 rq_probes=128` recall: 0.9926, 0.9926, 0.9926
- `rabitq lists=1024 rq_probes=128` throughput_per_second: 904.6, 895, 890.5
- `rabitq lists=1024 rq_probes=512` build_seconds: 10.22, 10.22, 10.22
- `rabitq lists=1024 rq_probes=512` index_size_bytes: 9.062e+07, 9.062e+07, 9.062e+07
- `rabitq lists=1024 rq_probes=512` latency_p50_ms: 2.775, 2.777, 2.796
- `rabitq lists=1024 rq_probes=512` latency_p95_ms: 2.913, 2.947, 2.984
- `rabitq lists=1024 rq_probes=512` latency_p99_ms: 2.993, 3.403, 3.25
- `rabitq lists=1024 rq_probes=512` recall: 0.9936, 0.9936, 0.9936
- `rabitq lists=1024 rq_probes=512` throughput_per_second: 352, 349.4, 346.5
- `rabitq lists=4096 rq_probes=1` build_seconds: 32.24, 32.24, 32.24
- `rabitq lists=4096 rq_probes=1` index_size_bytes: 1.913e+08, 1.913e+08, 1.913e+08
- `rabitq lists=4096 rq_probes=1` latency_p50_ms: 0.4866, 0.3655, 0.3623
- `rabitq lists=4096 rq_probes=1` latency_p95_ms: 0.5683, 0.4276, 0.4264
- `rabitq lists=4096 rq_probes=1` latency_p99_ms: 0.6183, 0.4701, 0.4816
- `rabitq lists=4096 rq_probes=1` recall: 0.00186, 0.00186, 0.00186
- `rabitq lists=4096 rq_probes=1` throughput_per_second: 1,884, 2,374, 2,384
- `rabitq lists=4096 rq_probes=8` build_seconds: 32.16, 32.16, 32.16
- `rabitq lists=4096 rq_probes=8` index_size_bytes: 1.913e+08, 1.913e+08, 1.913e+08
- `rabitq lists=4096 rq_probes=8` latency_p50_ms: 0.617, 0.5345, 0.5354
- `rabitq lists=4096 rq_probes=8` latency_p95_ms: 0.7634, 0.6175, 0.6153
- `rabitq lists=4096 rq_probes=8` latency_p99_ms: 0.8307, 0.703, 0.7137
- `rabitq lists=4096 rq_probes=8` recall: 0.6294, 0.6294, 0.6294
- `rabitq lists=4096 rq_probes=8` throughput_per_second: 1,486, 1,697, 1,692
- `rabitq lists=4096 rq_probes=32` build_seconds: 32.24, 32.24, 32.24
- `rabitq lists=4096 rq_probes=32` index_size_bytes: 1.913e+08, 1.913e+08, 1.913e+08
- `rabitq lists=4096 rq_probes=32` latency_p50_ms: 0.8325, 0.7891, 0.7939
- `rabitq lists=4096 rq_probes=32` latency_p95_ms: 1.105, 0.9348, 0.962
- `rabitq lists=4096 rq_probes=32` latency_p99_ms: 1.258, 1.063, 1.077
- `rabitq lists=4096 rq_probes=32` recall: 0.881, 0.881, 0.881
- `rabitq lists=4096 rq_probes=32` throughput_per_second: 1,106, 1,171, 1,150
- `rabitq lists=4096 rq_probes=128` build_seconds: 31.69, 31.69, 31.69
- `rabitq lists=4096 rq_probes=128` index_size_bytes: 1.913e+08, 1.913e+08, 1.913e+08
- `rabitq lists=4096 rq_probes=128` latency_p50_ms: 1.386, 1.335, 1.311
- `rabitq lists=4096 rq_probes=128` latency_p95_ms: 1.808, 1.733, 1.647
- `rabitq lists=4096 rq_probes=128` latency_p99_ms: 2.197, 2.155, 1.935
- `rabitq lists=4096 rq_probes=128` recall: 0.9856, 0.9856, 0.9856
- `rabitq lists=4096 rq_probes=128` throughput_per_second: 674.4, 697, 717.7
- `rabitq lists=4096 rq_probes=512` build_seconds: 31.64, 31.64, 31.64
- `rabitq lists=4096 rq_probes=512` index_size_bytes: 1.913e+08, 1.913e+08, 1.913e+08
- `rabitq lists=4096 rq_probes=512` latency_p50_ms: 2.805, 2.829, 2.804
- `rabitq lists=4096 rq_probes=512` latency_p95_ms: 3.57, 3.659, 3.523
- `rabitq lists=4096 rq_probes=512` latency_p99_ms: 4.3, 4.519, 4.316
- `rabitq lists=4096 rq_probes=512` recall: 0.9958, 0.9958, 0.9958
- `rabitq lists=4096 rq_probes=512` throughput_per_second: 339.1, 335.2, 338.1

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T145014Z
- CPU: Intel(R) Xeon(R) Platinum 8358 CPU @ 2.60GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424518144 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: d1988ff3cfe224bb03aa2097f5acdc5f0aa47be9 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

