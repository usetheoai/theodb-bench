# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134634Z-vector-sift-hnsw-theodb-2b526a35`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,434 | 0.8698 | 0.6357 | 0.7762 | 0.8846 | **no** |
| hnsw m=16 ef_search=64 | 1,212 | 0.9626 | 0.7656 | 0.919 | 1.054 | **no** |
| hnsw m=16 ef_search=256 | 469.3 | 0.9968 | 2.091 | 2.528 | 2.657 | yes |
| hnsw m=16 ef_search=512 | 290.9 | 0.9978 | 3.443 | 4.17 | 4.55 | yes |
| hnsw m=16 ef_search=1000 | 171.7 | 0.9976 | 5.822 | 7.213 | 7.746 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p95_ms cv=0.054; latency_p99_ms cv=0.097
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.074

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 9.18, 9.18, 9.18
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6141, 0.6359, 0.6357
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7451, 0.7762, 0.8293
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8069, 0.8846, 0.9801
- `hnsw m=16 ef_search=16` recall: 0.8698, 0.8698, 0.8698
- `hnsw m=16 ef_search=16` throughput_per_second: 1,484, 1,434, 1,411
- `hnsw m=16 ef_search=64` build_seconds: 8.641, 8.641, 8.641
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7656, 0.7628, 0.7684
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8838, 0.9367, 0.919
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9446, 1.054, 1.092
- `hnsw m=16 ef_search=64` recall: 0.9626, 0.9626, 0.9626
- `hnsw m=16 ef_search=64` throughput_per_second: 1,223, 1,172, 1,212
- `hnsw m=16 ef_search=256` build_seconds: 8.653, 8.653, 8.653
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.013, 2.105, 2.091
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.404, 2.528, 2.535
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.557, 2.691, 2.657
- `hnsw m=16 ef_search=256` recall: 0.9968, 0.9968, 0.9968
- `hnsw m=16 ef_search=256` throughput_per_second: 490.9, 469.3, 468.5
- `hnsw m=16 ef_search=512` build_seconds: 8.702, 8.702, 8.702
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.448, 3.443, 3.443
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.17, 4.186, 4.104
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.426, 4.662, 4.55
- `hnsw m=16 ef_search=512` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=512` throughput_per_second: 289.2, 290.9, 291.2
- `hnsw m=16 ef_search=1000` build_seconds: 8.675, 8.675, 8.675
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.822, 5.977, 5.704
- `hnsw m=16 ef_search=1000` latency_p95_ms: 7.213, 7.4, 7.002
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.746, 7.913, 7.703
- `hnsw m=16 ef_search=1000` recall: 0.9976, 0.9976, 0.9976
- `hnsw m=16 ef_search=1000` throughput_per_second: 171.7, 168.2, 176.3

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

