# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134502Z-vector-sift-hnsw-theodb-6d87d816`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,325 | 0.8728 | 0.6832 | 0.8524 | 0.9675 | **no** |
| hnsw m=16 ef_search=64 | 1,088 | 0.9642 | 0.8222 | 1.021 | 1.207 | **no** |
| hnsw m=16 ef_search=256 | 477.7 | 0.9982 | 2.026 | 2.503 | 2.783 | yes |
| hnsw m=16 ef_search=512 | 277.3 | 0.9998 | 3.512 | 4.876 | 5.419 | **no** |
| hnsw m=16 ef_search=1000 | 152 | 1 | 6.528 | 8.423 | 9.331 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.051; latency_p95_ms cv=0.195; latency_p99_ms cv=0.191; throughput_per_second cv=0.084
- `hnsw m=16 ef_search=64`: latency_p95_ms cv=0.156; latency_p99_ms cv=0.120
- `hnsw m=16 ef_search=512`: latency_p95_ms cv=0.096; latency_p99_ms cv=0.105
- `hnsw m=16 ef_search=1000`: latency_p50_ms cv=0.053; latency_p95_ms cv=0.059; latency_p99_ms cv=0.106; throughput_per_second cv=0.056

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 11.33, 11.33, 11.33
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6832, 0.7428, 0.6793
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.8524, 1.17, 0.8414
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.9386, 1.307, 0.9675
- `hnsw m=16 ef_search=16` recall: 0.8728, 0.8728, 0.8728
- `hnsw m=16 ef_search=16` throughput_per_second: 1,330, 1,143, 1,325
- `hnsw m=16 ef_search=64` build_seconds: 11.39, 11.39, 11.39
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.8103, 0.8227, 0.8222
- `hnsw m=16 ef_search=64` latency_p95_ms: 1.305, 0.992, 1.021
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.442, 1.158, 1.207
- `hnsw m=16 ef_search=64` recall: 0.9642, 0.9642, 0.9642
- `hnsw m=16 ef_search=64` throughput_per_second: 1,088, 1,079, 1,105
- `hnsw m=16 ef_search=256` build_seconds: 11.39, 11.39, 11.39
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.047, 2.026, 2.023
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.503, 2.494, 2.543
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.802, 2.711, 2.783
- `hnsw m=16 ef_search=256` recall: 0.9982, 0.9982, 0.9982
- `hnsw m=16 ef_search=256` throughput_per_second: 475.1, 481.6, 477.7
- `hnsw m=16 ef_search=512` build_seconds: 11.54, 11.54, 11.54
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.443, 3.569, 3.512
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.23, 5.101, 4.876
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.623, 5.674, 5.419
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 289, 268, 277.3
- `hnsw m=16 ef_search=1000` build_seconds: 11.56, 11.56, 11.56
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 6.053, 6.719, 6.528
- `hnsw m=16 ef_search=1000` latency_p95_ms: 7.697, 8.423, 8.618
- `hnsw m=16 ef_search=1000` latency_p99_ms: 8.506, 9.331, 10.5
- `hnsw m=16 ef_search=1000` recall: 1, 1, 1
- `hnsw m=16 ef_search=1000` throughput_per_second: 165.8, 149.5, 152

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

