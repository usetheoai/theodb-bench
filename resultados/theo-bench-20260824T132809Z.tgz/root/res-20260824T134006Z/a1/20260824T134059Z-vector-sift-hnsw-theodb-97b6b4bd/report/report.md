# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134059Z-vector-sift-hnsw-theodb-97b6b4bd`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,419 | 0.8726 | 0.6451 | 0.8043 | 0.8878 | **no** |
| hnsw m=16 ef_search=64 | 1,194 | 0.9618 | 0.7867 | 0.9366 | 1.043 | **no** |
| hnsw m=16 ef_search=256 | 479.8 | 0.9958 | 2.062 | 2.467 | 2.616 | yes |
| hnsw m=16 ef_search=512 | 297.9 | 0.997 | 3.348 | 4.072 | 4.336 | yes |
| hnsw m=16 ef_search=1000 | 175.6 | 0.9988 | 5.696 | 7.212 | 8.106 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p99_ms cv=0.050
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.087

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 8.778, 8.778, 8.778
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6451, 0.6645, 0.614
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.8043, 0.8371, 0.7632
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8878, 0.9524, 0.865
- `hnsw m=16 ef_search=16` recall: 0.8726, 0.8726, 0.8726
- `hnsw m=16 ef_search=16` throughput_per_second: 1,419, 1,368, 1,474
- `hnsw m=16 ef_search=64` build_seconds: 8.745, 8.745, 8.745
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7824, 0.7903, 0.7867
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9284, 0.9883, 0.9366
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9799, 1.161, 1.043
- `hnsw m=16 ef_search=64` recall: 0.9618, 0.9618, 0.9618
- `hnsw m=16 ef_search=64` throughput_per_second: 1,202, 1,130, 1,194
- `hnsw m=16 ef_search=256` build_seconds: 8.745, 8.745, 8.745
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.085, 2.037, 2.062
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.491, 2.443, 2.467
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.615, 2.698, 2.616
- `hnsw m=16 ef_search=256` recall: 0.9958, 0.9958, 0.9958
- `hnsw m=16 ef_search=256` throughput_per_second: 474.5, 482.8, 479.8
- `hnsw m=16 ef_search=512` build_seconds: 8.649, 8.649, 8.649
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.348, 3.311, 3.348
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.121, 4.036, 4.072
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.387, 4.336, 4.327
- `hnsw m=16 ef_search=512` recall: 0.997, 0.997, 0.997
- `hnsw m=16 ef_search=512` throughput_per_second: 297.9, 299.5, 296.2
- `hnsw m=16 ef_search=1000` build_seconds: 8.667, 8.667, 8.667
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.587, 5.696, 6.018
- `hnsw m=16 ef_search=1000` latency_p95_ms: 7.128, 7.212, 7.645
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.629, 8.106, 8.387
- `hnsw m=16 ef_search=1000` recall: 0.9988, 0.9988, 0.9988
- `hnsw m=16 ef_search=1000` throughput_per_second: 180.1, 175.6, 165.1

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

