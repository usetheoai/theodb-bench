# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134342Z-vector-sift-hnsw-theodb-04b1bf95`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,168 | 0.8686 | 0.7715 | 0.9236 | 1.048 | **no** |
| hnsw m=16 ef_search=64 | 1,068 | 0.961 | 0.8458 | 1.033 | 1.246 | **no** |
| hnsw m=16 ef_search=256 | 477.7 | 0.9958 | 2.055 | 2.498 | 2.648 | **no** |
| hnsw m=16 ef_search=512 | 289.4 | 0.9972 | 3.414 | 4.327 | 4.757 | yes |
| hnsw m=16 ef_search=1000 | 178.8 | 0.9982 | 5.586 | 7.05 | 8.024 | **no** |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p50_ms cv=0.075; throughput_per_second cv=0.075
- `hnsw m=16 ef_search=64`: latency_p50_ms cv=0.071; latency_p95_ms cv=0.125; latency_p99_ms cv=0.082; throughput_per_second cv=0.084
- `hnsw m=16 ef_search=256`: latency_p50_ms cv=0.095; latency_p95_ms cv=0.088; latency_p99_ms cv=0.085; throughput_per_second cv=0.085
- `hnsw m=16 ef_search=1000`: latency_p99_ms cv=0.086

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 9.209, 9.209, 9.209
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6848, 0.7895, 0.7715
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.9052, 0.9566, 0.9236
- `hnsw m=16 ef_search=16` latency_p99_ms: 1.048, 1.078, 1.013
- `hnsw m=16 ef_search=16` recall: 0.8686, 0.8686, 0.8686
- `hnsw m=16 ef_search=16` throughput_per_second: 1,308, 1,139, 1,168
- `hnsw m=16 ef_search=64` build_seconds: 9.2, 9.2, 9.2
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7665, 0.8458, 0.8829
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.9131, 1.033, 1.172
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.164, 1.246, 1.37
- `hnsw m=16 ef_search=64` recall: 0.961, 0.961, 0.961
- `hnsw m=16 ef_search=64` throughput_per_second: 1,217, 1,068, 1,046
- `hnsw m=16 ef_search=256` build_seconds: 9.442, 9.442, 9.442
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.364, 2.055, 1.984
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.878, 2.498, 2.467
- `hnsw m=16 ef_search=256` latency_p99_ms: 3.026, 2.648, 2.595
- `hnsw m=16 ef_search=256` recall: 0.9958, 0.9958, 0.9958
- `hnsw m=16 ef_search=256` throughput_per_second: 418.9, 477.7, 494.1
- `hnsw m=16 ef_search=512` build_seconds: 9.211, 9.211, 9.211
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.347, 3.414, 3.493
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.187, 4.327, 4.388
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.569, 4.757, 4.85
- `hnsw m=16 ef_search=512` recall: 0.9972, 0.9972, 0.9972
- `hnsw m=16 ef_search=512` throughput_per_second: 296.1, 289.4, 284.9
- `hnsw m=16 ef_search=1000` build_seconds: 9.178, 9.178, 9.178
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.489, 5.998, 5.586
- `hnsw m=16 ef_search=1000` latency_p95_ms: 7.043, 7.645, 7.05
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.529, 8.918, 8.024
- `hnsw m=16 ef_search=1000` recall: 0.9982, 0.9982, 0.9982
- `hnsw m=16 ef_search=1000` throughput_per_second: 181.2, 166, 178.8

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

