# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134751Z-vector-sift-hnsw-theodb-3409de82`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,486 | 0.8696 | 0.6085 | 0.7535 | 0.8593 | yes |
| hnsw m=16 ef_search=64 | 1,204 | 0.9634 | 0.7693 | 0.9243 | 1.036 | yes |
| hnsw m=16 ef_search=256 | 457.5 | 0.9978 | 2.145 | 2.62 | 2.847 | yes |
| hnsw m=16 ef_search=512 | 311.3 | 0.9998 | 3.16 | 4.029 | 4.464 | **no** |
| hnsw m=16 ef_search=1000 | 190.4 | 0.9998 | 5.249 | 6.575 | 7.281 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=512`: latency_p99_ms cv=0.064

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 10.31, 10.31, 10.31
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.613, 0.6085, 0.5873
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7535, 0.7634, 0.7297
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8233, 0.8614, 0.8593
- `hnsw m=16 ef_search=16` recall: 0.8696, 0.8696, 0.8696
- `hnsw m=16 ef_search=16` throughput_per_second: 1,480, 1,486, 1,533
- `hnsw m=16 ef_search=64` build_seconds: 10.62, 10.62, 10.62
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7783, 0.7591, 0.7693
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.928, 0.9225, 0.9243
- `hnsw m=16 ef_search=64` latency_p99_ms: 1.001, 1.057, 1.036
- `hnsw m=16 ef_search=64` recall: 0.9634, 0.9634, 0.9634
- `hnsw m=16 ef_search=64` throughput_per_second: 1,204, 1,185, 1,213
- `hnsw m=16 ef_search=256` build_seconds: 10.61, 10.61, 10.61
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 2.154, 2.145, 2.058
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.679, 2.62, 2.513
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.968, 2.847, 2.768
- `hnsw m=16 ef_search=256` recall: 0.9978, 0.9978, 0.9978
- `hnsw m=16 ef_search=256` throughput_per_second: 454.6, 457.5, 479.7
- `hnsw m=16 ef_search=512` build_seconds: 10.43, 10.43, 10.43
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.171, 3.16, 3.137
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.029, 3.999, 4.092
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.241, 4.464, 4.816
- `hnsw m=16 ef_search=512` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=512` throughput_per_second: 310.1, 311.5, 311.3
- `hnsw m=16 ef_search=1000` build_seconds: 10.46, 10.46, 10.46
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.249, 5.343, 5.239
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.485, 6.706, 6.575
- `hnsw m=16 ef_search=1000` latency_p99_ms: 7.281, 7.381, 7.169
- `hnsw m=16 ef_search=1000` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=1000` throughput_per_second: 190.4, 186.1, 190.7

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

