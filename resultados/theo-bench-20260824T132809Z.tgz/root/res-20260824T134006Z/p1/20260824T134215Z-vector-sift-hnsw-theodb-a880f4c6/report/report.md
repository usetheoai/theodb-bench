# vector/sift/hnsw on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134215Z-vector-sift-hnsw-theodb-a880f4c6`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| hnsw m=16 ef_search=16 | 1,413 | 0.872 | 0.6484 | 0.8052 | 0.8939 | **no** |
| hnsw m=16 ef_search=64 | 1,231 | 0.9628 | 0.7546 | 0.9046 | 1.109 | **no** |
| hnsw m=16 ef_search=256 | 492.1 | 0.9976 | 1.992 | 2.453 | 2.679 | yes |
| hnsw m=16 ef_search=512 | 307.1 | 0.9996 | 3.202 | 4.042 | 4.37 | yes |
| hnsw m=16 ef_search=1000 | 192.7 | 0.9998 | 5.165 | 6.455 | 6.979 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `hnsw m=16 ef_search=16`: latency_p95_ms cv=0.063; latency_p99_ms cv=0.126
- `hnsw m=16 ef_search=64`: latency_p99_ms cv=0.114

### Repetitions

Every repetition is retained:

- `hnsw m=16 ef_search=16` build_seconds: 10.59, 10.59, 10.59
- `hnsw m=16 ef_search=16` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=16` latency_p50_ms: 0.6042, 0.6484, 0.6556
- `hnsw m=16 ef_search=16` latency_p95_ms: 0.7462, 0.8052, 0.8456
- `hnsw m=16 ef_search=16` latency_p99_ms: 0.8152, 0.8939, 1.043
- `hnsw m=16 ef_search=16` recall: 0.872, 0.872, 0.872
- `hnsw m=16 ef_search=16` throughput_per_second: 1,496, 1,413, 1,387
- `hnsw m=16 ef_search=64` build_seconds: 11.24, 11.24, 11.24
- `hnsw m=16 ef_search=64` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=64` latency_p50_ms: 0.7436, 0.775, 0.7546
- `hnsw m=16 ef_search=64` latency_p95_ms: 0.8756, 0.9625, 0.9046
- `hnsw m=16 ef_search=64` latency_p99_ms: 0.9431, 1.182, 1.109
- `hnsw m=16 ef_search=64` recall: 0.9628, 0.9628, 0.9628
- `hnsw m=16 ef_search=64` throughput_per_second: 1,261, 1,146, 1,231
- `hnsw m=16 ef_search=256` build_seconds: 11.35, 11.35, 11.35
- `hnsw m=16 ef_search=256` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=256` latency_p50_ms: 1.992, 1.971, 2.004
- `hnsw m=16 ef_search=256` latency_p95_ms: 2.433, 2.457, 2.453
- `hnsw m=16 ef_search=256` latency_p99_ms: 2.621, 2.758, 2.679
- `hnsw m=16 ef_search=256` recall: 0.9976, 0.9976, 0.9976
- `hnsw m=16 ef_search=256` throughput_per_second: 492.1, 494.6, 486.7
- `hnsw m=16 ef_search=512` build_seconds: 11.31, 11.31, 11.31
- `hnsw m=16 ef_search=512` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=512` latency_p50_ms: 3.296, 3.202, 3.182
- `hnsw m=16 ef_search=512` latency_p95_ms: 4.079, 3.977, 4.042
- `hnsw m=16 ef_search=512` latency_p99_ms: 4.37, 4.28, 4.388
- `hnsw m=16 ef_search=512` recall: 0.9996, 0.9996, 0.9996
- `hnsw m=16 ef_search=512` throughput_per_second: 304.5, 308.4, 307.1
- `hnsw m=16 ef_search=1000` build_seconds: 11.32, 11.32, 11.32
- `hnsw m=16 ef_search=1000` index_size_bytes: 7.594e+07, 7.594e+07, 7.594e+07
- `hnsw m=16 ef_search=1000` latency_p50_ms: 5.15, 5.165, 5.189
- `hnsw m=16 ef_search=1000` latency_p95_ms: 6.436, 6.736, 6.455
- `hnsw m=16 ef_search=1000` latency_p99_ms: 6.946, 7.441, 6.979
- `hnsw m=16 ef_search=1000` recall: 0.9998, 0.9998, 0.9998
- `hnsw m=16 ef_search=1000` throughput_per_second: 192.7, 190.7, 193.2

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

