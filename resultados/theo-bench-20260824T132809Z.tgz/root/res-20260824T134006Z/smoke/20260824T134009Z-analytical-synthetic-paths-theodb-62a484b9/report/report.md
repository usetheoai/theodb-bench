# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260824T134009Z-analytical-synthetic-paths-theodb-62a484b9`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 114 | _not measured_ | 8.955 | 9.623 | 9.682 | yes |
| sum_amount via row | 90.13 | _not measured_ | 11.3 | 11.66 | 11.69 | yes |
| group_by_category via row | 45.11 | _not measured_ | 22.3 | 22.55 | 22.57 | **no** |
| filtered_sum via row | 68.44 | _not measured_ | 14.99 | 15.74 | 15.81 | **no** |
| numeric_filtered_sum via row | 75.1 | _not measured_ | 13.5 | 13.56 | 13.57 | **no** |
| total_rows via columnar | 590.2 | _not measured_ | 1.767 | 1.924 | 1.938 | **no** |
| sum_amount via columnar | 282.2 | _not measured_ | 3.65 | 3.758 | 3.78 | **no** |
| group_by_category via columnar | 43.86 | _not measured_ | 23.07 | 23.2 | 23.21 | yes |
| filtered_sum via columnar | 44.96 | _not measured_ | 22.39 | 22.47 | 22.47 | **no** |
| numeric_filtered_sum via columnar | 170.2 | _not measured_ | 5.963 | 6.178 | 6.197 | **no** |
| total_rows via parquet | 1.896 | _not measured_ | 528.9 | 539.9 | 540.2 | yes |
| sum_amount via parquet | 1.704 | _not measured_ | 592.4 | 593.9 | 594 | yes |
| group_by_category via parquet | 1.618 | _not measured_ | 619.9 | 624.3 | 624.7 | yes |
| filtered_sum via parquet | 1.765 | _not measured_ | 572.8 | 573.6 | 573.6 | yes |
| numeric_filtered_sum via parquet | 1.734 | _not measured_ | 581 | 583.2 | 583.4 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.323; latency_p99_ms cv=0.343
- `filtered_sum via row`: latency_p50_ms cv=0.075; latency_p95_ms cv=0.134; latency_p99_ms cv=0.139; throughput_per_second cv=0.062
- `numeric_filtered_sum via row`: latency_p95_ms cv=0.096; latency_p99_ms cv=0.103
- `total_rows via columnar`: latency_p50_ms cv=0.228; latency_p95_ms cv=0.217; latency_p99_ms cv=0.216; throughput_per_second cv=0.130
- `sum_amount via columnar`: latency_p50_ms cv=0.199; latency_p95_ms cv=0.195; latency_p99_ms cv=0.195; throughput_per_second cv=0.163
- `filtered_sum via columnar`: latency_p50_ms cv=0.063; latency_p95_ms cv=0.059; latency_p99_ms cv=0.059; throughput_per_second cv=0.069
- `numeric_filtered_sum via columnar`: throughput_per_second cv=0.056

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 9.634, 8.955, 8.893
- `total_rows via row` latency_p95_ms: 10.09, 9.623, 9.558
- `total_rows via row` latency_p99_ms: 10.13, 9.682, 9.617
- `total_rows via row` throughput_per_second: 107.4, 114.5, 114
- `sum_amount via row` latency_p50_ms: 11.3, 10.84, 11.63
- `sum_amount via row` latency_p95_ms: 11.66, 11.18, 11.8
- `sum_amount via row` latency_p99_ms: 11.69, 11.21, 11.82
- `sum_amount via row` throughput_per_second: 90.13, 93.33, 87.2
- `group_by_category via row` latency_p50_ms: 22.3, 23.85, 21.85
- `group_by_category via row` latency_p95_ms: 22.55, 37.46, 21.89
- `group_by_category via row` latency_p99_ms: 22.57, 38.67, 21.89
- `group_by_category via row` throughput_per_second: 45.11, 44.9, 46.66
- `filtered_sum via row` latency_p50_ms: 14.99, 15.65, 13.49
- `filtered_sum via row` latency_p95_ms: 15.74, 18.3, 14.04
- `filtered_sum via row` latency_p99_ms: 15.81, 18.54, 14.09
- `filtered_sum via row` throughput_per_second: 68.23, 68.44, 75.95
- `numeric_filtered_sum via row` latency_p50_ms: 13.55, 13.04, 13.5
- `numeric_filtered_sum via row` latency_p95_ms: 15.71, 13.19, 13.56
- `numeric_filtered_sum via row` latency_p99_ms: 15.9, 13.2, 13.57
- `numeric_filtered_sum via row` throughput_per_second: 75.01, 76.99, 75.1
- `total_rows via columnar` latency_p50_ms: 2.491, 1.667, 1.767
- `total_rows via columnar` latency_p95_ms: 2.725, 1.888, 1.924
- `total_rows via columnar` latency_p99_ms: 2.745, 1.908, 1.938
- `total_rows via columnar` throughput_per_second: 472.8, 604.8, 590.2
- `sum_amount via columnar` latency_p50_ms: 4.964, 3.508, 3.65
- `sum_amount via columnar` latency_p95_ms: 5.138, 3.758, 3.69
- `sum_amount via columnar` latency_p99_ms: 5.153, 3.78, 3.694
- `sum_amount via columnar` throughput_per_second: 212.2, 289.4, 282.2
- `group_by_category via columnar` latency_p50_ms: 22.23, 23.07, 23.91
- `group_by_category via columnar` latency_p95_ms: 22.88, 23.2, 24.03
- `group_by_category via columnar` latency_p99_ms: 22.94, 23.21, 24.05
- `group_by_category via columnar` throughput_per_second: 45.05, 43.86, 42.29
- `filtered_sum via columnar` latency_p50_ms: 21.6, 22.39, 24.37
- `filtered_sum via columnar` latency_p95_ms: 22.16, 22.47, 24.66
- `filtered_sum via columnar` latency_p99_ms: 22.21, 22.47, 24.69
- `filtered_sum via columnar` throughput_per_second: 47.32, 44.96, 41.2
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.382, 5.808, 5.963
- `numeric_filtered_sum via columnar` latency_p95_ms: 6.385, 5.867, 6.178
- `numeric_filtered_sum via columnar` latency_p99_ms: 6.386, 5.872, 6.197
- `numeric_filtered_sum via columnar` throughput_per_second: 158.4, 177.1, 170.2
- `total_rows via parquet` latency_p50_ms: 536.4, 528.9, 523.7
- `total_rows via parquet` latency_p95_ms: 539.9, 537.3, 544.6
- `total_rows via parquet` latency_p99_ms: 540.2, 538, 546.4
- `total_rows via parquet` throughput_per_second: 1.882, 1.896, 1.925
- `sum_amount via parquet` latency_p50_ms: 594.6, 592.4, 582
- `sum_amount via parquet` latency_p95_ms: 595.6, 593.9, 582.8
- `sum_amount via parquet` latency_p99_ms: 595.7, 594, 582.8
- `sum_amount via parquet` throughput_per_second: 1.683, 1.704, 1.75
- `group_by_category via parquet` latency_p50_ms: 618.5, 622.3, 619.9
- `group_by_category via parquet` latency_p95_ms: 624.7, 623.5, 624.3
- `group_by_category via parquet` latency_p99_ms: 625.2, 623.7, 624.7
- `group_by_category via parquet` throughput_per_second: 1.618, 1.611, 1.624
- `filtered_sum via parquet` latency_p50_ms: 567.9, 572.8, 575.1
- `filtered_sum via parquet` latency_p95_ms: 569.9, 573.6, 577.2
- `filtered_sum via parquet` latency_p99_ms: 570.1, 573.6, 577.4
- `filtered_sum via parquet` throughput_per_second: 1.769, 1.761, 1.765
- `numeric_filtered_sum via parquet` latency_p50_ms: 581, 584.4, 574.8
- `numeric_filtered_sum via parquet` latency_p95_ms: 583.2, 585.8, 581.8
- `numeric_filtered_sum via parquet` latency_p99_ms: 583.4, 586, 582.4
- `numeric_filtered_sum via parquet` throughput_per_second: 1.734, 1.72, 1.742

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260824T132809Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424522240 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: b35ae08c3987f5a4652dec5ac4a48c970489b5b6 (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

