# analytical/synthetic/paths on theodb

**Status:** EXPLORATORY · **Profile:** research · **Run:** `20260823T233431Z-analytical-synthetic-paths-theodb-0e4f43c7`

> This run is **EXPLORATORY**. Research runs may use non-frozen parameters, so the numbers below cannot back a published claim.

## Results

| Configuration | Throughput/s | Recall | p50 ms | p95 ms | p99 ms | Stable |
|---|---|---|---|---|---|---|
| total_rows via row | 97.08 | _not measured_ | 10.57 | 10.6 | 10.6 | yes |
| sum_amount via row | 76.89 | _not measured_ | 13.07 | 13.08 | 13.08 | yes |
| group_by_category via row | 40.23 | _not measured_ | 25.74 | 26.19 | 26.23 | **no** |
| filtered_sum via row | 63.01 | _not measured_ | 16.45 | 16.56 | 16.57 | yes |
| numeric_filtered_sum via row | 65.93 | _not measured_ | 15.23 | 15.44 | 15.46 | yes |
| total_rows via columnar | 542.1 | _not measured_ | 1.872 | 2.068 | 2.086 | yes |
| sum_amount via columnar | 254.4 | _not measured_ | 3.988 | 4.048 | 4.053 | yes |
| group_by_category via columnar | 38.91 | _not measured_ | 25.88 | 26.18 | 26.2 | **no** |
| filtered_sum via columnar | 40.3 | _not measured_ | 25.36 | 25.63 | 25.65 | **no** |
| numeric_filtered_sum via columnar | 156.8 | _not measured_ | 6.82 | 6.953 | 6.965 | yes |
| total_rows via parquet | 1.764 | _not measured_ | 571 | 572.4 | 572.7 | yes |
| sum_amount via parquet | 1.58 | _not measured_ | 639 | 639.5 | 639.6 | yes |
| group_by_category via parquet | 1.501 | _not measured_ | 674.4 | 674.9 | 674.9 | yes |
| filtered_sum via parquet | 1.637 | _not measured_ | 617.2 | 619.2 | 619.3 | yes |
| numeric_filtered_sum via parquet | 1.615 | _not measured_ | 627.1 | 628.3 | 628.3 | yes |

Unstable points are reported, not removed. Their repetitions disagree by more than the declared threshold, so the median below is a weaker claim than it looks:

- `group_by_category via row`: latency_p95_ms cv=0.092; latency_p99_ms cv=0.097
- `group_by_category via columnar`: latency_p50_ms cv=0.056; latency_p95_ms cv=0.063; latency_p99_ms cv=0.064; throughput_per_second cv=0.055
- `filtered_sum via columnar`: latency_p50_ms cv=0.053; throughput_per_second cv=0.053

### Repetitions

Every repetition is retained:

- `total_rows via row` latency_p50_ms: 10.4, 10.57, 10.64
- `total_rows via row` latency_p95_ms: 10.52, 10.6, 10.76
- `total_rows via row` latency_p99_ms: 10.53, 10.6, 10.77
- `total_rows via row` throughput_per_second: 97.19, 97.08, 94.97
- `sum_amount via row` latency_p50_ms: 13.01, 13.07, 13.22
- `sum_amount via row` latency_p95_ms: 13.05, 13.08, 13.33
- `sum_amount via row` latency_p99_ms: 13.06, 13.08, 13.33
- `sum_amount via row` throughput_per_second: 76.89, 77.18, 75.77
- `group_by_category via row` latency_p50_ms: 26.71, 24.77, 25.74
- `group_by_category via row` latency_p95_ms: 30.49, 26.03, 26.19
- `group_by_category via row` latency_p99_ms: 30.82, 26.14, 26.23
- `group_by_category via row` throughput_per_second: 38.74, 40.41, 40.23
- `filtered_sum via row` latency_p50_ms: 16.46, 16.21, 16.45
- `filtered_sum via row` latency_p95_ms: 16.75, 16.23, 16.56
- `filtered_sum via row` latency_p99_ms: 16.78, 16.23, 16.57
- `filtered_sum via row` throughput_per_second: 60.76, 63.42, 63.01
- `numeric_filtered_sum via row` latency_p50_ms: 15.8, 15.23, 14.9
- `numeric_filtered_sum via row` latency_p95_ms: 15.91, 15.44, 15.08
- `numeric_filtered_sum via row` latency_p99_ms: 15.92, 15.46, 15.1
- `numeric_filtered_sum via row` throughput_per_second: 63.52, 65.93, 67.35
- `total_rows via columnar` latency_p50_ms: 1.979, 1.872, 1.856
- `total_rows via columnar` latency_p95_ms: 2.126, 2.011, 2.068
- `total_rows via columnar` latency_p99_ms: 2.139, 2.024, 2.086
- `total_rows via columnar` throughput_per_second: 512.5, 544.6, 542.1
- `sum_amount via columnar` latency_p50_ms: 3.988, 3.872, 3.992
- `sum_amount via columnar` latency_p95_ms: 4.048, 4.181, 4.014
- `sum_amount via columnar` latency_p99_ms: 4.053, 4.209, 4.016
- `sum_amount via columnar` throughput_per_second: 251.9, 260, 254.4
- `group_by_category via columnar` latency_p50_ms: 23.48, 25.96, 25.88
- `group_by_category via columnar` latency_p95_ms: 23.6, 26.54, 26.18
- `group_by_category via columnar` latency_p99_ms: 23.61, 26.59, 26.2
- `group_by_category via columnar` throughput_per_second: 42.61, 38.69, 38.91
- `filtered_sum via columnar` latency_p50_ms: 23.26, 25.36, 25.63
- `filtered_sum via columnar` latency_p95_ms: 23.89, 25.63, 25.78
- `filtered_sum via columnar` latency_p99_ms: 23.95, 25.65, 25.79
- `filtered_sum via columnar` throughput_per_second: 43.57, 40.3, 39.47
- `numeric_filtered_sum via columnar` latency_p50_ms: 6.963, 6.444, 6.82
- `numeric_filtered_sum via columnar` latency_p95_ms: 7.361, 6.786, 6.953
- `numeric_filtered_sum via columnar` latency_p99_ms: 7.396, 6.817, 6.965
- `numeric_filtered_sum via columnar` throughput_per_second: 146.6, 156.8, 158.9
- `total_rows via parquet` latency_p50_ms: 568.3, 571, 572.1
- `total_rows via parquet` latency_p95_ms: 572.4, 571.9, 574.3
- `total_rows via parquet` latency_p99_ms: 572.7, 571.9, 574.5
- `total_rows via parquet` throughput_per_second: 1.763, 1.764, 1.773
- `sum_amount via parquet` latency_p50_ms: 625.5, 639, 643.2
- `sum_amount via parquet` latency_p95_ms: 627.8, 639.5, 644.7
- `sum_amount via parquet` latency_p99_ms: 628, 639.6, 644.8
- `sum_amount via parquet` throughput_per_second: 1.616, 1.58, 1.561
- `group_by_category via parquet` latency_p50_ms: 660.2, 674.4, 684.3
- `group_by_category via parquet` latency_p95_ms: 662, 674.9, 685.7
- `group_by_category via parquet` latency_p99_ms: 662.1, 674.9, 685.8
- `group_by_category via parquet` throughput_per_second: 1.518, 1.501, 1.468
- `filtered_sum via parquet` latency_p50_ms: 613.1, 617.2, 627.2
- `filtered_sum via parquet` latency_p95_ms: 614.3, 619.2, 639.2
- `filtered_sum via parquet` latency_p99_ms: 614.4, 619.3, 640.3
- `filtered_sum via parquet` throughput_per_second: 1.649, 1.637, 1.597
- `numeric_filtered_sum via parquet` latency_p50_ms: 625.5, 627.1, 627.6
- `numeric_filtered_sum via parquet` latency_p95_ms: 625.8, 630.1, 628.3
- `numeric_filtered_sum via parquet` latency_p99_ms: 625.8, 630.3, 628.3
- `numeric_filtered_sum via parquet` throughput_per_second: 1.615, 1.62, 1.595

## Validation

| Check | Outcome | Required | Detail |
|---|---|---|---|
| sut_alive | PASS | yes |  |
| run_not_refused | PASS | yes |  |
| within_time_budget | PASS | yes |  |
| client_alive | PASS | yes |  |
| operation_count | PASS | yes |  |
| repetitions_completed | PASS | yes |  |
| timeout_rate | PASS | yes |  |
| error_rate | PASS | yes |  |
| result_integrity | PASS | yes |  |
| warmup_policy | PASS | yes |  |
| process_containment | PASS | no |  |
| cpu_limit | UNAVAILABLE | no | unavailable: no CPU set declared |
| memory_limit | UNAVAILABLE | no | unavailable: no memory bound declared |
| no_oom | PASS | yes |  |
| telemetry_complete | PASS | no |  |
| quality_reported | PASS | yes |  |
| clean_source_tree | PASS | no |  |

## Environment

- Host: theo-bench-20260823T232726Z
- CPU: Intel(R) Xeon(R) Platinum 8280 CPU @ 2.70GHz (16 logical, 16 physical)
- SMT: False · Governor: _unavailable_
- Memory: 67424514048 bytes
- Kernel: 6.8.0-124-generic · Runner: theodb-bench 0.6.0
- Benchmark commit: 42193c652c7e779e181694b879471fa171d320ef (dirty: False)

Fields shown in italics were not available on this host and are recorded as absent rather than as zero.

